---
name: multiagent-research-orchestrator
description: >
  Multi-agent orchestration pipeline for first-skill discovery research targeting Brazilian B2B service operators.
  Coordinates 4 specialist subagents (segmentation, form design, schema/scoring, QA) to produce: form blueprint,
  variable dictionary, transcription schema, scoring rubric, case decision logic, and pre/post model.
  ALWAYS activate for: "coletor de pesquisa", "formulário de qualificação", "first-skill discovery",
  "segmentar personas", "blueprint do formulário", "rubrica de scoring", "lógica de decisão",
  "sistema de qualificação de casos", "dicionário de variáveis", "modelo pré vs pós", "orquestra pesquisa".
  Also activate when user pastes a persona list and asks to build a qualification system,
  even without explicit trigger phrases.
---

# Claude Code Multi-Agent Research Orchestrator

This skill implements a **4-subagent research orchestration pipeline** to produce a complete
first-skill qualification system for Brazilian B2B service contexts.

---

## What This Skill Produces

A single, complete research specification that enables a human operator to:

1. Build a form externally (Typeform, Google Forms, Notion, etc.)
2. Collect comparable responses across heterogeneous respondents
3. Transcribe responses into a stable schema
4. Interpret responses using a fixed rubric
5. Classify each case as `accept / accept_with_scope_reduction / needs_clarification / reject`
6. Compare pre-vs-post outcomes after skill delivery

---

## Architecture

```
research-orchestrator (lead)
├── segmentation-researcher       → macro-area grouping + workflow pattern analysis
├── form-blueprint-agent          → universal collector design (sections, questions, variables)
├── schema-scoring-agent          → response schema, scoring rubric, case decision logic, pre/post model
└── qa-consistency-agent          → internal audit, gap detection, final verdict
```

Each agent has a narrow scope. The orchestrator merges, deduplicates, and resolves conflicts.

---

## Fixed Product Truths (Non-Negotiable Context)

Treat these as immutable truths throughout every agent's output:

| Truth | Value |
|---|---|
| Product | First useful Claude Skill + short activation kit |
| Primary target | Brazilian small B2B service businesses and adjacent professional operators |
| Workflow type | Mainly textual and recurrent |
| Offer scope | First implementation + activation (NOT full-stack automation) |
| Workflows per submission | Exactly one |
| Supported environment | Claude.ai with Skills |
| Success definition | Skill received, installed, and used for first useful execution with minimal support |
| User profile | Low tolerance for setup friction; values clarity, practical examples, low cognitive load |

---

## Orchestration Workflow

When this skill activates, follow these steps **in order**:

### Step 1 — Segmentation
Read `agents/segmentation-researcher.md` and execute that agent's task against the input sample.
Produce: macro-areas with workflow patterns, trust requirements, onboarding sensitivity, scope risk.

### Step 2 — Form Blueprint
Read `agents/form-blueprint-agent.md` and execute that agent's task using Step 1 output as context.
Produce: universal collector with all question fields, answer types, normalization rules.

### Step 3 — Schema & Scoring
Read `agents/schema-scoring-agent.md` and execute that agent's task using Steps 1–2 as context.
Produce: variable dictionary, transcription schema, scoring rubric, case decision logic, pre/post model.

### Step 4 — QA Review
Read `agents/qa-consistency-agent.md` and execute that agent's audit against Steps 1–3 outputs.
Produce: gap report, redundancy flags, conflicts, final QA verdict.

### Step 5 — Orchestrator Merge
Merge all outputs. Resolve naming conflicts, remove redundancy, enforce one-workflow-per-submission.
Produce the **Final Output** in the structure below.

---

## Final Output Structure

Return the final answer in **Portuguese (Brazil)**, in exactly this order:

```
1.  Objetivo do coletor
2.  Macroáreas da amostra
3.  Lógica de desenho do formulário
4.  Blueprint completo do formulário
5.  Dicionário de variáveis
6.  Schema de transcrição das respostas coletadas
7.  Rubrica de interpretação e scoring
8.  Lógica de decisão do caso
9.  Modelo pré vs pós
10. Exemplos por macroárea
11. Riscos, ambiguidades e limites
12. Recomendação final de implementação
```

---

## Quality Gate

The output passes **only if** all of these are true:

- [ ] A human can build the form from the output alone
- [ ] Responses from different respondents can be compared
- [ ] Transcription can be done consistently by any operator
- [ ] Pre-vs-post measurement is structurally possible
- [ ] Output is directly actionable for triage and future skill design
- [ ] No scope drift toward full-stack automation, enterprise AI education, or multi-platform delivery
- [ ] One workflow per submission is enforced throughout

---

## Agent Reference Files

| File | Purpose | When to Read |
|---|---|---|
| `agents/segmentation-researcher.md` | Macro-area grouping logic and output format | Step 1 |
| `agents/form-blueprint-agent.md` | Universal collector design spec | Step 2 |
| `agents/schema-scoring-agent.md` | Variable dictionary, rubric, scoring, pre/post | Step 3 |
| `agents/qa-consistency-agent.md` | Audit checklist, gap detection, QA verdict | Step 4 |
| `references/sample-personas.md` | Example persona list for testing | Optional |

---

## Anti-Patterns (Never Do These)

- Do NOT drift into generic market research
- Do NOT optimize for enterprise transformation or broad AI education
- Do NOT allow more than one workflow per submission
- Do NOT fabricate statistics or present inference as certainty
- Do NOT use unstructured prose for critical fields in the schema
- Do NOT conflate `accept_with_scope_reduction` with `needs_clarification` in the decision logic
