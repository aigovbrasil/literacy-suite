# CMD-01-PPS Usage Examples

## Example 1: Daily Consultant Workflow

**Context:** Consultant processes 5 client deliverables every morning

```bash
User: "T03+T07+T12"

Execution log:
├─ T03 activated: Normalize naming
├─ T07 activated: X-Ray asset mode
├─ T12 activated: Client-ready branding
└─ Processing:
    ├─ /mnt/project/client-a-files/ → client-a-deliverable.zip
    ├─ /mnt/project/client-b-files/ → client-b-deliverable.zip
    ├─ /mnt/project/client-c-files/ → client-c-deliverable.zip
    ├─ /mnt/project/client-d-files/ → client-d-deliverable.zip
    └─ /mnt/project/client-e-files/ → client-e-deliverable.zip

Result: 5 ZIPs generated in 30 seconds
Time saved: 2h manual → 30s = 1h 59m 30s
```

---

## Example 2: Emergency Pre-Meeting Package

**Context:** Meeting starts in 2 minutes, need repo ready NOW

```bash
User: "T10"

Execution log:
├─ T10 activated: Emergency package mode
├─ Skipping: validation, QA gates, metadata generation
└─ Fast track:
    ├─ A01: Scan (2s)
    ├─ A09: Build structure (4s)
    └─ A14: Create ZIP (3s)

Result: project-emergency.zip in 12 seconds
Note: Post-meeting, run "W01" for proper version
```

---

## Example 3: Forensic Analysis of Legacy Project

**Context:** Inherited 120-file project, no documentation

```bash
User: "A03+A08+A11+A18"

Execution log:
├─ A03: Normalize naming (fix snake_case, prefixes)
├─ A08: Extract metadata (tags, frameworks, keywords)
├─ A11: Generate dependency graph (imports/references)
└─ A18: Create forensic log (all changes tracked)

Output:
├─ project-cleaned/ (normalized files)
├─ metadata.yaml (structured info)
├─ dependencies.svg (visual graph)
└─ forensic-log.md (audit trail)

Result: "What does this do?" answered in 1 minute
```

---

## Example 4: Portfolio Consolidation

**Context:** Freelancer has 30 projects across 3 months to showcase

```bash
User: "T01+T05+T15"

Execution log:
├─ T01: Hands-off mode (no confirmations)
├─ T05: Multi-source scan
│   ├─ /mnt/project/
│   ├─ /home/claude/uploads/
│   └─ /home/claude/archives/
├─ T15: Generate master index
└─ Processing:
    ├─ Scanned: 30 projects, 456 files
    ├─ Classified: 15 templates, 8 apps, 7 designs
    └─ Generated: index.html with navigation

Result: portfolio-site.zip (deploy to Netlify)
Time: 45 seconds vs 8-hour weekend project
```

---

## Example 5: Safe First-Time Usage

**Context:** User scared of breaking things, first time using skill

```bash
User: "A19+T02"

Execution log:
├─ A19: Backup original files to /backups/
├─ T02: Interactive mode activated
└─ For each operation:
    ├─ [PREVIEW] "Rename file-01.txt → project-file.txt?"
    │   User: "Yes"
    ├─ [PREVIEW] "Move to src/templates/?"
    │   User: "Yes"
    └─ [CONFIRM] "Generate ZIP?"
        User: "Yes"

Result: Full control + rollback available if needed
```

---

## Example 6: Custom Workflow Development

**Context:** User discovers useful combo, wants to save it

```bash
# First use
User: "A01+A08+A12"

# Works well for their flow
# Next day, they alias it:
User: "Save 'A01+A08+A12' as 'my-metadata-flow'"

# Future usage:
User: "my-metadata-flow"
→ Executes A01+A08+A12 automatically
```

---

## Example 7: Weekly Archive Workflow

**Context:** End of sprint, archive completed projects

```bash
User: "W05"  # Multi-source consolidate

Execution log:
├─ Scanned: 3 sources (/project/, /uploads/, /completed/)
├─ Detected: 12 projects
├─ Found duplicates: 3 pairs
├─ Resolved: Kept latest versions
├─ Structure: Hierarchical by sprint
└─ Output: sprint-07-archive.zip

Result: Clean weekly archive, duplicates removed
```

---

## RASTREABILITY LOG (show log)

```
=== CMD-01-PPS Execution History ===

2026-05-04 09:03:12 | T03+T07+T12 | 5 files → 5 ZIPs | 30s | ✅
2026-05-04 11:45:22 | T10 | 1 file → 1 ZIP | 12s | ✅ (emergency)
2026-05-04 14:20:45 | W01 | 12 files → 1 ZIP | 15s | ✅
2026-05-04 16:30:12 | A03+A08+A11+A18 | Forensic | 45s | ✅
2026-05-05 09:00:03 | T03+T07+T12 | 5 files → 5 ZIPs | 30s | ✅

Total executions: 5
Total time saved: ~9 hours manual work
Token cost: $0.15 (vs $0.60 manual equivalent)
```

---

**These examples show real workflows. Start with simple IDs (T03, W01) then build custom combos as you discover patterns.**
