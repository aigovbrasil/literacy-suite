# Naming Conventions — CMD-01-PPS

## ID Taxonomy Structure

### Action IDs (A01-A20)
Format: `A` + two digits  
Range: 01-20  
Purpose: Granular operations  
Example: `A03` = Normalize naming

### Trigger IDs (T01-T15)
Format: `T` + two digits  
Range: 01-15  
Purpose: Pre-configured action sequences  
Example: `T07` = X-Ray asset mode

### Workflow IDs (W01-W10)
Format: `W` + two digits  
Range: 01-10  
Purpose: Complete end-to-end workflows  
Example: `W01` = Full auto hands-off

### Combination Syntax
Format: `ID+ID+ID`  
Separator: `+` (plus sign)  
Order: Execution sequence (left to right)  
Example: `A03+A08+A12` = Normalize → Extract metadata → Generate YAML

---

## File Naming Conventions (Applied by A03)

### From → To Transformations

**Snake Case → Kebab Case**
```
user_profile.html → user-profile.html
contact_form.jsx → contact-form.jsx
```

**Remove Numeric Prefixes**
```
01_intro.md → intro.md
5-dashboard.html → dashboard.html
```

**Remove Double Underscores**
```
_5-__ASS-01.html → ass-01.html
__temp__file.txt → temp-file.txt
```

**Spaces → Hyphens**
```
my file.html → my-file.html
user guide.md → user-guide.md
```

**Lowercase Everything**
```
UserProfile.html → user-profile.html
ContactForm.jsx → contact-form.jsx
```

---

## Directory Structure Conventions

### Standard Repo Layout
```
project-name/
├── README.md
├── .gitignore
├── src/
│   ├── templates/
│   ├── components/
│   └── assets/
├── docs/
│   ├── context/
│   └── metadata.yaml
└── scripts/
```

### Type-Specific Routing

**X-Ray Assets → X-Ray Structure**
```
x-ray-asset/
├── src/
│   ├── ebooks/
│   ├── playbooks/
│   └── dashboards/
└── docs/
    └── x-ray-metadata.yaml
```

**FORGE Templates → FORGE Structure**
```
forge-template/
├── templates/
│   ├── executive/
│   ├── saas/
│   └── editorial/
└── references/
    └── design-tokens.json
```

---

## Metadata YAML Schema

```yaml
project:
  name: project-kebab-case
  type: x-ray-asset | bussola-pme | forge-template | generic
  version: 1.0.0
  created: YYYY-MM-DD
  
files:
  - source: original-filename.ext
    normalized: target-path/kebab-case-name.ext
    type: template | design | reference | script
    tags: [keyword1, keyword2, keyword3]
    size_kb: 99
    complexity: low | medium | high
    
dependencies:
  - file: path/to/file.ext
    imports: [other-file.ext, another.ext]
    
structure:
  directories: 5
  files: 12
  total_size_kb: 1024
```

---

## Log Entry Format

```json
{
  "timestamp": "2026-05-04T09:03:12Z",
  "command": "T03+T07+T12",
  "actions_executed": ["A01", "A02", "A03", "..."],
  "files_processed": 5,
  "changes_applied": ["rename:3", "structure:1", "metadata:1"],
  "output": "/outputs/project-name.zip",
  "duration_seconds": 30,
  "tokens_used": 3400,
  "model": "claude-sonnet-4-5",
  "cost_usd": 0.027
}
```

---

## Reserved Prefixes

**Do NOT use these prefixes for custom IDs:**
- `A` = Actions (reserved)
- `T` = Triggers (reserved)
- `W` = Workflows (reserved)
- `CMD` = Command system (reserved)
- `PPS` = Project Packaging System (reserved)

**Available for custom extensions:**
- `C` = Custom user workflows
- `X` = Experimental features
- `M` = Macros (future)

Example custom: `"C01"` = Your personal workflow

---

**This reference is used by A03 (Normalize Naming) to ensure consistent transformations.**
