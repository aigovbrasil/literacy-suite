# CMD-01-PPS QUICK REFERENCE · Tabular Taxonomy

**Command Structure:** `[ID]` or `[ID+ID+ID]` | **Execution:** Say any ID to Claude

---

## TRIGGER TAXONOMY (MECE)

### SINGLE TRIGGERS — Direct Execution

| ID | Command | Action Sequence | Time | Daily Use Case |
|----|---------|-----------------|------|----------------|
| **T01** | hands-off | A01→A20 (full auto) | 15s | Morning batch: process overnight files |
| **T02** | interactive | A01→A20 (confirm each) | 3m | First-time: new project type |
| **T03** | normalize | A01+A03+A18 | 8s | **MOST COMMON** — fix naming chaos daily |
| **T07** | X-Ray | A01→A14 (X-Ray mode) | 18s | Client deliverables |
| **T10** | emergency | A01+A09+A14 | 12s | Pre-meeting rush |

### POWER COMBINATIONS — Multi-Objective

| Combo | Objective | Actions | Result | Frequency |
|-------|-----------|---------|--------|-----------|
| **T03+T07+T12** | Daily client factory | Normalize + X-Ray + Client brand | 5 ZIPs ready | 10×/day |
| **T01+T05+T15** | Portfolio consolidate | Hands-off + Multi-source + Index | 30 projects → 1 site | 1×/week |
| **A03+A08+A11+A18** | Forensic cleanup | Normalize + Metadata + Graph + Log | Legacy audit complete | 2×/month |
| **A19+W01** | Safety-first auto | Backup + Full workflow | Zero-risk packaging | When scared |
| **T05+T06+T13** | Merge deduped projects | Multi-source + Dedupe + Bundle | Clean consolidated repo | 1×/sprint |

### ACTION ATOMS — Build Your Own

| ID | Action | Use Alone? | Combine With | Example |
|----|--------|------------|--------------|---------|
| **A01** | Scan | ✅ Status check | A02 (classify) | "A01+A02" = inventory |
| **A03** | Normalize | ✅ Quick fix | A18 (log) | "A03+A18" = traceable rename |
| **A08** | Extract metadata | ❌ Needs scan | A01+A12 | "A01+A08+A12" = metadata pipeline |
| **A11** | Dependency graph | ❌ Needs files | A01+A08 | "A01+A08+A11" = full analysis |
| **A19** | Backup | ✅ Safety first | ANY | "A19+[anything]" = safe mode |

### WORKFLOW PRESETS — One-Word Execution

| ID | Workflow | Best For | Alternative |
|----|----------|----------|-------------|
| **W01** | Full auto | Daily repetitive | T01 (same) |
| **W03** | Normalize-only | Naming fixes | T03 (same) |
| **W07** | X-Ray package | X-Ray assets | T07 (same) |
| **W10** | Emergency | Speed critical | T10 (same) |

---

## EXECUTION EXAMPLES (MECE by Context)

**CONTEXT: Unknown files arrived**
→ `"A01+A02"` (scan + classify) → See what you have  
→ Then: `"T04"` (discovery phase) → Full metadata

**CONTEXT: Client wants deliverable NOW**
→ `"T10"` (emergency) → 12 seconds to ZIP  
→ Or: `"T07+T12"` (X-Ray + client brand) if 18s available

**CONTEXT: Weekly portfolio update**
→ `"T01+T05+T15"` → Consolidate all, generate index  
→ Output: portfolio-site.zip deploy-ready

**CONTEXT: Inherited legacy mess**
→ `"A19+T11"` (backup + forensic) → Safe deep analysis  
→ Then: `"A03+A08+A12"` → Clean + document

**CONTEXT: Scared to break things**
→ `"A19+T02"` (backup + interactive) → Full control + rollback

---

## RASTREABILITY LOG FORMAT

Every execution logs:
```
2026-05-04 09:03:12 | T03+T07+T12 | 5 files → 5 ZIPs | 18s | ✅
2026-05-04 14:20:45 | W01 | 12 files → 1 ZIP | 15s | ✅
```

Query: `"show log"` → See all CMD-01-PPS history

---

**Total:** 294 words | **Coverage:** 20 actions, 15 triggers, 10 workflows, 25+ combinations
