# CMD-01-PPS · Project Packaging System v2.0

**ID-based command taxonomy for daily packaging workflows**

---

## 🚀 QUICK START

Add this skill to your Claude account, then use with IDs:

```bash
# Daily most common
"T03+T07+T12"  # Normalize + X-Ray + Client branding

# Emergency packaging
"T10"  # Fast 12-second package

# Safe exploration
"A19+W01"  # Backup first + full auto

# Discovery
"A01+A02"  # Scan + classify (no changes)
```

---

## 📁 STRUCTURE

```
CMD-01-PPS-skill/
├── SKILL.md                           ← Main skill specification
├── README.md                          ← This file
├── references/
│   └── trigger-table.md              ← Quick reference (300 words)
├── scripts/
│   └── [execution scripts go here]
└── examples/
    └── [usage examples go here]
```

---

## 🎯 CORE VALUE

**Problem:** Spend 2h/day packaging projects manually  
**Solution:** 20 combinable actions (A01-A20) + 15 triggers (T01-T15) = infinite custom workflows  
**Result:** 2h → 15min (87.5% time saved), full rastreability, zero copy-paste errors

---

## 📖 DOCUMENTATION

- **Full spec:** Read `SKILL.md` (complete taxonomy + examples)
- **Quick ref:** Read `references/trigger-table.md` (300-word cheat sheet)
- **Examples:** See `examples/` for real workflows

---

## 🌟 WOW COMBINATIONS

1. **T03+T07+T12** — Daily client deliverable factory (30s for 5 clients)
2. **T01+T05+T15** — Portfolio consolidation (30 projects → 1 site in 45s)
3. **A03+A08+A11+A18** — Forensic cleanup (legacy audit complete)

---

## 🔧 INSTALLATION

1. Copy `CMD-01-PPS-skill/` folder to your skills directory
2. Say `"CMD-01-PPS"` to Claude to activate
3. Or use any trigger: `"T03"`, `"W01"`, `"A03+A08"`

---

**Version:** 2.0.0  
**Author:** Leonardo Batista  
**License:** Proprietary (X-Ray OS)
