---
name: x-ray-publish-register
description: Registra skill X-Ray em Biblioteca Notion + Google Drive após validação reader-test, mantém versionamento e notifica clones B2 ativos quando uma nova versão B1 é publicada. ATIVE SEMPRE para "publicar skill X-Ray", "registrar nova versão", "publish X-Ray", "notificar clones consultores", "atualizar biblioteca de skills", "/x-ray-publish", "/x-ray-register", "save skill to notion", "subir skill ao Drive", "release X-Ray". TAMBÉM ATIVE automaticamente após criação bem-sucedida de skill X-Ray (handoff de skill-creator) ou após nova versão da suite empacotada por x-ray-skill-packager. NÃO ATIVE para skills genéricas Anthropic (use skill-publish-and-register). NÃO ATIVE sem reader-test prévio (skill ainda não está pronta para release).
version: 1.0.0
---

# X-Ray Publish & Register

Última camada do pipeline: pega uma skill X-Ray validada (reader-test ✓ + qa_checklist ✓), registra na biblioteca canônica (Notion como source of truth, Google Drive como backup), e dispara notificação para todos os clones B2 ativos.

## Pré-requisitos — gates de publicação

Esta skill **bloqueia publicação** se qualquer item abaixo falhar:

```
GATE-PUB-1: SKILL.md tem YAML frontmatter válido (name + description)?
GATE-PUB-2: Reader-test passou (skill-reader-test-matrix.md preenchido com PASS)?
GATE-PUB-3: qa_checklist.md está com todos os itens marcados?
GATE-PUB-4: VERSION foi incrementada se a skill já existia?
GATE-PUB-5: CHANGELOG entry foi escrita para esta mudança?
GATE-PUB-6: Confirmação explícita "Y" do owner (Leonardo no caso B1)?
```

Falha em qualquer gate: pare, reporte qual gate falhou, sugira a correção. Nunca pule.

## Fluxo de publicação

```
Skill validada (B1 — Leonardo)
    │
    ├─► Notion: Biblioteca de Skills X-Ray (database)
    │       ├── Nova entry: {nome, versão, descrição, owner, data}
    │       ├── Subpágina: SKILL.md completo (anexo + texto inline)
    │       └── Linkagem: skill anterior (parent) se for update
    │
    ├─► Google Drive: /X-Ray Suite/Releases/v{VERSION}/
    │       └── Backup do ZIP completo da suite
    │
    └─► Notificação aos clones B2 ativos
            ├── Slack DM ao consultor (se MCP ativo)
            ├── Email com diff da versão (se solicitado)
            └── Update no Dashboard Operacional do clone
```

## Inputs obrigatórios

1. `skill_name` — nome da skill (deve corresponder a SKILL.md frontmatter)
2. `skill_path` — caminho local da SKILL.md
3. `version` — versão semântica (1.0.0, 1.1.0, etc.)
4. `change_summary` — resumo da mudança (vai para CHANGELOG e notificação)
5. `confirmation` — "Y" explícito do owner

Se algum input estiver vazio: pare, peça ao consultor.

## Operação Notion (via MCP)

```
# Pseudo-código (use Notion MCP tools quando disponíveis)

1. Buscar database "Biblioteca de Skills X-Ray" no workspace do owner
2. Buscar entry existente por skill_name
3. Se existir:
     - Marcar entry antiga como "previous_version"
     - Criar nova entry com version atualizada
     - Linkar parent → child
3. Se não existir:
     - Criar nova entry
4. Criar subpágina com conteúdo completo de SKILL.md
5. Anexar SKILL.md como file attachment
6. Tags: ["X-Ray", "v{VERSION}", "owner:{consultant_short}"]
```

Se Notion MCP não estiver ativo no projeto, pare e oriente: "Notion não conectado. Conecte via Connectors → Notion antes de prosseguir."

## Operação Google Drive (via MCP)

Backup secundário do release:

```
1. Verificar pasta "/X-Ray Suite/Releases/" — criar se não existir
2. Criar subpasta "v{VERSION}/"
3. Upload do ZIP gerado por x-ray-skill-packager
4. Upload do MANIFEST.json
5. Upload do CHANGELOG.md
6. Permissões: read-only para shared org, edit apenas para Leonardo (B1)
```

Drive é backup — se falhar, Notion ainda é a fonte de verdade.

## Notificação aos clones B2

Quando uma skill B1 é atualizada, todos os clones B2 ativos precisam saber. Pipeline:

```
1. Ler lista de clones ativos (consultant_directory.yaml em Drive raiz)
2. Para cada clone B2:
     2.1. Gerar diff entre versão anterior e nova
     2.2. Compor mensagem:
          "🔔 Atualização disponível na suite X-Ray
           Skill: {skill_name}
           Nova versão: {VERSION}
           Mudanças: {change_summary}
           Diff completo: {notion_url}
           Para atualizar seu clone: rode `/x-ray-update` no seu Project."
     2.3. Enviar via canal preferido (Slack DM ou email)
3. Registrar broadcast no decision_log do B1
```

Notificação é informativa — clones não atualizam automaticamente (auto-update quebra customizações). Decisão de atualizar é do consultor B2.

## consultant_directory.yaml — formato

```yaml
# /X-Ray Suite/consultant_directory.yaml (no Drive raiz, escrita pelo Leonardo)
clones:
  - id: "rogerinho-2026"
    consultant_short: "Rogerinho"
    consultant_full: "Rogério Silva"
    email: "rogerinho@consultoria.com.br"
    slack_id: "U0123ABC"
    suite_version: "1.0.0"
    purchased_at: "2026-04-15"
    notify_preference: "slack"
    active: true
  - id: "maria-2026"
    consultant_short: "Maria"
    suite_version: "0.9.5"
    active: false  # paused
```

Apenas Leonardo (B1) edita esse arquivo. Clones leem mas não escrevem.

## Auditoria — decision_log do B1

Toda publicação registra evento:

```
[2026-05-XX 14:32] DECISÃO: Publicada skill x-ray-orchestrator v1.0.0
  Owner: Leonardo
  Mudanças: MVP inicial
  Notificados: 1 clone (Rogerinho)
  Notion entry: {url}
  Drive backup: {url}
```

Trilha de auditoria é fundamental — se um clone B2 reportar bug, é possível rastrear qual versão e quando foi publicada.

## Anti-patterns

- Não publique skill sem reader-test (gate-pub-2 existe por isso)
- Não notifique clones automaticamente sem opt-in (notify_preference no directory)
- Não sobrescreva entry antiga no Notion — preserve histórico via parent/child linking
- Não publique se Notion MCP estiver desconectado — falha silenciosa quebra source of truth
- Não inclua dados sensíveis de clones na notificação (apenas metadados públicos)
- Não use Google Drive como source of truth — é backup, sempre

## Modo dry-run

Para testar sem efeitos colaterais, aceite parâmetro `--dry-run`:

```
/x-ray-publish x-ray-orchestrator v1.0.0 --dry-run

→ Simula todos os passos, mostra o que ACONTECERIA, mas não escreve em Notion/Drive nem notifica.
→ Output: relatório de simulação com URLs hipotéticos e payloads compostos.
```

Útil antes da primeira publicação real para validar setup de MCP.

## Quando esta skill encontra erro

Erros de MCP (auth expirada, rate limit, sem permissão):
- Reporte erro exato
- Sugira ação concreta (re-autenticar, esperar X minutos, ajustar permissão)
- NÃO tente retry automático
- NÃO continue com próximo passo do pipeline

Erros de validação (gate falha):
- Identifique qual gate falhou
- Mostre o item específico que precisa ser corrigido
- Aponte para o arquivo (qa_checklist.md, skill-reader-test-matrix.md)
- Espere correção antes de prosseguir

## Output

Após publicação bem-sucedida:

```
✅ Publicação concluída

Skill: x-ray-orchestrator v1.0.0
Notion: {url}
Drive: {url}
Clones notificados: 1 (Rogerinho via Slack)
Tempo: 14.2s

decision_log atualizado em: /home/claude/[case_id]/decision_log.md
```

## Relação com outras skills X-Ray

- Recebe input de: skill-creator (após reader-test) ou x-ray-skill-packager (após build)
- Lê: SKILL.md a publicar, consultant_directory.yaml
- Escreve em: Notion (Biblioteca de Skills X-Ray), Google Drive (Releases), decision_log do owner
- Notifica: clones B2 via Slack/email
- Roteado por: x-ray-self-knowledge → x-ray-orchestrator (`/x-ray-publish`)
