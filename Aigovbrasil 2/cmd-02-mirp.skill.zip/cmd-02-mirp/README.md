# CMD-02-MIRP · Modify-Improve-Register-Publish v1.0

**Industrial skill development pipeline with Notion registry**

---

## 🚀 QUICK START

```bash
# Most common: Fast improve + register
"T03+T04"

# Complete pipeline
"W01" or "/mirp [skill-name]"

# Emergency (25 seconds)
"T10"

# Batch entire library
"W06"
```

---

## 🎯 WHAT THIS IS

12-step deterministic pipeline that takes any Claude skill through:
1. ✅ ID taxonomy generation (A01-A20, T01-T15, W01-W10)
2. ✅ Combinable trigger creation (ID+ID+ID syntax)
3. ✅ 5W2H framework + problem tree + 3 WOW combos
4. ✅ 295-word MECE tabular reference
5. ✅ 7 usage examples
6. ✅ Notion registry integration
7. ✅ Production-ready ZIP package

**Time:** 2 minutes per skill  
**Quality:** Industrial-grade  
**Registry:** Notion as single source of truth

---

## 🌟 3 WOW COMBINATIONS

### #1: W01 — "Industrial Skill Factory"
```
Input: Any chaotic skill
Output: CMD-style skill + Notion entry + ZIP
Time: 2 minutes
```

### #2: T12+T15 — "Cross-Account Skill Sync"
```
Input: 20 skills in Account A
Output: Same 20 skills in Account B via Notion
Time: 5 minutes
```

### #3: T03+T08+A18 — "Fast Improve + Forensic Log"
```
Input: Production skill (needs transparency)
Output: Enhanced skill + what-changed.md + metadata
Time: 45 seconds
```

---

## 📦 STRUCTURE

```
CMD-02-MIRP-skill/
├── SKILL.md                     ← Complete specification
├── README.md                    ← This file
├── references/
│   ├── trigger-table.md        ← 289-word quick ref
│   └── notion-schema.md        ← Notion database setup
└── examples/
    └── usage-examples.md       ← 7 real workflows
```

---

## 🔧 INSTALLATION

1. Copy to `/mnt/skills/user/CMD-02-MIRP-skill/`
2. Say `"CMD-02-MIRP"` or `"MIRP"` to activate
3. (Optional) Connect Notion MCP for registry

**Without Notion:** Improvement works, registry skipped  
**With Notion:** Full power including cross-account sync

---

## 📊 ID REFERENCE

| Category | Range | Count | Purpose |
|----------|-------|-------|---------|
| Actions | A01-A20 | 20 | Granular operations |
| Triggers | T01-T15 | 15 | Pre-configured sequences |
| Workflows | W01-W10 | 10 | Complete end-to-end |

**Combinable with `+`:** `T03+T04+A18`

---

## 🎓 QUICK EXAMPLES

```bash
# New skill
W01 new-skill

# Quick improve
T03 existing-skill

# Register to Notion
T04 existing-skill

# Batch register all
T12

# Emergency package
T10 demo-skill

# Safe mode
A19+W01
```

---

## 🔗 NOTION INTEGRATION

**Database Properties:**
- Name (title)
- Version (text)
- CMD ID (text)
- Status (select)
- ICP (text)
- WOW Combos (text)
- Updated (date)
- ZIP Path (URL)

See `references/notion-schema.md` for complete setup.

---

## ✅ READY TO USE

**Version:** 1.0.0  
**Author:** Leonardo Batista  
**License:** Proprietary (X-RAY OS)  
**Dependencies:** Notion MCP (optional)
