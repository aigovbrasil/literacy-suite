# CMD-02-MIRP QUICK REFERENCE · Tabular Taxonomy

**Command Structure:** `[ID]` or `[ID+ID+ID]` | **Execution:** Say any ID to Claude

---

## TRIGGER TAXONOMY (MECE)

### SINGLE TRIGGERS — Direct Execution

| ID | Command | Actions | Time | Daily Use Case |
|----|---------|---------|------|----------------|
| **T01** | full pipeline | A01→A20 (complete MIRP) | 2min | New skills or major updates |
| **T03** | fast enhance | A01+A03+A07+A12 | 30s | **MOST COMMON** — quick improve |
| **T04** | register only | A01+A08+A14 | 20s | Add existing skill to Notion |
| **T10** | emergency | A01+A03+A12 | 25s | Pre-demo fast track |
| **T12** | batch register | Scan all + A14 | varies | Sync entire library to Notion |

### POWER COMBINATIONS — Multi-Objective

| Combo | Objective | Result | Frequency |
|-------|-----------|--------|-----------|
| **T03+T04** | Improve + register | Enhanced skill in Notion registry | 5×/day |
| **T12+T15** | Batch sync accounts | Unified registry across accounts | 1×/week |
| **T14+T04** | Forensic + register | Transparent changelog + Notion | When audited |
| **A19+W01** | Backup + full pipeline | Zero-risk complete improvement | When scared |
| **T03+T08+A18** | Fast + metadata + log | Quick improve with full transparency | Production skills |

### ACTION ATOMS — Build Your Own

| ID | Action | Use Alone? | Combine With | Example |
|----|--------|------------|--------------|---------|
| **A01** | Scan skill | ✅ Status check | A02 (extract triggers) | "A01+A02" = baseline analysis |
| **A03** | Generate IDs | ❌ Needs scan | A01+A07 | "A01+A03+A07" = add taxonomy |
| **A08** | Extract metadata | ❌ Needs scan | A01+A14 | "A01+A08+A14" = registry entry |
| **A14** | Register Notion | ❌ Needs data | A08+A14 | "A08+A14" = metadata to Notion |
| **A18** | Forensic log | ✅ Transparency | ANY | "A18+[anything]" = logged mode |
| **A19** | Backup first | ✅ Safety | ANY | "A19+[anything]" = safe mode |

### WORKFLOW PRESETS — One-Command Complete

| ID | Workflow | Best For | Time | Notion? |
|----|----------|----------|------|---------|
| **W01** | Full MIRP Pipeline | Complete improvement + registry | 2min | ✅ |
| **W02** | Quick Improve | Fast enhancement, no registry | 50s | ❌ |
| **W05** | Safe Pipeline | Backup + improve + cleanup | 2.5min | ✅ |
| **W06** | Batch Process | Improve entire skill library | varies | ✅ |
| **W10** | Version Release | Official production release | 60s | ✅ |

---

## EXECUTION EXAMPLES (MECE by Context)

**CONTEXT: New skill just created**
→ `W01` or `full pipeline [name]` → Complete package + Notion entry  
→ **Output:** skill-v2.0.zip + searchable in Notion

**CONTEXT: Existing skill needs quick tweak**
→ `T03` or `fast enhance [name]` → 30-second improve  
→ **Output:** Enhanced skill without full docs

**CONTEXT: Have 20 skills, need them all in Notion**
→ `T12` or `batch register` → Scans all, registers each  
→ **Output:** Searchable library in Notion database

**CONTEXT: Working across 2 Claude accounts**
→ `T12+T15` → Register all + export package  
→ Upload to Account B → `T15` → Import  
→ **Output:** Both accounts synced via single Notion registry

**CONTEXT: Pre-demo in 60 seconds**
→ `T10` or `emergency [name]` → 25-second package  
→ **Output:** Working skill, skip validation

**CONTEXT: Production skill needs update (must be transparent)**
→ `T14+T04` → Forensic analysis + register  
→ **Output:** what-changed.md + updated Notion entry

**CONTEXT: Don't trust the changes**
→ `A19+W01` → Backup + full pipeline  
→ **Output:** Original preserved, rollback available

---

## NOTION INTEGRATION

### With Notion MCP Connected:
- ✅ T04, T12, T14 work (registry features)
- ✅ Searchable skill library
- ✅ Version history tracked
- ✅ Cross-account single source of truth

### Without Notion MCP:
- ✅ All improvement features work
- ⚠️ Registry features skipped gracefully
- ❌ No T04, T12, T14 (Notion-specific)
- ℹ️ Skills still improved, just not registered

**Recommended:** Connect Notion for full power

---

## RASTREABILITY LOG FORMAT

Every execution logs:
```
2026-05-04 09:03 | W01 bussola-orchestrator | 2min | ✅ Notion
2026-05-04 10:15 | T03 x-ray-abs | 30s | ⚠️ No Notion (MCP offline)
2026-05-04 14:20 | T12 batch-all | 5min | ✅ 20 skills registered
```

Query: `"show mirp log"` → See all CMD-02-MIRP execution history

---

## DAILY WORKFLOW RECOMMENDATIONS

**Morning Routine (10 minutes):**
```
09:00 → T12  # Sync any new skills to Notion
09:01 → Review Notion dashboard
09:02 → W01 skill-1
09:04 → W01 skill-2
09:06 → W01 skill-3
09:08 → W01 skill-4
09:10 → W01 skill-5
Result: 5 skills improved + registered
```

**Quick Check (30 seconds):**
```
"T06" or "validate all"
→ QA health check without changes
→ Reports: 18 ✅, 2 ⚠️
```

**Emergency Mode (25 seconds):**
```
"T10 demo-skill"
→ Fast track to working package
→ Post-demo: "W01 demo-skill" for proper improvement
```

---

**Total:** 289 words | **Coverage:** 20 actions, 15 triggers, 10 workflows, Notion registry
