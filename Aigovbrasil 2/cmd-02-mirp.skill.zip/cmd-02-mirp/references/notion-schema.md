# Notion Schema for CMD-02-MIRP Registry

**Database Name:** Skills Library  
**Purpose:** Single source of truth for all Claude skills across accounts

---

## 📋 DATABASE PROPERTIES

### Required Properties

| Property Name | Type | Purpose | Example |
|--------------|------|---------|---------|
| **Name** | Title | Skill name | "bussola-orchestrator" |
| **Version** | Text | Semantic version | "2.0.0" |
| **CMD ID** | Text | Command identifier | "CMD-02-MIRP" |
| **Status** | Select | Production state | "✅ Production" |
| **Updated** | Date | Last modification | 2026-05-04 |
| **ZIP Path** | URL | Download link | /outputs/skill-v2.0.zip |

### Optional Properties

| Property Name | Type | Purpose | Example |
|--------------|------|---------|---------|
| **ICP** | Text | Target user | "Consultants with 20+ skills" |
| **WOW Combos** | Text | Top 3 combinations | "T03+T04, W01, T12+T15" |
| **Tags** | Multi-select | Categories | "Pipeline", "Registry", "Automation" |
| **Dependencies** | Relation | Linked skills | Links to other skill pages |
| **Author** | Person | Creator | Leonardo Batista |
| **Accounts** | Multi-select | Where deployed | "Account A", "Account B" |

---

## 🏗️ SETUP INSTRUCTIONS

### Step 1: Create Database

1. Open Notion
2. Create new database (full-page or inline)
3. Name it: "Skills Library"
4. Choose "Table" view

### Step 2: Add Properties

Add each property from the tables above:

```
Click "+ Add property" for each:
1. Name (Title) — already exists
2. Version (Text)
3. CMD ID (Text)
4. Status (Select)
   Options: ✅ Production, 🚧 Development, 🧪 Testing, ❌ Deprecated
5. Updated (Date)
6. ZIP Path (URL)
7. ICP (Text)
8. WOW Combos (Text)
9. Tags (Multi-select)
   Options: Pipeline, Registry, Automation, X-Ray, Bussola, FORGE, etc.
```

### Step 3: Connect to Claude

1. Install Notion MCP in Claude settings
2. Authorize workspace access
3. Note the database ID (from URL)
4. Test with: `"T04 test-skill"` → Should create entry

---

## 📊 VIEWS RECOMMENDED

### View 1: All Skills (Default)
- Sort by: Updated (newest first)
- Filter: None
- Show: All properties

### View 2: Production Ready
- Filter: Status = ✅ Production
- Sort by: Name (A-Z)
- Show: Name, Version, CMD ID, Updated

### View 3: By Account
- Group by: Accounts
- Sort by: Updated (newest)
- Show: Name, Version, Status

### View 4: Recently Updated
- Filter: Updated in last 7 days
- Sort by: Updated (newest)
- Show: Name, Version, Status, Changes

---

## 🔍 QUERY EXAMPLES

### Find Specific Skill
```
Search bar: "bussola-orchestrator"
→ Shows all versions and accounts
```

### Find All Production Skills
```
View: "Production Ready"
→ Filtered list of stable skills
```

### Find Skills Updated This Week
```
View: "Recently Updated"
→ What changed recently
```

### Find Skills by Author
```
Filter: Author = [your name]
→ Your contributions
```

---

## 🔄 AUTOMATION EXAMPLES (Notion)

### Auto-Update Status
```
When: New page created via CMD-02-MIRP
Then: Set Status to "✅ Production"
```

### Version Alert
```
When: Version property changes
Then: Notify team in Slack
```

### Dependency Checker
```
When: Skill marked as "❌ Deprecated"
Then: Flag all dependent skills
```

---

## 📝 PAGE TEMPLATE

When A14 (Register Notion) executes, it creates pages with this structure:

```markdown
# [Skill Name]

## Overview
[5W2H WHAT section]

## Trigger Reference
bash
T01 — full pipeline (2min)
T03 — fast enhance (30s)
W01 — complete workflow
[etc.]


## WOW Combinations
1. [Combo 1] — [Description]
2. [Combo 2] — [Description]
3. [Combo 3] — [Description]

## Links
- ZIP: [link to outputs]
- GitHub: [if synced]
- Docs: [if external]

## Change Log
- v2.0.0 (2026-05-04): ID taxonomy added
- v1.0.0 (2026-01-15): Initial release
```

---

## 🔐 PERMISSIONS

### Recommended Setup

**Full Access:**
- Skill author
- Team leads
- DevOps

**Can Edit:**
- All developers
- QA team

**Can View:**
- Entire company
- External consultants (select skills)

**Can Comment:**
- Everyone (for feedback)

---

## 🎯 BEST PRACTICES

1. **Always use CMD-02-MIRP** to create/update entries (consistency)
2. **Never manual edit** properties set by MIRP (breaks automation)
3. **Use Tags liberally** for easy filtering
4. **Link Dependencies** to catch breaking changes
5. **Archive old versions** (don't delete — rollback insurance)
6. **Weekly review** of Recently Updated view
7. **Monthly audit** of Status across all skills

---

## 🆘 TROUBLESHOOTING

### Entry not created
→ Check Notion MCP connection: `tool_search("notion")`  
→ Verify database ID in skill config  
→ Test with simple: `T04 test-skill`

### Duplicate entries
→ MIRP checks by Name + Version before creating  
→ If duplicate, it updates existing entry  
→ Manual duplicates: merge in Notion UI

### Missing properties
→ Add missing properties to database  
→ Re-run: `T04 [skill-name]` to populate

### Wrong database
→ Update database ID in MIRP config  
→ Or select correct database when connecting MCP

---

## 📈 METRICS TO TRACK

Add these calculated properties:

**Days Since Update:**
```
formula: dateBetween(now(), prop("Updated"), "days")
```

**Version Major:**
```
formula: first(split(prop("Version"), "."))
```

**Deployment Count:**
```
formula: length(prop("Accounts"))
```

Use for dashboards showing:
- Skills needing attention (>30 days)
- Most deployed skills
- Version distribution

---

**This schema enables CMD-02-MIRP registry features. Without it, improvement still works but registry is skipped.**
