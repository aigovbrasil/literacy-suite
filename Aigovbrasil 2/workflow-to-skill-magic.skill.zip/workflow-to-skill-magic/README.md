# Workflow to Skill Magic

**Transforme workflows casuais em skills profissionais com 3 perguntas.**

Zero programação. Zero jargão. Widget visual incluído.

---

## ✨ O Que Faz

Você repetiu um workflow no Claude? Esta skill transforma em skill automática:
- 📝 3 perguntas simples
- ⚙️ 30 segundos de processamento
- 🎁 Skill pronta + widget visual

---

## 🎯 Quando Usar

Diga qualquer um destes:
```
"transforma isso em skill"
"quero automatizar isso"
"cria skill desse workflow"
"toda semana faço isso, tem como automatizar?"
```

---

## 🚀 Exemplo Rápido

**Você:**
> "Toda segunda crio cronograma semanal, sempre esqueço o formato"

**Skill:**
> ✨ Detectei workflow repetitivo!
> 
> 3 perguntas rápidas:
> 1. Nome? [cronograma-semanal]
> 2. Ativa quando? ["cria cronograma"]
> 3. Só você ou compartilhar? [Só eu]
>
> ⚙️ Criando... 30s

**Você recebe:**
- `cronograma-semanal.skill` (instalável)
- Widget visual interativo
- README em português
- Exemplos prontos

---

## 📦 O Que Vem no Pacote

```
sua-skill/
├── SKILL.md              # Instruções técnicas
├── README-pt-br.md       # Guia em português
├── widget/
│   └── preview.html     # Dashboard visual
└── templates/           # Templates base
```

---

## 💡 Integra Automaticamente

- `/live-prompt-pro-converter` — Normaliza descrição
- `/skill-creator` — Gera estrutura
- `/forge-visual-canvas` — Cria widget
- Skills X-Ray disponíveis
- Suas outras skills

---

## ⚡ Métricas

- **Tempo:** 30-90 segundos
- **Custo:** $0.02-0.08 (Haiku)
- **Perguntas:** 3 apenas
- **Resultado:** Skill production-ready

---

## 🎓 Instalação

1. Baixe `workflow-to-skill-magic.skill`
2. Settings > Skills > Upload
3. Pronto!

---

## 🧪 Teste Agora

Diga ao Claude:
```
"transforma isso em skill"
```

E siga as 3 perguntas.

---

**Versão:** 1.0.0  
**Target:** Iniciantes não-dev  
**Idioma:** PT-BR
