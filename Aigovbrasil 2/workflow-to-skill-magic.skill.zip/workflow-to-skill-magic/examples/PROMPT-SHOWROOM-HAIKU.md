# 🎬 PROMPT SHOWROOM — Workflow to Skill Magic
## Para rodar com Claude Haiku e filmar resultado

---

## ⚡ PROMPT COMPLETO (COPIE TUDO ABAIXO)

```markdown
# 🎯 DEMONSTRAÇÃO — Cria Skill de Cronograma Semanal Automatizado

Você é um freelancer que toda segunda-feira precisa criar um cronograma semanal para seus projetos. 

Sempre esquece o formato ideal e perde 15 minutos toda semana montando do zero.

**Hoje você vai transformar isso em skill automática que faz em 10 segundos.**

---

## CONTEXTO DO CASO

**Persona:** Marina, designer freelancer, 28 anos, São Paulo
- Trabalha com 3-5 clientes simultâneos
- Toda segunda 9h precisa planejar a semana
- Usa Claude há 2 meses, mas sem skills
- Não sabe programar, não quer aprender
- Quer "apertar um botão e resolver"

**Pain Point Atual:**
```
Segunda 9h → Abre Claude
Segunda 9h05 → "Claude, cria cronograma semanal"
Segunda 9h10 → "Adiciona espaço pra reuniões de cliente"
Segunda 9h12 → "Formata bonito em tabela markdown"
Segunda 9h15 → "Adiciona meus blocos fixos (almoço, gym)"
Segunda 9h20 → Copia resultado, cola no Notion

Próxima segunda → REPETE TUDO
```

**Tempo perdido:** 15min/semana × 52 semanas = **13 horas/ano**

---

## WORKFLOW QUE MARINA FEZ (E QUER AUTOMATIZAR)

**Passo 1:** Criar estrutura base
```markdown
| Dia | Manhã (9h-12h) | Tarde (14h-18h) | Noite (19h-21h) |
|-----|----------------|-----------------|-----------------|
| Seg | [VAZIO] | [VAZIO] | [VAZIO] |
| ... | ... | ... | ... |
```

**Passo 2:** Adicionar blocos fixos recorrentes
```yaml
blocos_fixos:
  - "Almoço: 12h-14h (todos os dias)"
  - "Academia: 19h-20h (Seg/Qua/Sex)"
  - "Reunião semanal cliente A: Ter 10h"
  - "Revisão design: Sex 16h"
```

**Passo 3:** Adicionar espaços para ad-hoc
```
[ESPAÇO LIVRE] — Marcador para encaixar demandas urgentes
```

**Passo 4:** Exportar formatado
```
Markdown table → Copiar → Colar no Notion
```

---

## SUA MISSÃO (Claude)

Você vai usar a skill `workflow-to-skill-magic` para transformar esse workflow casual da Marina em uma skill profissional chamada `cronograma-semanal-freelancer`.

**Instruções:**

1. **Ative a skill** `workflow-to-skill-magic`

2. **Capture o workflow** descrito acima (4 passos)

3. **Faça as 3 perguntas** ao usuário (mas como é demo, você mesmo responde):
   - Nome: `cronograma-semanal-freelancer`
   - Gatilhos: `"cria cronograma"`, `"planeja minha semana"`, `"agenda semanal"`
   - Uso: Pessoal (só Marina)

4. **Gere a skill completa** incluindo:
   - SKILL.md estruturado
   - Template base do cronograma
   - Blocos fixos configuráveis
   - README em PT-BR

5. **Crie widget visual interativo** via `/forge-visual-canvas`:
   - Dashboard mostrando a skill
   - Preview do cronograma gerado
   - Botão "Testar skill"
   - Exemplos de customização
   - Design FORGE (executivo, dark mode)

6. **Integre com skills disponíveis**:
   - `docx` (exportar pra Word)
   - `notion` (se disponível, sync direto)

7. **Entregue o pacote final**:
   - `cronograma-semanal-freelancer.skill` (ZIP)
   - `widget-preview.html` (standalone)
   - `README-pt-br.md`
   - `exemplo-cronograma.md` (preview real)

8. **Mostre comparação antes/depois**:
   ```
   ANTES (manual):
   - Tempo: 15min
   - Passos: 4 manuais
   - Erros: Sempre esquece algo
   
   DEPOIS (com skill):
   - Tempo: 10 segundos
   - Passos: 1 comando
   - Erros: Zero (template fixo)
   ```

9. **Calcule ROI**:
   ```
   Economia semanal: 14min 50seg
   Economia anual: 12.8 horas
   Valor (R$100/hora): R$1.280/ano
   Custo da skill: $0.05 (uma vez)
   ROI: 25.600x
   ```

---

## FORMATO DE ENTREGA (PARA FILMAR)

### Seção 1: Introdução
```
🎯 CASO: Marina — Designer Freelancer

Pain Point: 15min/semana criando cronograma manualmente

Solução: Skill automática em 3 perguntas
```

### Seção 2: Demonstração do Workflow Atual (Antes)
```
[Mostra os 4 passos manuais]
[Tempo cronometrado: 15 minutos]
[Destaca pontos de fricção]
```

### Seção 3: Ativação da Skill Magic
```
User: "transforma isso em skill"

Claude: ✨ Detectei workflow repetitivo!
        📝 Nome? [cronograma-semanal-freelancer]
        🎯 Gatilhos? [auto-detectados]
        👥 Uso? [Pessoal]
        
        ⚙️ Criando... 30s
```

### Seção 4: Entrega da Skill
```
🎉 Skill pronta!

📦 Arquivos gerados:
  • cronograma-semanal-freelancer.skill
  • Widget interativo (preview abaixo)
  • README português
  • Template customizável

[Widget renderiza inline via forge-visual-canvas]
```

### Seção 5: Widget Visual (WOW Moment #1)
```html
<!-- Dashboard interativo -->
<div class="skill-dashboard">
  <header>
    <h1>cronograma-semanal-freelancer</h1>
    <span class="version">v1.0.0</span>
  </header>
  
  <section class="workflow-preview">
    <h2>Como funciona:</h2>
    <div class="steps-animation">
      1. Você diz: "cria cronograma"
      2. Claude gera em 10 segundos
      3. Cronograma pronto!
    </div>
  </section>
  
  <section class="output-demo">
    <h2>Resultado:</h2>
    <table class="cronograma-preview">
      <!-- Cronograma real renderizado -->
    </table>
  </section>
  
  <section class="customization">
    <h2>Personalizável:</h2>
    <button onclick="changeTheme()">Dark/Light</button>
    <button onclick="editBlocks()">Editar blocos fixos</button>
  </section>
</div>
```

### Seção 6: Teste da Skill (WOW Moment #2)
```
User: "cria cronograma"

Claude: [Usa skill recém-criada]

Output (10 segundos depois):
┌─────────────────────────────────────────┐
│ CRONOGRAMA SEMANAL — Marina Designer   │
│ Semana de 05-11 Maio 2026              │
├─────┬──────────┬──────────┬──────────┤
│ Dia │ Manhã    │ Tarde    │ Noite    │
├─────┼──────────┼──────────┼──────────┤
│ SEG │ [LIVRE]  │ [LIVRE]  │ Academia │
│     │          │          │ 19h-20h  │
├─────┼──────────┼──────────┼──────────┤
│ TER │ Cliente A│ [LIVRE]  │ [LIVRE]  │
│     │ 10h-11h  │          │          │
├─────┼──────────┼──────────┼──────────┤
│ ... │ ...      │ ...      │ ...      │
└─────┴──────────┴──────────┴──────────┘

Blocos fixos aplicados:
✓ Almoço 12h-14h (todos os dias)
✓ Academia Seg/Qua/Sex
✓ Reunião cliente A Ter 10h
✓ Revisão design Sex 16h

Tempo de geração: 8.3 segundos
```

### Seção 7: Comparação Antes/Depois (WOW Moment #3)
```
┌──────────────────────────────────────────┐
│ ANTES (Manual)        │ DEPOIS (Skill)  │
├───────────────────────┼─────────────────┤
│ Tempo: 15min          │ Tempo: 10seg    │
│ Passos: 4 manuais     │ Passos: 1       │
│ Erros: Frequentes     │ Erros: Zero     │
│ Frustração: Alta      │ Frustração: Zero│
│ Consistência: Baixa   │ Consistência: 100%│
└───────────────────────┴─────────────────┘

📊 ROI Anual:
  • Economia tempo: 12.8 horas
  • Valor economizado: R$1.280
  • Custo skill: $0.05
  • ROI: 25.600x
```

### Seção 8: Integrações Automáticas (WOW Moment #4)
```
💡 Integrações detectadas:

✓ docx — Exportar pra Word
  Comando: "exporta cronograma pra Word"

✓ pdf — Gerar PDF imprimível
  Comando: "gera PDF do cronograma"

✓ notion (se configurado) — Sync automático
  Comando: "envia pro Notion"

Quer ativar alguma? [SIM] [Depois]
```

### Seção 9: Próximos Passos
```
📥 Como instalar:

1. Baixe: cronograma-semanal-freelancer.skill
2. Settings > Skills > Upload
3. Pronto!

🧪 Teste agora:
"cria cronograma"

📱 Funciona em:
✓ Claude.ai (web)
✓ Claude app (mobile)
✓ Claude Code (desktop)
```

### Seção 10: Call-to-Action (Marketing)
```
🎁 Quer criar SUA skill automática?

Use: workflow-to-skill-magic

Transforme qualquer workflow repetitivo em skill profissional:
• 3 perguntas simples
• 30 segundos de processamento
• Skill pronta com widget visual

Baixe agora: [LINK]
```

---

## CHECKLIST DE FILMAGEM

Para o vídeo ficar perfeito:

### Frame 1: Problema (0:00-0:15)
- [ ] Mostra Marina perdendo 15min toda segunda
- [ ] Destaca frustração ao repetir workflow
- [ ] Pain point claro: "Sempre esqueço o formato"

### Frame 2: Solução (0:15-0:30)
- [ ] Introduz workflow-to-skill-magic
- [ ] "3 perguntas, 30 segundos, skill pronta"
- [ ] Zero programação, zero jargão

### Frame 3: Demo (0:30-1:30)
- [ ] User: "transforma isso em skill"
- [ ] 3 perguntas (filmadas em tempo real)
- [ ] Processamento visível (30s)
- [ ] Skill gerada

### Frame 4: Widget WOW (1:30-2:00)
- [ ] Widget renderiza inline (visual impacto)
- [ ] Design FORGE premium
- [ ] Animações smooth
- [ ] Preview do cronograma

### Frame 5: Teste Real (2:00-2:20)
- [ ] "cria cronograma" → 10 segundos → pronto
- [ ] Comparação lado a lado: 15min vs 10seg
- [ ] ROI calculado: R$1.280/ano

### Frame 6: CTA (2:20-2:30)
- [ ] "Crie SUA skill agora"
- [ ] Link para download
- [ ] Thumbnails de outros casos (upsell)

---

## CONFIGURAÇÃO TÉCNICA

**Modelo:** Claude Haiku 4 (rápido + barato)  
**Custo estimado:** $0.05 total  
**Tempo execução:** ~60 segundos  
**Output:** ~3000 palavras + widget HTML  

**Por que Haiku?**
- Showroom não precisa Opus
- Workflow já estruturado (não é brainstorm)
- Widget via script (FORGE templates prontos)
- ROI visual: barato = melhor demo

---

## COMANDOS COPY-PASTE

### Para rodar no Claude:
```
[Cole todo o conteúdo deste arquivo]
```

### Para filmar:
```bash
# Screen recording
CMD + SHIFT + 5 (Mac)
Win + G (Windows)

# Foco na seção do widget
# Zoom suave quando ROI aparecer
# Pause em cada WOW moment (3-5 segundos)
```

---

## RESULTADO ESPERADO

Ao final você terá:

1. ✅ Skill funcional instalada
2. ✅ Widget visual impactante
3. ✅ Demonstração filmável
4. ✅ ROI calculado (viral hook)
5. ✅ 4-5 WOW moments claros
6. ✅ Material pronto pra marketing

**Tempo total:** 2-3 minutos de vídeo final  
**Edição mínima:** Só cortes + zoom nos WOW moments  
**Virality score:** 8/10 (problema real + solução wow + ROI absurdo)

---

**Status:** Ready to film  
**Target:** Topo de funil, iniciantes não-dev  
**Hook:** "R$1.280 economizados com 3 perguntas"
```

---

## 🎬 COMO USAR ESTE PROMPT

1. **Copie tudo** (do "PROMPT COMPLETO" até o fim)
2. **Cole no Claude** (Haiku recommended)
3. **Aguarde ~60 segundos**
4. **Filme a tela** enquanto outputs aparecem
5. **Edite** (zoom nos WOW moments)
6. **Publique** com hook: "R$1.280/ano economizados em 30 segundos"

---

**Custo:** $0.05  
**Tempo:** 60seg geração + 5min filmagem + 10min edição  
**ROI Marketing:** Viral hook + prova social + caso concreto
