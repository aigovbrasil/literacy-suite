# CMD-03-MARO Usage Examples

**Real-world scenarios with exact commands and expected outputs**

---

## Example 1: New Client Research System (W01)

**Scenario:** Monday morning, received 15 persona descriptions from new client. Need complete qualification system by EOD.

**Command:**
```
W01

[paste]
1. Consultoria empresarial (50-200 funcionários)
2. Escritório de advocacia trabalhista
3. Clínica odontológica (3 dentistas)
4. Contabilidade para MEI/ME
5. Psicóloga clínica (atendimento individual)
... [10 more]
```

**Actions Executed:** A01→A20 (full pipeline, 15min)

**Output Received:**
```
research-system-20260504/
├── 01-form-blueprint.md (4 sections, 18 questions)
├── 02-variable-dictionary.md (18 variables documented)
├── 03-transcription-schema.yaml (stable schema)
├── 04-scoring-rubric.md (4 criteria, 1-10 scale)
├── 05-decision-logic.md (classification rules)
├── 06-pre-post-model.md (effectiveness framework)
├── 07-typeform-export.json
└── 08-google-forms-export.md
```

**Outcome:** Built form in Typeform, sent to client same day. 50 responses in 3 days.

**Time:** 15 minutes (vs 50 hours manual)

---

## Example 2: Emergency Pre-Call Form (T10)

**Scenario:** 10:25 AM, client call at 11:00. They want to discuss qualification form. Need something to show NOW.

**Command:**
```
T10 emergency

Personas:
- Consultoria de RH para PMEs
- Escritório de arquitetura residencial
- Distribuidora de produtos médicos
- Agência de marketing digital
- Fisioterapeuta domiciliar
```

**Actions Executed:** A01+A02+A05+A10+A17 (5min)

**Output Received:**
```
emergency-system-minimal/
├── form-blueprint.md (3 sections, 12 questions)
├── scoring-rubric.md (basic 4-criteria)
└── decision-logic.md (simple rules)
```

**Outcome:** Had form blueprint ready for 11:00 call. Client approved approach. Full system built post-call using W01.

**Time:** 5 minutes (call saved)

---

## Example 3: Quick Persona Segmentation (T03)

**Scenario:** Friday planning session. Want to understand persona clusters before committing to form design.

**Command:**
```
T03 segment

[paste 20 persona descriptions]
```

**Actions Executed:** A01+A02 (1min)

**Output Received:**
```markdown
SEGMENTATION RESULTS:

Macro-Area 1: Knowledge Workers (7 personas)
- Workflow pattern: Document-heavy, consultation-based
- Trust requirement: High (confidential data)
- Onboarding sensitivity: Medium

Macro-Area 2: Healthcare Providers (5 personas)
- Workflow pattern: Appointment-driven, patient records
- Trust requirement: Very high (HIPAA/LGPD)
- Onboarding sensitivity: High (compliance)

Macro-Area 3: Distribution/Commerce (4 personas)
- Workflow pattern: Inventory + orders + logistics
- Trust requirement: Medium
- Onboarding sensitivity: Low

Macro-Area 4: Creative Services (4 personas)
- Workflow pattern: Project-based, client revisions
- Trust requirement: Medium
- Onboarding sensitivity: Medium
```

**Outcome:** Team agreed segments make sense. Proceeded with W01 next week.

**Time:** 1 minute

---

## Example 4: Form Design Without Full System (T05)

**Scenario:** Have existing scoring rubric from previous project. Just need new form for different personas.

**Command:**
```
T05 form blueprint

Personas:
- Corretora de seguros (pessoa física)
- Despachante documentalista
- Personal trainer (aulas particulares)
- Nutricionista esportivo
```

**Actions Executed:** A01+A05+A06+A07+A18 (5min)

**Output Received:**
```
form-blueprint/
├── form-sections.md (4 sections, 15 questions)
├── variable-definitions.md (15 variables)
└── typeform-export.json (ready to import)
```

**Outcome:** Imported JSON to Typeform. Form live in 10 minutes. Used existing rubric from last project.

**Time:** 5 minutes + 5 min manual Typeform setup = 10min total

---

## Example 5: Batch Response Scoring (T12)

**Scenario:** Wednesday afternoon. 100 forms filled. Need to score all and make decisions by EOD.

**Command:**
```
T12 batch score

[upload responses-export.csv]
```

**Actions Executed:** A08+A10+A11 (loop 100×, 10min total)

**Output Received:**
```csv
respondent_id,workflow_clarity,scope_feasibility,trust_level,onboarding_readiness,total_score,decision
R001,8,9,8,7,32,accept
R002,6,7,5,6,24,accept_with_reduction
R003,4,6,7,5,22,needs_clarification
R004,3,4,3,3,13,reject
... [96 more]

SUMMARY:
✅ Accept: 47 (47%)
⚠️ Accept with Reduction: 28 (28%)
❓ Needs Clarification: 18 (18%)
❌ Reject: 7 (7%)
```

**Outcome:** Sent decisions to sales team. 47 accepted immediately. 28 scheduled for scope clarification. 18 follow-up emails sent. 7 politely declined.

**Time:** 10 minutes (vs 50 hours manual @ 30min/response)

---

## Example 6: Iterative Design — Check Then Commit (T03 → T05)

**Scenario:** Cautious approach. Want to verify segmentation before designing form.

**Step 1 Command:**
```
T03 segment

[paste 12 personas]
```

**Step 1 Output:** 3 macro-areas identified.

**Review with team:** "Looks good, proceed with form."

**Step 2 Command:**
```
T05 form blueprint
```

**Step 2 Output:** Form blueprint + Typeform JSON.

**Outcome:** Two-step validation reduced risk. Team confident in design.

**Total Time:** 1min + 5min = 6 minutes (with review break in between)

---

## Example 7: Custom Agent Combination (A02+A05+A10)

**Scenario:** Have existing QA system. Just need: segmentation + form + scoring. Skip transcription schema and pre/post model.

**Command:**
```
A02+A05+A10

[paste personas]
```

**Actions Executed:**
- A02: Segmentation (Agent 1)
- A05: Form sections (Agent 2)
- A10: Scoring rubric (Agent 3)

**Output Received:**
```
custom-output/
├── segmentation-report.md
├── form-sections.md
└── scoring-rubric.md
```

**Outcome:** Exactly what was needed. No extra files. Integrated into existing workflow.

**Time:** 4 minutes (vs 15min full W01)

---

## Trigger Decision Tree

```
START: I have personas

Q1: Do I need complete system?
  YES → W01 (15min)
  NO → Go to Q2

Q2: Emergency situation?
  YES → T10 (5min minimal)
  NO → Go to Q3

Q3: What do I need specifically?
  Just segmentation → T03 (1min)
  Just form → T05 (5min)
  Just scoring → T07 (3min)
  Form + schema → T08 (6min)
  Custom → A02+A05+... (combine actions)

Q4: Do I have responses to score?
  YES → T12 (10min for 100)
  NO → Design system first (back to Q1)
```

---

## Pro Tips

1. **Start with T03** if unsure — 1 minute to verify segments makes sense
2. **Use T10** before client calls — better to have something than nothing
3. **T12 saves massive time** — automate what's automatable (scoring)
4. **W01 is default** — unless you know you need less, run full pipeline
5. **A13 (QA) is automatic** in workflows — agents catch their own mistakes
6. **Combine freely** — A02+A05+A10 = custom workflow in 4min

---

**All examples use real CMD-03-MARO IDs. Copy-paste commands directly.**
