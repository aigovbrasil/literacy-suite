# Sample Personas — Reference

This file contains the canonical persona sample used for testing and examples.
Use this when the user hasn't provided their own sample.

## Sample List

| # | Name | Role / Context |
|---|---|---|
| 1 | João | Estudante universitário |
| 2 | Andressa | Advogada |
| 3 | Kleber | Empreendedor — imobiliária |
| 4 | Agência MKT Beens | Agência de marketing |
| 5 | Domingos | Finanças pessoais |
| 6 | Cristiane | Professora |
| 7 | FGV Santos Business | Instituição de ensino |
| 8 | Mari | Diretora |
| 9 | Fabio | Empreendedor — dono de oficina |
| 10 | Guilherme | Engenheiro agrônomo |
| 11 | Gilson | Contador |
| 12 | Armando | Consultor de leilão de imóveis |
| 13 | Gabriela | Estudante |
| 14 | Pedro | Estudante |
| 15 | Ana | Professora |
| 16 | Professora de inglês Unlimited | Profissional de ensino de idiomas |
| 17 | Silvana | Psicóloga |
| 18 | Sabrina | Psiquiatra |
| 19 | Renan Franco | Influencer |
| 20 | Bee | Empresa de consultoria de negócios |

## Notes on This Sample

- **High heterogeneity**: spans students, regulated professionals, small business owners, educators, and service firms.
- **ICP signal**: strongest ICP alignment likely in Andressa, Kleber, Gilson, Armando, Silvana, Sabrina, Bee, Mari, and Agência MKT Beens.
- **Out-of-scope signals**: Domingos (finanças pessoais = B2C, not B2B), students (no commercial workflow), Renan Franco (content/creator context, not B2B service).
- **Ambiguous signals**: Guilherme (depends on whether agronomic work is client-facing), FGV Santos Business (institutional buyer dynamics differ).

## Expected Macro-Area Count

Between 4 and 6 macro-areas is appropriate for this sample.
