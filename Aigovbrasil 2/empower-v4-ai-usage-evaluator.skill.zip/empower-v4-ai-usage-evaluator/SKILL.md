---
name: empower-v4-ai-usage-evaluator
description: Evaluate, normalize, compare, and improve AI/Claude usage patterns across accounts, conversations, exports, prompts, and research datasets using the Empower V4 framework. Use when the user asks to run Empower, analyze Claude/AI conversations, compare accounts, calculate maturity scores, detect prompt risk patterns, normalize epistemic/narrative extraction data, generate usage quality reports, build quality-label queues, or produce publishable Medium/GitHub-style analysis from interaction datasets. Do not use for one-off prompt rewriting, generic Claude questions, or advice without historical interaction data.
---

# Empower V4 — AI Usage Evaluator

## Purpose

Empower V4 is a local-first evaluation skill for AI usage intelligence. It converts messy conversation exports and research workbooks into normalized interaction datasets, computes structural maturity, compares accounts, detects weak prompt patterns, and produces report-ready evidence for workflow improvement or publication.

The skill is designed for **system-level evaluation**, not isolated prompt editing.

## Activate When

Use this skill when the user asks for any of the following:

- Run Empower / Empower V4 / AI usage evaluator.
- Analyze Claude, ChatGPT, or AI conversation exports.
- Compare accounts, users, workflows, prompt styles, or interaction quality.
- Calculate maturity score, quality lift, structural density, expansion ratio, risk clusters, or prompt upgrade candidates.
- Normalize uploaded XLSX/CSV/JSON/JSONL/ZIP data into a canonical interaction schema.
- Build epistemic extraction, narrative discovery, or x-ray research datasets.
- Prepare GitHub, Medium, LinkedIn, or research-style reports from AI usage data.

Do **not** use this skill for:

- A single prompt rewrite without dataset analysis.
- Generic prompt engineering advice.
- General Claude/OpenAI product questions.
- Tasks where no interaction history, file, or metric frame is provided.

## Operating Principles

1. **Local-first**: process uploaded data locally; do not rely on external services for private files.
2. **Never mix fact and hypothesis**: label inferred fields as assumptions, risks, or proxy metrics.
3. **Separate structural metrics from quality metrics**: maturity is not the same as validated output quality.
4. **Flag confidence**: small, imbalanced, or unlabeled datasets must be marked exploratory.
5. **Preserve raw evidence**: keep source files and normalized outputs traceable.
6. **Prefer reproducible scripts**: generate outputs with scripts in `scripts/`, not manual one-off analysis.
7. **Use concise, report-ready outputs**: Markdown summary + CSV/XLSX/JSON artifacts.

## Directory Contract

Expected directory structure:

```text
empower-v4-ai-usage-evaluator/
├── SKILL.md
├── README.md
├── manifest.json
├── scripts/
│   ├── empower_v4_evaluator.py
│   ├── build_epistemic.py
│   └── build_narrative_discovery.py
├── schemas/
│   └── canonical_interaction_schema.json
├── references/
│   ├── metric_formulas.md
│   ├── v2_compatibility.md
│   ├── v3_compatibility.md
│   └── publishing_protocol.md
├── examples/
│   └── data/
├── tests/
│   └── test_empower_smoke.py
└── docs/
    └── output_contract.md
```

## Input Detection

### Supported Inputs

- `.csv`: canonical interaction datasets, metrics tables, label queues.
- `.jsonl`: canonical interaction records.
- `.json`: raw exports or structured conversation objects.
- `.zip`: grouped account exports or multi-file packages.
- `.xlsx`: epistemic extraction, x-ray discovery, narrative discovery, research workbooks.

### Canonical Interaction Schema

Minimum useful fields:

```text
interaction_id
account_id
conversation_id
timestamp
user_prompt
assistant_response
task_type
prompt_format
context_richness
prompt_length
response_length
turn_sequence
```

Recommended additional fields:

```text
source_file
source_account
model
language
structure_density
code_presence
expansion_ratio
evidence_attachment
quality_label_status
```

## Execution Modes

Use the main script for normalized CSV/JSONL interaction analysis:

```bash
python scripts/empower_v4_evaluator.py \
  --input input.csv \
  --mode full \
  --output empower_v4_package \
  --charts
```

Modes:

| Mode | Use Case | Output Focus |
|---|---|---|
| `quick` | Fast maturity scan | Score + top risks |
| `compare` | Multi-account comparison | Account deltas |
| `full` | Default complete run | Report + CSV suite |
| `labels` | Human-labeled quality analysis | Lift and quality metrics |
| `upgrade` | Prompt improvement queue | Top rewrite candidates |
| `all` | Full + labels + charts | Complete package |

## Workflow

### 1. Inspect Inputs

Identify file type, schema, account count, row count, labels, and whether the dataset is raw or canonical.

### 2. Normalize

Map data into canonical schema. If fields are missing, infer only when reasonable and mark as proxy or assumption. Missing critical fields must become a gap entry rather than fabricated content.

### 3. Score Structural Maturity

Compute maturity using weighted structural components:

```text
maturity = 1 + 4 * (
  0.30 * prompt_structure +
  0.25 * context_richness +
  0.20 * output_control +
  0.10 * task_diversity +
  0.10 * high_value_task_share +
  0.05 * evidence_attachment
)
```

Levels:

| Score | Level |
|---:|---|
| 1.0–1.9 | L1 Ad-hoc |
| 2.0–2.9 | L2 Functional |
| 3.0–3.9 | L3 Structured |
| 4.0–4.5 | L4 Optimized |
| 4.6–5.0 | L5 Systematic |

### 4. Compare Accounts or Workflows

Compare:

- maturity score
- prompt format distribution
- context richness
- structure density
- code presence
- task type mix
- expansion ratio
- risk cluster concentration
- upgrade candidate volume

Warn when account sizes are imbalanced or below confidence threshold.

### 5. Detect Risk Clusters

Flag combinations such as:

- short prompt + low context + high-value task
- low-context analysis/research/code tasks
- high expansion ratio from underspecified prompt
- repeated rework indicators
- hallucination labels or unresolved evidence gaps

### 6. Analyze Labels When Available

Quality labels are separate from structure. Join using `interaction_id`; fallback to `conversation_id + turn_sequence` or prompt/response hash.

Expected label columns:

```text
success_1st_turn
rework_required
hallucination_detected
usefulness_score
precision_score
clarity_score
notes
labeler
label_ts
```

### 7. Generate Outputs

Minimum package:

```text
empower_v4_package/
├── README.md
├── empower_v4_report.md
├── account_comparison.csv
├── maturity_scorecard.csv
├── risk_clusters.csv
├── prompt_upgrade_candidates.csv
├── normalized_interactions.csv
└── run_manifest.json
```

Optional charts:

```text
charts/
├── maturity_by_account.png
├── prompt_format_distribution.png
├── context_richness_distribution.png
├── expansion_ratio_by_format.png
└── risk_cluster_heatmap.png
```

## Confidence Rules

| Evidence Size | Confidence |
|---:|---|
| `<20` interactions | very low / exploratory |
| `20–49` interactions | low |
| `50–99` interactions | medium |
| `>=100` interactions | high |

For account comparison, prefer at least 30 interactions per account; ideal is 50+.

## Report Requirements

Every final report should include:

1. Executive summary.
2. Dataset profile and confidence level.
3. Account/workflow comparison.
4. Top maturity drivers.
5. Top risk clusters.
6. Top 10 prompt upgrade candidates.
7. Labels/lift section if labels exist.
8. Gaps and assumptions.
9. Next actions.
10. Files generated.

## Publication Protocol

When the user asks whether analysis is publishable for GitHub, Medium, LinkedIn, or a blog:

- Separate private evidence from public claims.
- Remove raw prompts/responses unless the user explicitly approves them.
- Convert private account IDs into anonymized archetypes.
- State that structural maturity is a proxy unless human labels exist.
- Include methodology, dataset limitations, and reproducibility notes.
- Prefer charts and aggregate tables over screenshots of private conversations.

## Script Map

| Script | Role |
|---|---|
| `scripts/empower_v4_evaluator.py` | Main interaction evaluator and report generator |
| `scripts/build_epistemic.py` | Builds epistemic extraction workbooks / data structures |
| `scripts/build_narrative_discovery.py` | Builds narrative discovery and x-ray style research workbooks |

## Safety and Data Handling

- Do not upload private datasets to external services.
- Do not expose private prompts unless needed and approved.
- Do not present proxy metrics as ground-truth quality.
- Do not infer sensitive personal attributes from usage patterns.
- Always mark assumptions (`A-###`), risks (`R-###`), metrics (`M-###`), tasks (`T-###`), and decisions (`D-###`) when producing vault-style outputs.
