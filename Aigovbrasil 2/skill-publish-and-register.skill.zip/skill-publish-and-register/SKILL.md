---
name: skill-publish-and-register
description: >
  Orquestra o registo completo de uma skill nova após a sua criação no Notion:
  cria entrada na Biblioteca de Skills, guarda SKILL.md completo como subpágina
  (repositório único), e adiciona linha no Dashboard Operacional. Zero passos manuais.
  Google Drive MCP não permite escrita — Notion é o repositório canónico definitivo.

  SEMPRE ativar quando o utilizador disser:
  - "publica a skill", "regista a skill", "salva no notion"
  - "linha de produção da skill", "skill-publish", "publish and register"
  - Qualquer frase após criação de skill indicando querer guardar/registar

  TAMBÉM ativar AUTOMATICAMENTE ao final de qualquer criação bem-sucedida de skill.
---

# Skill Publish & Register — Meta-Skill de Linha de Produção

Orquestra 3 ações em sequência após criação de uma skill. Notion é o repositório único — Drive removido por limitação de escrita no MCP.

---

## Arquitectura do repositório

```
Biblioteca de Skills (Database Notion)
└── [entrada da skill]           ← metadata + campos
    └── 📄 SKILL.md — [nome]     ← subpágina com conteúdo completo
```

Esta estrutura substitui completamente o Google Drive. Cada skill tem:
- **Metadata** nos campos da database (pesquisável, filtrável)
- **Conteúdo completo** na subpágina SKILL.md (repositório canónico)

---

## Pré-condições

Antes de executar, confirmar:
- [ ] Nome da skill (slug, ex: `doc-to-5w2h-json-extractor`)
- [ ] SKILL.md completo gerado (conteúdo integral)
- [ ] Categoria (ver opções abaixo)
- [ ] Trigger phrases (2–5 frases)
- [ ] Função (1–2 linhas)
- [ ] Dependências (conectores / outras skills, ou "Nenhuma")

---

## Passo 1 — Notion Biblioteca de Skills (metadata)

**Database ID:** `1f270b80-ef55-40af-980b-5a7cad2ffdfc`
**Data Source ID:** `65ddf3a0-ad9d-48aa-812e-c87df860277c`
**URL:** https://www.notion.so/1f270b80ef5540af980b5a7cad2ffdfc

Criar nova página na database com estas propriedades:

| Propriedade | Valor |
|---|---|
| Nome da Skill | [nome-da-skill] |
| Categoria | [ver opções] |
| Trigger Phrases | Lista das frases de ativação |
| Função | Descrição 1–2 linhas |
| SKILL.md Preview | Primeiras 3–4 linhas da descrição do SKILL.md |
| Status | Ativa |
| Versão | 1.0 |
| Data Criação | [data de hoje, ISO: YYYY-MM-DD] |
| Dependências | Conectores / skills necessárias, ou "Nenhuma" |

Guardar o **page_id** retornado — necessário para o Passo 2.

---

## Passo 2 — Subpágina SKILL.md (repositório completo)

Criar subpágina dentro da entrada criada no Passo 1:

```
parent: { type: "page_id", page_id: [id da entrada criada no Passo 1] }
properties: { title: "📄 SKILL.md — [nome-da-skill]" }
content: [SKILL.md completo em Notion Markdown]
icon: "📄"
```

Esta subpágina É o repositório da skill. Contém:
- Frontmatter YAML em bloco de código
- Todas as fases/instruções em Markdown estruturado
- Tabelas de referência rápida
- IDs de sistema actualizados

---

## Passo 3 — Notion Dashboard Operacional

**Page ID:** `334a986e-e0b3-8137-956b-f68313e32782`
**URL:** https://www.notion.so/334a986ee0b38137956bf68313e32782

Adicionar linha à tabela "Skills Ativas — Referência Rápida" via `update_content`:

```
| [número sequencial] | [nome-da-skill] | [Categoria] | [trigger curto] | [Função 1 linha] | ✓ Ativa |
```

Número sequencial = contar linhas existentes na tabela + 1 (formato: 001, 002, 003...)

---

## Passo 4 — Confirmação ao utilizador

```
✓ Skill [nome] registada com sucesso:
  → Biblioteca: [URL da entrada]
  → SKILL.md: [URL da subpágina]
  → Dashboard: linha [N] adicionada
```

---

## IDs do sistema (reais — não alterar)

| Componente | ID / URL |
|---|---|
| Hub do Sistema | https://www.notion.so/334a986ee0b38145924cdd4e635b2fb2 |
| Biblioteca de Skills | https://www.notion.so/1f270b80ef5540af980b5a7cad2ffdfc |
| Data Source Biblioteca | `65ddf3a0-ad9d-48aa-812e-c87df860277c` |
| Dashboard Operacional | https://www.notion.so/334a986ee0b38137956bf68313e32782 |
| M6 Admin | https://www.notion.so/331a986ee0b381928203ed55d080860c |
| SISTEMA MASTER 2026 | https://www.notion.so/331a986ee0b3810fb55fd355c2263612 |

---

## Categorias disponíveis

| Categoria | Usar para |
|---|---|
| Extração & Estruturação | JSON extract, 5W2H, parsing de documentos |
| Documentos & Ficheiros | DOCX, PDF, PPTX, XLSX |
| Publicação & Sync | Notion, pipelines editoriais |
| Análise & Síntese | Research, síntese estratégica, briefings |
| Workflow & Automação | Meta-skills, orquestrações, pipelines |
| Notion & Sistema | Dashboards, protocolos, sincronização |
| Editorial & Escrita | Frankwatching, artigos, prompts, copywriting |

---

## Troubleshooting

| Problema | Solução |
|---|---|
| Data Source ID não encontrado | Usar Database ID `1f270b80ef5540af980b5a7cad2ffdfc` diretamente |
| Categoria não existe | Usar "Workflow & Automação" como fallback |
| Dashboard não atualiza | Editar page `334a986ee0b38137956bf68313e32782` com update_content |
| SKILL.md muito longo para subpágina | Dividir em secções com cabeçalhos — Notion suporta conteúdo ilimitado |
