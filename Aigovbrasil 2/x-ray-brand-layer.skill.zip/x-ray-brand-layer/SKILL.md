---
name: x-ray-brand-layer
description: Aplica a identidade do consultor X-Ray (nome, cor, logo, fonte) sobre os tokens FORGE em qualquer entregável. ATIVE SEMPRE que houver geração de output destinado ao cliente final (proposta, diagnóstico, ebook, plano de ação, dashboard, slide deck, e-mail, apresentação executiva), ou quando o consultor pedir "aplicar minha brand", "personalizar o output", "trocar para a marca do consultor", "remover branding X-Ray genérico", "white-label", "ajustar cores", "injetar logo do consultor". TAMBÉM ATIVE no momento de configuração inicial via consultant_config.yaml. NÃO ATIVE para outputs internos (rascunhos, decision_log, captura) — esses não vão para o cliente e não precisam de brand layer.
version: 1.0.0
---

# X-Ray Brand Layer

Camada de personalização que pega o output bruto e aplica a identidade visual do consultor antes da entrega ao cliente final. É o "white-labeling" da suite X-Ray.

## Princípio fundamental

O cliente final (Toni) nunca deve ver o nome "X-Ray" em entregáveis. Ele vê apenas o consultor (Rogerinho) e a marca dele. A suite X-Ray é infraestrutura invisível.

## Pipeline de aplicação

```
output bruto → forge-visual-canvas (tokens base) → x-ray-brand-layer (override consultor) → entregável final
```

Esta skill nunca substitui forge-visual-canvas. Ela age depois, sobrescrevendo apenas o que o consultant_config define como override.

## Fontes de verdade

A identidade vem **exclusivamente** de `consultant_config.yaml` no projeto ativo. Nunca infira cor/logo/nome a partir de contexto ou conversa anterior. Se o config não existir, pare e dispare `/x-ray-start`.

```yaml
# Trecho relevante de consultant_config.yaml
brand:
  consultant_name: "Rogerinho Consultoria PME"
  consultant_short: "Rogerinho"
  primary_color: "#1B4D3E"      # override de --forge-orange
  secondary_color: "#C9A961"    # override de --forge-blue
  text_dark: "#0A1F1A"           # override de --forge-dark
  text_light: "#F5F2E8"          # override de --forge-light
  logo_url: "data:image/svg+xml;base64,..."   # ou URL pública
  logo_alt: "Rogerinho Consultoria"
  font_heading: "Poppins"        # mantém FORGE default
  font_body: "Lora"               # mantém FORGE default
  signature_block: |
    Rogerinho Silva
    Consultor PME · CRA-SP 12345
    rogerinho@consultoria.com.br
```

Se um campo de brand estiver vazio no config, mantenha o token FORGE default. Nunca invente cor.

## Aplicação por tipo de entregável

### HTML / Ebook interativo

Substitua as CSS variables no `<style>` ou `:root` block:

```css
:root {
  --consultant-primary: #1B4D3E;     /* lido de config */
  --consultant-secondary: #C9A961;   /* lido de config */
  --consultant-text-dark: #0A1F1A;
  --consultant-text-light: #F5F2E8;
  --consultant-name: "Rogerinho Consultoria PME";
}
```

Toda referência a `--forge-orange` em elementos visíveis ao cliente vira `--consultant-primary`. `--forge-blue` vira `--consultant-secondary`. Tokens estruturais (radius, spacing) permanecem FORGE.

### DOCX (Word)

Aplique via python-docx no momento da geração:
- `RGBColor` de headings = consultant_primary
- `RGBColor` de body = consultant_text_dark
- Logo no header da primeira página
- signature_block no footer da última página

### PPTX (slides)

Master slide com:
- Background: consultant_text_light
- Title color: consultant_primary
- Body text: consultant_text_dark
- Logo no canto superior direito de cada slide

### PDF (export de HTML)

Aplica no HTML antes do "Imprimir → Salvar como PDF". CSS variables fazem o resto automaticamente.

## O que NUNCA é sobrescrito

Tokens estruturais do FORGE permanecem invioláveis:
- Border radius (4/8/12/20/9999)
- Tipografia mínima (11px)
- Pesos permitidos (400, 500, 700, 800 — nunca 600)
- Anti-patterns FORGE (sem gradiente roxo, sem Inter, sem emoji decorativo)

A brand do consultor é cosmética. A integridade visual é estrutural.

## Validação antes de entregar

Antes de marcar um entregável como pronto para cliente, verifique:

```
✓ consultant_config.yaml foi lido nesta sessão?
✓ Todas as ocorrências de "X-Ray" no texto visível foram removidas?
✓ Logo do consultor aparece em pelo menos um lugar (header ou footer)?
✓ Nome do consultor aparece na assinatura?
✓ Cor primária é consultant_primary, não --forge-orange?
✓ Tokens estruturais FORGE preservados (radius, font weights, etc.)?
```

Se qualquer item falhar, o entregável não sai. Corrija e revalide.

## Modo whitelabel total vs co-branded

`consultant_config.yaml` define o modo:

```yaml
brand:
  whitelabel_mode: true   # entregável só mostra consultor
  # ou
  whitelabel_mode: false  # mostra "Powered by X-Ray" no footer minúsculo
```

Modo `false` é útil em casos onde Rogerinho quer transparência metodológica com o cliente. Modo `true` é o default — o cliente vê apenas a marca do consultor.

## Antipattern crítico

NUNCA aplique cores hardcoded de exemplos antigos no output. Toda cor passa pelo config. Se você for tentado a escrever `#1B4D3E` direto no SVG, pare — leia o config primeiro.

## Quando esta skill é insuficiente

Se o consultor pedir customização que vai além de cores/logo/fontes (por exemplo, mudar a estrutura do ebook, adicionar nova seção, redesenhar layout), encaminhe para forge-visual-canvas com instrução explícita. Esta skill é apenas a camada de override de identidade — não é redesenho.
