---
name: research-protocol-diamond
description: Execute structured research with 3P-DIAMANTE framework, epistemic rigor, and same-day actionable outputs. Use for market validation, competitive analysis, strategic decisions requiring 85% data-driven insights.
---

# Research Protocol Diamond

Structured research protocol delivering 85% data-driven insights + same-day executable actions.

## Trigger This Skill For

- Market validation ("Is there demand for X in Brazil?")
- Monetization pathway analysis (freelance vs employment vs product)
- Competitive benchmarking with numerical data
- Strategic decisions requiring fact-based recommendations
- ICP validation with verifiable metrics

## Architecture: 3P-DIAMANTE-WORKFLOW-PRINTODAY

**3P** = Pre-research (normalize request, route framework, note exclusions)
**DIAMANTE** = 7-layer decomposition (Define, Identify, Assumptions, Metrics, Analysis-constraints, No-inference, Trade-offs, Epistemic-tags)
**WORKFLOW** = Phased execution (validation searches → synthesis)
**PRINTODAY** = Same-day action (copy-paste command + validation)

## Output Structure

### Data Section (85%)
```
Q[N]: [Question] | SOURCE: [Citation] | DATA: [Number] | INSIGHT: [10w]
CONFIDENCE: [High|Medium|Low] | TAG: [FACT|HYPOTHESIS|INFERENCE|GAP]
```

### Three Pathways
```
Path A: {speed: "X days to $", scale: "Y/12mo", risk: "H|M|L", tradeoff: "..."}
Path B: {...}
Path C: {...}
Recommendation: [Data-driven choice]
```

### Action Roadmap
```
TODAY 8AM: [Executable step with link]
TODAY 2PM: [Next milestone]
WEEK 1: [Deliverable]
```

## Quality Gates

- [ ] Every claim tagged: FACT | HYPOTHESIS | INFERENCE | GAP
- [ ] 85%+ data numerical + sourced
- [ ] Trade-offs explicit (A loses what from B/C)
- [ ] No-inference limits stated
- [ ] PRINTODAY action copy-paste ready

## Example Triggers

1. "Research Claude skills market Brazil — 85% data validation + 3 monetization paths"
2. "Validate GitHub portfolio vs formal degree for AI jobs — data + today's action"
3. "Compare freelance/employment/product for AI consultant — speed + risk analysis"

See `references/` for framework guides, `templates/` for output structure, `examples/` for full cases.
