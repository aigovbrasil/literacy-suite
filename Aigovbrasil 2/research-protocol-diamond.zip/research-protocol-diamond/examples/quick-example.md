# Example: Market Validation Research

**User Request**: "Research if Claude skills training has market in Brazil"

**Output**:

## PRE-RESEARCH (3P)
- Explicit: Market size for Claude skills training PT-BR
- Implicit: Validation before building course + speed to revenue
- Framework: MECE (market segments) + JTBD (customer progress)

## DIAMANTE
- Problem: "Does viable market exist for Claude skills PT-BR?"
- Variables: Market size (R$), competition (#courses), WTP (price)
- No-inference: Cannot claim demand without survey data
- Trade-off: Focus Brazil = ignore LATAM 5x TAM

## DATA (85%)
Q1: AI education market Brazil 2026?
SOURCE: ABStartups Report 2026
DATA: R$ 2.1B, 35% YoY growth
INSIGHT: Large growing market validates space entry
TAG: FACT

## THREE PATHWAYS
Path A (Freelance): Speed 14 days, Scale R$60k/yr, Risk Medium
Path B (Course): Speed 45 days, Scale R$180k/yr, Risk High
Path C (Employment): Speed 30 days, Scale R$120k/yr, Risk Low

Recommendation: Path C → Path A hybrid (security + upside)

## PRINTODAY
8AM: Create GitHub repo github.com/leo/claude-skills-br
2PM: Upload first skill with README
Validation: Repo visible publicly
