# Trigger Prompts

1. "Research Claude skills market Brazil using diamond protocol"
2. "Validate monetization: freelance vs course vs job — 85% data"
3. "Competitive analysis AI education PT-BR — speed + risk assessment"
4. "Market validation: GitHub portfolio value for AI jobs — data + action"
5. "Research ICP for Claude consulting Brazil — metrics + pathways"
