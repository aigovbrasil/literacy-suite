# Research Protocol Diamond Skill

**Purpose**: Structured research with metacognitive rigor + same-day executable actions

**Architecture**: 3P-DIAMANTE-WORKFLOW-PRINTODAY

**Quality Bar**: 85% numerical data + 15% logical inference

## Quick Start

1. Upload this skill to Claude.ai (Settings → Skills → Upload custom skill)
2. Trigger with: "Research [topic] using diamond protocol — need 85% data validation"
3. Receive: Data-backed analysis + 3 pathways + today's executable action

## What's Included

- `SKILL.md` — Main skill definition with frontmatter
- `references/` — Framework guides
- `templates/` — Output structure templates
- `examples/` — Full case studies
- `tests/` — Trigger prompts + validation

## Installation

```bash
# Via claude.ai web interface
1. Settings → Skills → Upload custom skill
2. Select research-protocol-diamond.zip
3. Skill appears in your custom skills list
```

## Use Cases

- Market validation before product launch
- Career decision analysis (paths comparison)
- Competitive intelligence with benchmarks
- Strategic planning with trade-off analysis

**License**: MIT  
**Version**: 1.0  
**Maintainer**: Created for Leo's power user setup
