---
name: x-ray-onboarding-ebook
description: Gera o ebook interativo X-Ray em HTML standalone para duas rotas — /rogerinho (onboarding do consultor com download da suite) e /toni (entrega do diagnóstico ao cliente final, sem Claude). ATIVE SEMPRE para "gerar ebook X-Ray", "criar ebook de onboarding", "ebook do consultor", "ebook do cliente Toni", "/x-ray-deliver ebook", "/x-ray-deliver ebook-cliente", "ebook interativo X-Ray", "onboarding interativo da suite", "deliverable HTML X-Ray", "package o ebook". TAMBÉM ATIVE quando o consultor mencionar entregar um diagnóstico em formato visual interativo ao cliente, ou quando Leonardo precisar gerar o pacote de boas-vindas para um novo consultor que comprou a suite. NÃO ATIVE para PDFs simples (use forge-visual-canvas + skills/public/pdf), apresentações (use pptx skill), ou outputs de uma única seção isolada.
version: 1.0.0
---

# X-Ray Onboarding Ebook

Gera ebook interativo HTML standalone (single-file, sem dependências externas) com duas rotas de uso:

- **/rogerinho** — onboarding do consultor que comprou a suite X-Ray
- **/toni** — entrega final ao cliente do consultor (cliente nunca usa Claude)

Cada rota tem 4 seções estruturais. O HTML resultante é self-contained: Rogerinho recebe por email/Drive e abre no browser sem instalação.

## Inputs obrigatórios

Antes de gerar o ebook, leia:

1. `consultant_config.yaml` (do projeto ativo) — define brand do consultor
2. `route` — qual rota gerar (`/rogerinho` ou `/toni`)
3. Se rota `/toni`: leia também `source_of_truth.md`, `decision_log.md`, `plano_acao.md` do caso

Se algum input estiver ausente, pare e reporte o que falta. Não invente conteúdo do ebook.

## Estrutura — Rota /rogerinho (4 seções)

| # | Seção | Conteúdo | Fonte |
|---|---|---|---|
| 01 | O que você comprou | Visão geral da suite, lista de skills, valor entregue | template + consultant_config |
| 02 | Como usar a suite | Workflow D0→D5, comandos do orquestrador, gates | x-ray-orchestrator SKILL.md |
| 03 | Configurar seu sistema | Form interativo que gera consultant_config.yaml | template + JS form |
| 04 | Métricas + Download ZIP | Painel de uso + botão de download da suite empacotada | x-ray-skill-packager output |

## Estrutura — Rota /toni (4 seções)

| # | Seção | Conteúdo | Fonte |
|---|---|---|---|
| 01 | Seu diagnóstico | Sumário executivo + key findings | source_of_truth.md + decision_log.md |
| 02 | Seu plano de ação | Timeline visual 5W2H | plano_acao.md |
| 03 | Acompanhar progresso | Executive Office embarcado | x-ray-executive-office (modo cliente) |
| 04 | Próximos passos | CTA para próxima sessão + contato do consultor | consultant_config.signature_block |

## Pipeline de geração

```
1. Leia consultant_config.yaml
2. Leia template HTML base (assets/template-rogerinho.html ou template-toni.html)
3. Leia conteúdo da fonte (caso /toni: source_of_truth + decision_log + plano_acao)
4. Aplique x-ray-brand-layer:
   - Substitua CSS variables com cores do consultor
   - Insira logo no header
   - Insira signature_block no footer
   - Remova qualquer menção visível a "X-Ray" se whitelabel_mode=true
5. Embarque x-ray-executive-office como <iframe srcdoc> ou inline component
6. Para rota /rogerinho: anexe ZIP da suite via base64 data URI no botão de download
7. Salve em /mnt/user-data/outputs/[consultant_short]-ebook-[route].html
8. Apresente via present_files
```

## Brand discipline

- Tokens FORGE são base — nunca remova
- Override apenas via consultant_config (cor primária, logo, fonte heading/body)
- Modo dark/light: ambos suportados, toggle no header
- Tipografia: Poppins (heading) + Lora (body) por default — sobrescrevível via config
- Sem dependências externas: todas as fontes via Google Fonts CDN no `<link>`, ícones via SVG inline

## Anti-patterns

- Não use Inter font (default "AI slop")
- Não use gradientes roxos
- Não use `position:fixed` em widgets que possam ser embarcados em iframe
- Não embed Claude artifacts dentro do ebook /toni — Toni nunca toca Claude
- Não inclua API keys, tokens, ou qualquer credencial no HTML
- Não inclua telemetria ou tracking — entregável é estático e privado

## Estrutura mínima do HTML gerado

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{consultant_name}} — Onboarding | Suite X-Ray</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700;800&family=Lora:wght@400;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --consultant-primary: {{primary_color}};
      --consultant-secondary: {{secondary_color}};
      --consultant-text-dark: {{text_dark}};
      --consultant-text-light: {{text_light}};
      /* + tokens FORGE estruturais */
    }
    /* CSS aplicando todos os tokens */
  </style>
</head>
<body>
  <aside class="sidebar">
    <!-- nav com 4 seções da rota -->
  </aside>
  <main class="content">
    <!-- 4 sections: s1, s2, s3, s4 -->
  </main>
  <script>
    // navegação SPA-like via display:none/block
    // form de config (rota /rogerinho)
    // timeline interativa (rota /toni)
    // executive office embedded
  </script>
</body>
</html>
```

## Padrão de UX (herdado do ASS-01 ebook reference)

- Sidebar fixa à esquerda (largura 280px)
- Mobile: hamburger toggle abaixo de 768px
- Cards expansíveis (accordion) para sub-conteúdo denso
- Phase timeline interativa para mostrar workflow
- Badges coloridos para status (verde/âmbar/vermelho) usando consultant colors
- Touch targets mínimo 44px
- Scroll behavior smooth
- Hover/active states sutis

## Padrão de UX (rota /toni — específico)

Toni recebe um arquivo HTML que abre no browser dele e funciona offline. Não há login, não há servidor, não há Claude. O HTML contém:

- Diagnóstico em prosa executiva (não bullet points densos)
- Plano de ação em timeline visual com responsáveis e prazos
- Executive Office embarcado para acompanhamento de execução
- Botão "Baixar este ebook em PDF" (window.print() trigger)
- Contato do consultor sempre visível (footer fixo no mobile)

## Output paths

- Rota /rogerinho: `/mnt/user-data/outputs/{consultant_short}-onboarding-ebook.html`
- Rota /toni: `/mnt/user-data/outputs/{consultant_short}-cliente-{client_name}-ebook.html`

Sempre apresente o arquivo final via `present_files` para o consultor poder baixar e enviar.

## Quando o ebook precisa de update

A skill é idempotente — rode novamente com o mesmo input e gera o mesmo output. Quando o consultor atualizar o caso (nova decisão, novo risco, novo entregável), regere o ebook /toni — não tente patchear o HTML antigo.

## Relação com outras skills X-Ray

- Lê: consultant_config.yaml (escrito por x-ray-onboarding-ebook Seção 03 ou manualmente)
- Chama: x-ray-brand-layer (aplicação de identidade)
- Embarca: x-ray-executive-office (sprint tracker inline)
- Empacota com: x-ray-skill-packager (rota /rogerinho inclui ZIP da suite)
- Roteado por: x-ray-self-knowledge → x-ray-orchestrator (`/x-ray-deliver`)
