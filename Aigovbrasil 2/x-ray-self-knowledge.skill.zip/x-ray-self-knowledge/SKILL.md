---
name: x-ray-self-knowledge
description: Router de precisão da suite X-Ray — saiba qual skill consultar para qual problema. ATIVE SEMPRE que o consultor (Rogerinho, Leonardo ou clones) perguntar "qual skill X-Ray usar para [tarefa]", "como funciona a suite X-Ray", "o que faz cada skill X-Ray", "diferença entre x-ray-orchestrator e x-ray-abs", "documentação interna X-Ray", "mapa da suite X-Ray", "what does X-Ray do", "X-Ray help", "/x-ray-help", "self-knowledge". TAMBÉM ATIVE quando houver ambiguidade entre duas skills X-Ray — antes de adivinhar, consulte este router. NÃO ATIVE para perguntas sobre produtos Anthropic (use product-self-knowledge nativo) ou para execução de tarefas em si (route via tabela e invoque a skill correta).
version: 1.0.0
---

# X-Ray Self-Knowledge — Router Meta

Função única: dado um problema, retornar qual skill da suite X-Ray resolve. Inspirado em product-self-knowledge da Anthropic, adaptado para a marca X-Ray.

## Princípios centrais

1. **Precisão acima de palpite** — se duas skills parecem candidatas, leia ambas e escolha
2. **Distinguir camadas** — DEV (Anthropic) vs B1 (Leonardo) vs B2 (consultor clonado) vs C (cliente final)
3. **Citar a fonte** — sempre nomeie a skill X-Ray invocada e a versão
4. **Recurso certo primeiro** — não chame skill genérica quando há skill X-Ray específica

## Mapa de roteamento — por tipo de pergunta

### Operação de caso (Rogerinho rodando consultoria)

| Pergunta do consultor | Skill correta |
|---|---|
| "Iniciar caso novo" | x-ray-orchestrator (`/x-ray-start`) |
| "Capturar fato/hipótese/risco" | x-ray-orchestrator (`/captura*`) |
| "Rodar diagnóstico" | x-ray-orchestrator → carrega x-ray-abs |
| "Normalizar para YAML" | x-ray-db |
| "Criar plano de ação" | x-ray-orchestrator (`/x-ray-deliver plano`) |
| "Mandar pro Linear" | x-ray-orchestrator (`/x-ray-execute`) → projects-to-linear |
| "Status do caso" | x-ray-orchestrator (`/status`) |

### Onboarding e setup (Leonardo entrega para Rogerinho, Rogerinho configura)

| Pergunta | Skill correta |
|---|---|
| "Gerar ebook de onboarding para o consultor" | x-ray-onboarding-ebook (rota /rogerinho) |
| "Configurar identidade do consultor" | x-ray-onboarding-ebook (Seção 03) → escreve consultant_config.yaml |
| "Aplicar brand do consultor em entregável" | x-ray-brand-layer |
| "Empacotar a suite para download" | x-ray-skill-packager |
| "Registrar skill no Notion/Drive" | x-ray-publish-register |

### Entrega ao cliente final (Rogerinho → Toni)

| Pergunta | Skill correta |
|---|---|
| "Gerar form de intake para o cliente Toni" | x-ray-client-form |
| "Receber JSON do cliente e abrir caso" | x-ray-orchestrator (`/x-ray-start --import-json`) |
| "Gerar ebook final para o cliente" | x-ray-onboarding-ebook (rota /toni) |
| "Sprint tracker do cliente" | x-ray-executive-office (modo cliente) |
| "Sprint tracker do consultor" | x-ray-executive-office (modo consultor) |

### Diagnóstico estratégico standalone

| Pergunta | Skill correta |
|---|---|
| "Análise estratégica de negócio" | x-ray-abs |
| "Score de priorização I×U×C×F÷(E×R)" | x-ray-abs |
| "Validação causal de hipótese" | x-ray-abs (modo Uncertainty/AREDE) |
| "Canonical Pipeline S00–S20" | x-ray-abs (Canonical Engine) |

### Meta — sobre a suite

| Pergunta | Skill correta |
|---|---|
| "Como funciona a suite X-Ray?" | x-ray-self-knowledge (esta skill) |
| "Criar nova skill X-Ray clonada" | skill-creator + x-ray-skill-packager |
| "Reader-test de skill X-Ray" | doc-coauthoring + skill-reader-test-matrix.md |

## Ambiguidades resolvidas

### x-ray-orchestrator vs x-ray-abs

- **x-ray-orchestrator** é o co-piloto de caso ativo, com gates, captura, decision_log
- **x-ray-abs** é o motor de diagnóstico estratégico, pode rodar standalone fora de caso

Regra: se há um caso aberto com consultant_config.yaml ativo → orchestrator. Se é análise pontual sem caso → abs.

### x-ray-onboarding-ebook (rota Rogerinho) vs (rota Toni)

- **Rota /rogerinho** entrega: o que ele comprou, como configurar, download da suite, métricas de uso
- **Rota /toni** entrega: diagnóstico do cliente, plano visual, executive office embarcado, NUNCA Claude

Regra: o destinatário decide a rota. Rogerinho usa Claude → Rota /rogerinho. Toni nunca toca Claude → Rota /toni.

### x-ray-brand-layer vs forge-visual-canvas

- **forge-visual-canvas** é o motor de render visual genérico (FORGE tokens, 10 linguagens)
- **x-ray-brand-layer** injeta a identidade do consultor (cor, logo, fonte) sobre os tokens FORGE

Regra: forge é o canvas, x-ray-brand-layer é a tinta personalizada. Sempre rode forge primeiro, depois x-ray-brand-layer no topo.

### x-ray-client-form vs zip pattern (Ref_form_in-line-b2c)

- **x-ray-client-form** é a skill que GERA o HTML do form
- O **zip pattern** é a especificação de fluxo (D0→D2: WhatsApp → claude.ai → JSON)

Regra: para criar o HTML, chame a skill. Para entender o fluxo de entrega, leia este documento.

## Versionamento e clonagem

A suite X-Ray segue o padrão DEV→B2B2C:

```
DEV (Anthropic)
  └── skills públicas: skill-creator, brand-guidelines, doc-coauthoring, internal-comms
        │
        └── B1 (Leonardo) — source of truth
              └── skills X-Ray: orchestrator, self-knowledge, brand-layer, etc.
                    │
                    └── B2 (Rogerinho_consultant) — clone personalizado
                          └── skills clonadas: [Rogerinho]_orchestrator, etc.
                                │
                                └── C (cliente Toni) — recebe artefatos finais
                                      └── ebook + form + executive office (zero Claude)
```

Cada clone B2 mantém:
- Mesma estrutura de SKILL.md (DNA do método)
- consultant_config.yaml personalizado (nome, brand, MCPs)
- meta-reference apontando para versão B1 source

Quando uma skill B1 é atualizada, x-ray-publish-register dispara um aviso para todos os clones B2 ativos com diff da versão.

## Como usar este router

1. Identifique o tipo de pergunta (operação / onboarding / entrega / diagnóstico / meta)
2. Localize na tabela correspondente
3. Invoque a skill X-Ray nomeada
4. Se houver ambiguidade, leia a seção "Ambiguidades resolvidas"
5. Se nenhuma tabela cobrir o caso: pergunte ao consultor — não invente

## Referências de origem

| Skill X-Ray | Inspiração Anthropic |
|---|---|
| x-ray-orchestrator | (original — formaliza X-RAY-1 BUSINESS PACK) |
| x-ray-self-knowledge | product-self-knowledge |
| x-ray-brand-layer | brand-guidelines |
| x-ray-onboarding-ebook | doc-coauthoring + forge-visual-canvas + web-artifacts-builder |
| x-ray-client-form | (original — baseado no zip pattern Ref_form_in-line-b2c) |
| x-ray-executive-office | (original — adaptação do TSX remixed) |
| x-ray-skill-packager | skill-creator (etapa de packaging) |
| x-ray-publish-register | skill-publish-and-register |

A herança é declarativa, não cega. Quando a skill Anthropic muda, a skill X-Ray é re-validada via doc-coauthoring Stage 3 antes de propagar.
