---
name: x-ray-skill-packager
description: Empacota a suite X-Ray completa em ZIP único pronto para distribuição ao consultor. Inclui todas as 8 skills, templates, README e instruções de instalação. ATIVE SEMPRE para "empacotar suite X-Ray", "gerar ZIP da suite", "package X-Ray", "preparar entrega para consultor", "/x-ray-package", "build da suite", "criar arquivo de distribuição", "pacote para venda", "ZIP para upload no Claude.ai". TAMBÉM ATIVE quando Leonardo precisar entregar a suite a um novo consultor que comprou, ou quando uma versão atualizada precisar ser redistribuída aos clones existentes. NÃO ATIVE para empacotar uma única skill (use skill-creator package_skill.py).
version: 1.0.0
---

# X-Ray Skill Packager

Empacota a suite X-Ray completa em arquivo ZIP self-contained para distribuição ao consultor que comprou. O ZIP é o que vai dentro do botão "Download da Suite" na Seção 04 do ebook de onboarding.

## Conteúdo do pacote

```
x-ray-suite-v{VERSION}.zip
├── README.md                          # entrada — leia primeiro
├── INSTALL.md                         # como instalar no Claude.ai
├── CHANGELOG.md                       # histórico de versões
├── skills/
│   ├── x-ray-orchestrator/SKILL.md
│   ├── x-ray-self-knowledge/SKILL.md
│   ├── x-ray-brand-layer/SKILL.md
│   ├── x-ray-onboarding-ebook/SKILL.md
│   ├── x-ray-client-form/SKILL.md
│   ├── x-ray-executive-office/SKILL.md
│   ├── x-ray-skill-packager/SKILL.md
│   └── x-ray-publish-register/SKILL.md
├── templates/
│   ├── consultant_config.template.yaml
│   ├── qa_checklist.template.md
│   └── skill-reader-test-matrix.md
└── docs/
    ├── architecture.md                # diagrama da arquitetura DEV→B2B2C
    ├── workflow-d0-d5.md              # fluxo do consultor passo a passo
    ├── gates-G0-G4.md                 # explicação dos gates
    └── epistemic-rules-R01-R05.md     # regras invioláveis
```

## Pipeline de empacotamento

```python
import zipfile, os, json, datetime

def package_suite(version="1.0.0", source_dir="/home/claude/x-ray-suite",
                  output_path="/mnt/user-data/outputs/x-ray-suite-v{version}.zip"):
    output = output_path.format(version=version)

    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zf:
        # 1. Adicione todos os arquivos do source_dir
        for root, dirs, files in os.walk(source_dir):
            # Skip artifacts/ — não vai dentro do ZIP da suite
            if 'artifacts' in root: continue
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, source_dir)
                zf.write(full_path, rel_path)

        # 2. Adicione manifesto da versão
        manifest = {
            "version": version,
            "build_date": datetime.datetime.now().isoformat(),
            "skills": list_skills(source_dir),
            "schema_version": "1.0.0",
            "source": "Leonardo Batista — X-Ray Suite B1"
        }
        zf.writestr("MANIFEST.json", json.dumps(manifest, indent=2))

    return output
```

## Versionamento

A versão segue semver (MAJOR.MINOR.PATCH):

| Tipo de mudança | Incremento |
|---|---|
| Breaking change na estrutura de SKILL.md ou em comandos do orchestrator | MAJOR |
| Nova skill adicionada à suite, ou nova rota no ebook | MINOR |
| Bug fix em SKILL.md, melhoria de descrição, fix de typo | PATCH |

A versão atual vive em `/home/claude/x-ray-suite/VERSION` (single line).

## Instalação no Claude.ai (instruções para Rogerinho)

O ZIP é baixado pelo consultor a partir do ebook de onboarding (Seção 04). Depois:

```
1. Descompactar o ZIP em qualquer pasta local
2. Abrir Claude.ai → Settings → Skills (em desktop ou web)
3. Para cada skill em skills/:
   3.1. Click em "Add Skill" → "Upload from folder"
   3.2. Selecionar a pasta da skill (ex: skills/x-ray-orchestrator/)
   3.3. Confirmar instalação
4. Repetir para todas as 8 skills
5. Criar um Project no Claude.ai chamado "{Nome do Consultor} — Casos X-Ray"
6. Anexar todas as 8 skills ao Project
7. Subir consultant_config.yaml (gerado na Seção 03 do ebook) ao Project como anexo
8. Pronto — chamar `/x-ray-start` em qualquer chat dentro do Project ativa o orchestrator
```

INSTALL.md no ZIP traz essa sequência com screenshots e troubleshooting.

## README.md do pacote — conteúdo mínimo

```markdown
# Suite X-Ray — v{VERSION}

Sistema operacional para consultoria PME, baseado em Claude.ai + MCP.

## O que está incluído
- 8 skills modulares (orchestrator + 7 satélites)
- Templates de configuração e QA
- Documentação de arquitetura e workflow

## Próximos passos
1. Leia INSTALL.md
2. Configure seu consultant_config.yaml (Seção 03 do ebook)
3. Rode /x-ray-start no seu primeiro caso

## Suporte
Leonardo Batista — leonardo@xray.suite
Versão: {VERSION} · Build: {BUILD_DATE}
```

## CHANGELOG.md — formato

```markdown
# Changelog X-Ray Suite

## [1.0.0] - 2026-05-XX
### Added
- 8 skills core (orchestrator, self-knowledge, brand-layer, onboarding-ebook, client-form, executive-office, skill-packager, publish-register)
- Templates de consultant_config e qa_checklist
- Documentação de arquitetura DEV→B2B2C

### Notes
- MVP commercial v1
- Compatibilidade: Claude.ai Pro + MCP (Linear, Drive, Slack)
```

## Quando atualizar e redistribuir

Triggers para nova versão:
- Mudança em SKILL.md de qualquer skill core
- Nova skill adicionada
- Bug crítico identificado em production (consultor B2)
- Mudança em consultant_config.yaml schema

Após gerar nova versão:
1. Atualize VERSION
2. Atualize CHANGELOG.md
3. Rode esta skill (x-ray-skill-packager) → gera novo ZIP
4. Invoque x-ray-publish-register para notificar clones B2 ativos
5. Atualize a Seção 04 do ebook de onboarding com link do novo ZIP

## Validação pré-empacotamento

```
✓ Todas as 8 SKILL.md existem e têm YAML frontmatter válido (name + description)
✓ VERSION está incrementada se houve mudanças
✓ CHANGELOG.md tem entrada para a nova versão
✓ INSTALL.md está atualizado
✓ Templates não contêm dados pessoais (nomes, emails reais de testes)
✓ Nenhum arquivo .DS_Store, .pyc, __pycache__, ou similar de OS
✓ ZIP final pesa < 5MB (suite enxuta)
```

## Output path

`/mnt/user-data/outputs/x-ray-suite-v{VERSION}.zip`

Após gerar, apresente via `present_files` ao Leonardo (ou ao consultor que está atualizando uma versão pra B2).

## Anti-patterns

- Não inclua artifacts/ (HTMLs gerados) no ZIP — esses são por-sessão, não fazem parte da suite
- Não inclua consultant_config.yaml com dados reais — apenas o template
- Não inclua tokens, API keys ou credenciais
- Não use `zipfile.ZIP_STORED` (sem compressão) — sempre `ZIP_DEFLATED`
- Não esqueça do MANIFEST.json — é a fonte de verdade da versão dentro do ZIP

## Relação com outras skills X-Ray

- Empacota: todas as 8 skills + templates + docs
- Output consumido por: x-ray-onboarding-ebook (Seção 04 — Download)
- Notificação após build: x-ray-publish-register
- Roteado por: x-ray-self-knowledge → x-ray-orchestrator (`/x-ray-package`)
