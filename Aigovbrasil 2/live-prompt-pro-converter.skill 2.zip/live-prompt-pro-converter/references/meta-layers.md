# Meta-Layers — L11, L12, Stopping, Confidence, Completeness

Read this file at STEP 7 of the execution flow.

---

## Section 6: L11 — Adversarial Self-Critique Protocol

After completing output_v1 in STEP 6, execute this protocol exactly.

```
PERSONA SWITCH: You are now a DIFFERENT entity.
You are a senior Anthropic AI systems engineer.
You have NEVER seen this output before.
You have NO attachment to what was produced.
Your sole function is to find every flaw.
You will be evaluated on the quality of your critique, not on the
quality of the output — finding flaws is success for you.

Audit output_v1 against these 7 axes. For each finding, assign severity:
✗ = must fix before delivery
⚠ = should fix or declare as known limitation

AXIS 1 — COMPLETENESS
List every explicit element from the original raw_prompt.
Check each: ✓ addressed / ✗ missing / ⚠ partial.

AXIS 2 — CONSISTENCY
Are there internal contradictions in the output?
Does any instruction conflict with another?
List each contradiction.

AXIS 3 — EXECUTABILITY
Can this be deployed exactly as written, with zero additional work?
What specifically requires additional specification to execute?

AXIS 4 — TECHNICAL CORRECTNESS
Are any claims, model names, API parameters, or technical details
wrong or outdated? List each error.

AXIS 5 — GAPS
What would a world-class practitioner in [DOMAIN_INJECTED] add
that is absent here? List top 3 gaps maximum.

AXIS 6 — EDGE CASES
What breaks this output under non-ideal conditions?
(missing context, adversarial input, ambiguous instructions, scale)
List each failure mode.

AXIS 7 — SIMPLICITY CHECK
Is there a simpler solution that achieves the same goal
that was overlooked? Describe it if yes.

OUTPUT FORMAT:
| Axis | Finding | Severity |
|------|---------|----------|
| ... | ... | ✗/⚠ |
```

---

## Section 7: L12 — Refinement Pass Protocol

After completing L11 critique, execute this protocol exactly.

```
PERSONA SWITCH: You are the AUTHOR again.
You have read the adversarial critique.
You accept every ✗ finding as a mandatory fix.
You accept every ⚠ finding as requiring either a fix or a
justified known limitation declaration.

FOR EACH FINDING:
1. Apply the fix directly to the output
2. Log the change in the delta table

DELTA LOG FORMAT:
| Finding | Fix Applied | Why This Resolves It |
|---------|-------------|---------------------|
| ... | ... | ... |

KNOWN LIMITATION FORMAT (for ⚠ not fixed):
| Finding | Why Not Fixed | Impact | Workaround |
|---------|---------------|--------|------------|
| ... | ... | ... | ... |

After applying all fixes, produce output_v2.
output_v2 replaces output_v1 as the current working output.
```

---

## Section 8: Stopping Criterion & Iteration Control

```
STOP when ALL of the following are true:
  ✓ All ✗ findings from L11 are resolved in L12
  ✓ All ⚠ findings are either resolved or declared as known limitations
  ✓ iteration_count ≤ 3

CONTINUE (return to STEP 7) when:
  ✗ Any ✗ finding remains unresolved
  AND iteration_count < 3

FORCE STOP at iteration_count = 3:
  All remaining issues declared as known limitations.
  Append to output: "REACHED MAXIMUM ITERATIONS. Remaining known
  limitations are listed in the known_limitations field."

iteration_count starts at 1 at first L11 execution.
Increment by 1 each time L11 is re-executed.
```

---

## Section 9: Confidence Scoring Protocol

After stopping criterion is met, score each major section:

| **Level** | **Criteria** |
|---|---|
| HIGH | Complete, unambiguous, technically verified, immediately executable |
| MEDIUM | Complete but contains at least one declared assumption or ⚠ limitation |
| LOW | Incomplete, contains unresolved ambiguity, or requires external validation |

Apply to: system_message, user_message, detection_result, placeholder_resolution, output_spec.

---

## Section 10: Completeness Audit Protocol

```
List every explicit requirement from the original raw_prompt.
For each requirement:
  ✓ = fully addressed in final output
  ✗ = not addressed → apply fix or declare known limitation
  ⚠ = partially addressed → declare what is missing

If any ✗ remains after this audit: return to L12 for one final fix pass
(does not increment iteration_count).
```
