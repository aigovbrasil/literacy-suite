# Few-Shot Examples, Anti-Patterns & Known Limitations

Read this file as needed for reference during execution.

---

## Section 14: Few-Shot Examples

### Example 1: FACTUAL — Simple Question

**raw_prompt (PT-BR):** `"o que é adaptive thinking no claude?"`

**Execution trace:**
- Score: 1 (single question, factual)
- Type: FACTUAL
- Translation: EN
- Layers: L1, L6, L9
- Already-upgraded: false

**Output:**
```json
{
  "detection": {
    "type": "FACTUAL",
    "score": 1,
    "signals_found": ["single question", "no subtasks"],
    "ambiguities_declared": [],
    "recommended_model": "claude-haiku-4-5-20251001"
  },
  "layers_activated": {"primary": ["L1", "L6", "L9"], "meta": ["L11", "L12"]},
  "upgraded_prompt": {
    "system_message": "You are an expert in Anthropic Claude architecture and capabilities. Answer precisely and concisely. If uncertain about any technical detail, state it explicitly rather than guessing.",
    "user_message": "What is Adaptive Thinking in Claude 4.x models, and how does it differ from Extended Thinking? If any aspect of your answer is uncertain or approximate, declare it explicitly.",
    "prefill": null,
    "cache_control": null
  },
  "confidence_scores": {"overall": "HIGH"},
  "summary_pt_br": "Pergunta factual simples detectada (score 1). Traduzida do PT-BR para EN. Aplicadas 3 camadas: role injection, output spec, uncertainty protocol. Roteado para Haiku por eficiência de custo. Nenhuma ambiguidade detectada."
}
```

---

### Example 2: ANALYSIS — Document Review

**raw_prompt (PT-BR):** `"analisa esse contrato e me diz os riscos legais e financeiros"`

**Execution trace:**
- Score: 6 (analyze+3, review+3)
- Type: ANALYSIS
- Layers: L1, L2, L3, L4, L6, L7, L8, L9
- Ambiguity: document not provided

**Output:**
```json
{
  "detection": {
    "type": "ANALYSIS",
    "score": 6,
    "signals_found": ["analyze", "evaluate", "multi-dimensional (legal+financial)"],
    "ambiguities_declared": ["Document content not provided — template prepared, user must insert contract text"],
    "recommended_model": "claude-sonnet-4-6"
  },
  "upgraded_prompt": {
    "system_message": "You are a senior expert in legal and financial contract analysis. Your analysis will inform a risk assessment and business decision. Separate confirmed risks from potential risks. Separate legal risks from financial risks. Surface non-obvious risks. Note: this is analytical observation only, not legal advice.",
    "user_message": "<context>\n  <document index=\"1\">[INSERT CONTRACT TEXT HERE]</document>\n</context>\n\nReason step by step in <thinking> tags:\n  1. Identify contract type, parties, jurisdiction, and governing law\n  2. Audit each clause for legal risk: liability caps, indemnification, IP assignment, termination rights, exclusivity, penalties\n  3. Audit each clause for financial risk: payment terms, price escalation, penalties, hidden costs, currency exposure\n  4. Identify missing standard protections for each risk category\n  5. Identify ambiguous language that could be exploited adversarially\n\nProduce structured risk analysis in <answer> tags:\n- Risk table: Risk | Category | Clause | Severity (High/Med/Low) | Probability | Recommended Mitigation\n- Missing protections list\n- Ambiguities requiring legal counsel\n\nIf uncertain about any finding: label it explicitly as [UNCERTAIN] in the table.\n\n[QUERY: Analyze this contract and identify all legal and financial risks]",
    "prefill": "<thinking>",
    "cache_control": {"apply_to": "system_message", "type": "ephemeral"}
  },
  "confidence_scores": {"overall": "MEDIUM"},
  "summary_pt_br": "Tarefa de análise multi-dimensional detectada (score 6). Traduzida do PT-BR para EN. 8 camadas ativadas incluindo CoT em 5 etapas e adaptive thinking. ATENÇÃO: o documento do contrato não foi fornecido — o campo [INSERT CONTRACT TEXT HERE] deve ser preenchido antes de enviar ao modelo. Roteado para Sonnet 4.6."
}
```

---

### Example 3: COMPLEX — Full Hyperautomation

**raw_prompt (PT-BR):**
`"cria um sistema completo de onboarding automatizado para novos clientes integrando CRM, email e slack, com tratamento de erros e monitoramento"`

**Execution trace:**
- Score: 11 (automate+4, workflow+4, integrate+4, multi-step+3)
- Type: COMPLEX
- All 10 primary layers + L11 + L12
- Ambiguities: CRM platform unspecified, email provider unspecified

**Output:**
```json
{
  "detection": {
    "type": "COMPLEX",
    "score": 11,
    "signals_found": ["automate", "workflow", "integrate", "multi-step", "monitoring", "error handling"],
    "ambiguities_declared": [
      "CRM platform not specified (Salesforce? HubSpot? other?)",
      "Email provider not specified (Gmail? SendGrid? other?)",
      "Slack workspace configuration not specified",
      "Onboarding completion criteria not defined"
    ],
    "recommended_model": "claude-opus-4-6"
  },
  "layers_activated": {
    "primary": ["L1","L2","L3","L4","L5","L6","L7","L8","L9","L10"],
    "meta": ["L11","L12"]
  },
  "upgraded_prompt": {
    "system_message": "You are a world-class automation architect specializing in enterprise hyperautomation systems (PIPILONES architecture). You design complete, production-ready, end-to-end automated workflows. You think in full systems: triggers, conditions, actions, error handling, rollbacks, retry logic, dead-letter queues, monitoring, and alerting. Every workflow you design is immediately deployable and handles failure modes explicitly. You never assume a happy path without defining its failure recovery.",
    "user_message": "<context>\n  <document index=\"1\">[ENVIRONMENT SPEC — insert available integrations, API credentials context, and existing system architecture if available]</document>\n</context>\n\nCRITICAL AMBIGUITIES — state your assumptions explicitly for each:\n- CRM platform: which system? (affects API patterns)\n- Email provider: which service? (affects deliverability and templating)\n- Slack workspace: bot permissions available?\n- Onboarding completion: what defines a successfully onboarded customer?\n\nReason exhaustively in <thinking> tags:\n  1. Map the complete customer onboarding journey: all states from lead→active\n  2. Design triggers for each state transition\n  3. Specify CRM actions: record creation, field updates, stage transitions\n  4. Specify email sequence: triggers, timing, content requirements, personalization\n  5. Specify Slack notifications: channels, message formats, escalation paths\n  6. Design error handling for each integration: retry policy, dead-letter handling, fallback\n  7. Design monitoring: what to track, alert thresholds, dashboard requirements\n  8. Identify race conditions and design mutex/idempotency controls\n  9. Define rollback procedures for each critical failure point\n  10. Validate: does this cover 100% of the specified scope with no gaps?\n\nProduce complete system specification in <answer> tags:\n- Workflow state diagram (text-based)\n- Complete implementation spec per integration\n- Error handling matrix: Step | Error Type | Retry Policy | Fallback | Alert\n- Monitoring checklist\n- Deployment prerequisites\n\n[NEXT SKILL HOOK]: Pass complete spec to implementation skill for code generation.\n\n[QUERY: Design complete automated customer onboarding system integrating CRM, email, and Slack with full error handling and monitoring]",
    "prefill": "<thinking>",
    "cache_control": {"apply_to": "system_message", "type": "ephemeral"}
  },
  "confidence_scores": {
    "system_message": "HIGH",
    "user_message": "MEDIUM",
    "detection": "HIGH",
    "overall": "MEDIUM"
  },
  "summary_pt_br": "Tarefa COMPLEX de alta complexidade detectada (score 11). Todas as 10 camadas primárias ativadas + L11/L12. 4 ambiguidades críticas declaradas no prompt — o modelo vai assumir premissas e listá-las explicitamente. CoT em 10 etapas cobre design completo do sistema. Integration hook incluído para skill downstream de geração de código. Roteado para Opus 4.6. Confiança geral MEDIUM devido às ambiguidades não resolvidas sobre plataformas específicas."
}
```

---

## Section 15: Anti-Patterns

| **Anti-Pattern** | **Por Que Falha** | **Correção** |
|---|---|---|
| Prompt técnico em PT-BR | Reasoning subótimo em não-inglês | → Sempre EN no system_message e user_message |
| system_message e user_message misturados | Reduz precisão de seguimento | → Sempre separar |
| Placeholders não resolvidos no output | Quebra execução downstream | → Resolver ou declarar como ambiguidade |
| Skill chamando a si mesma | Circular dependency → loop infinito | → Self-exemption arquitetural |
| L11 genérico ("revise seu output") | Sycophantic loop — confirma o que já fez | → Persona separada + 7 eixos específicos |
| Budget de tokens acima de 32K sem necessidade | Diminishing returns + custo | → Usar adaptive thinking, não budget fixo |
| Cache control ausente em prompts longos | Custo alto em pipelines repetitivos | → Sempre aplicar em system_message >750 tokens |
| Sem critério de parada no loop L11/L12 | Loop infinito ou parada prematura | → Stopping criterion + max 3 iterações |
| Tags `<document>` vazias | Confunde modelo, pode gerar alucinação | → Remover bloco inteiro se sem contexto |
| Query no início do prompt | Contexto vem depois → qualidade -30% | → Query sempre como último elemento |

---

## Section 16: Known Limitations

| **Limitation** | **Impacto** | **Workaround** |
|---|---|---|
| JSON output schema é overkill para uso conversacional | Overhead desnecessário em invocações diretas | → Modo conversacional simplificado (Output Schema, Conversational Invocation) |
| Placeholder resolution depende de inferência semântica | Pode resolver incorretamente em prompts ambíguos | → Ambiguidades sempre declaradas no output |
| L11/L12 loop não elimina todos os problemas em 3 iterações | Qualidade máxima pode requerer iteração manual | → Declare remaining issues; usuário pode re-invocar |
| Streaming/LIVE não suportado via JSON schema | Outputs longos não streamam | → Usar modo conversacional |
| Não valida se modelo recomendado está disponível | Pode recomendar modelo indisponível | → Fallback: claude-sonnet-4-6 |
