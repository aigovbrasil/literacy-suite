# Output Schema & Integration Protocol

Read this file at STEP 12 of the execution flow.

---

## Section 11: Output Schema

```json
{
  "version": "3.0.0",
  "detection": {
    "type": "COMPLEX|ANALYSIS|CREATIVE|AGENTIC|FACTUAL",
    "score": 0,
    "signals_found": ["signal1", "signal2"],
    "ambiguities_declared": ["ambiguity1"],
    "recommended_model": "claude-opus-4-6",
    "already_upgraded": false
  },
  "layers_activated": {
    "primary": ["L1", "L2", "L3", "L4", "L6", "L7", "L8", "L9", "L10"],
    "meta": ["L11", "L12"]
  },
  "placeholders_resolved": {
    "DOMAIN_INJECTED": "resolved value",
    "PURPOSE_INJECTED": "resolved value",
    "QUERY_INJECTED": "resolved value"
  },
  "upgraded_prompt": {
    "system_message": "...(English)...",
    "user_message": "...(English, XML structured)...",
    "prefill": "<thinking>",
    "cache_control": {
      "apply_to": "system_message",
      "type": "ephemeral"
    }
  },
  "meta_layer_results": {
    "iterations": 1,
    "critique_table": [],
    "delta_log": [],
    "known_limitations": []
  },
  "confidence_scores": {
    "system_message": "HIGH|MEDIUM|LOW",
    "user_message": "HIGH|MEDIUM|LOW",
    "detection": "HIGH|MEDIUM|LOW",
    "overall": "HIGH|MEDIUM|LOW"
  },
  "completeness_audit": [
    {"requirement": "...", "status": "✓|✗|⚠", "note": "..."}
  ],
  "summary_pt_br": "Resumo em português claro do que foi feito, por quê, e o que o usuário precisa saber."
}
```

### Conversational Invocation (non-pipeline)

When called directly in conversation (not via pipeline JSON),
skip JSON wrapper. Deliver:

1. `summary_pt_br` as natural language explanation
2. `system_message` in a labeled code block
3. `user_message` in a labeled code block
4. Any declared ambiguities or known limitations as a table
5. Ask user: (A) Aplicar agora, (B) Apenas copiar, (C) Ajustar algo

---

## Section 12: Integration Protocol

### 12.1 How Other Skills Call This Skill

Any skill in the PIPILONES architecture must include this block
at the start of its own execution instructions:

```
PRE-EXECUTION REQUIREMENT:
Before executing this skill's primary function, call
live-prompt-pro-converter with:
  - raw_prompt: [the user's task or instruction for this skill]
  - context: [any documents or data available]
  - downstream_skill: [name of this current skill]

Use the returned upgraded_prompt.system_message and
upgraded_prompt.user_message for all subsequent Claude API calls
within this skill's execution.

EXCEPTION: If live-prompt-pro-converter returns
already_upgraded: true, use the prompt as-is.
```

### 12.2 Pipeline Pattern

```
User request arrives at Skill A
  → Skill A calls live-prompt-pro-converter(raw_prompt, context, "skill_a")
  → Converter executes 13-step flow
  → Returns upgraded_prompt JSON
  → Skill A uses system_message as system role
  → Skill A uses user_message as user role
  → Skill A sends to recommended_model
  → Skill A processes result
  → If chained: result passed to next skill
  → Final output delivered to user in PT-BR
```

### 12.3 Calling from Another SKILL.md

When another skill's SKILL.md references this skill, it uses:

```
Call skill: live-prompt-pro-converter
Pass: {raw_prompt: [current task], context: [current context]}
Receive: upgraded_prompt object
Use: upgraded_prompt.system_message + upgraded_prompt.user_message
```
