#!/usr/bin/env python3
"""
Batch Skill Builder
===================

Converte até 20 arquivos/pastas brutas em pacotes de skill padronizados.

Saída por item:
- pasta normalizada da skill
- .zip por skill
- .skill por skill, opcional e habilitado por padrão
- relatório batch em CSV, JSON e Markdown

Sem dependências externas obrigatórias. Compatível com Python 3.10+.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import plistlib
import re
import shutil
import sys
import textwrap
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Tuple

REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "manifest.json",
    "docs/FRAMEWORK.md",
    "docs/RISK_BOUNDARY.md",
    "docs/VALIDATION.md",
    "references/sources.md",
    "references/metrics.md",
    "schemas/output_schema.json",
    "examples/sample_input.md",
    "tests/smoke_test.py",
]

TEXT_EXTENSIONS = {
    ".md", ".txt", ".py", ".json", ".csv", ".html", ".htm", ".xml", ".yaml", ".yml",
    ".toml", ".js", ".ts", ".tsx", ".jsx", ".css", ".sql", ".sh", ".zsh", ".bash",
    ".webarchive",
}

SENSITIVE_KEYWORDS = {
    "health": ["adhd", "tdah", "medical", "clinical", "diagnosis", "medication", "therapy", "mental health"],
    "legal": ["legal", "law", "contract", "court", "compliance", "regulation", "lgpd", "gdpr"],
    "finance": ["finance", "financial", "investment", "trading", "tax", "valuation", "accounting"],
    "security": ["password", "credential", "secret", "token", "exploit", "vulnerability", "security"],
}

DEFAULT_TAGS = ["#workflow", "#ai", "#execution"]


@dataclass
class BuildResult:
    index: int
    input_path: str
    slug: str
    title: str
    input_kind: str
    skill_dir: str
    zip_path: str
    skill_path: str
    status: str
    warnings: str
    errors: str


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def slugify(value: str, max_len: int = 72) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = re.sub(r"-+", "-", value).strip("-")
    if not value:
        value = "untitled-skill"
    return value[:max_len].strip("-") or "untitled-skill"


def titleize(value: str) -> str:
    base = Path(value).stem if Path(value).suffix else Path(value).name
    base = re.sub(r"[-_]+", " ", base).strip()
    base = re.sub(r"\s+", " ", base)
    return base.title() if base else "Untitled Skill"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_read_text(path: Path, max_chars: int = 120_000) -> str:
    try:
        if path.suffix.lower() == ".webarchive":
            return read_webarchive(path, max_chars=max_chars)
        data = path.read_bytes()[: max_chars * 3]
        return data.decode("utf-8", errors="ignore")[:max_chars]
    except Exception:
        return ""


def read_webarchive(path: Path, max_chars: int = 120_000) -> str:
    try:
        with path.open("rb") as f:
            obj = plistlib.load(f)
        main = obj.get("WebMainResource", {}) if isinstance(obj, dict) else {}
        data = main.get("WebResourceData", b"")
        if isinstance(data, bytes):
            return data.decode("utf-8", errors="ignore")[:max_chars]
        return str(data)[:max_chars]
    except Exception:
        data = path.read_bytes()[: max_chars * 3]
        return data.decode("utf-8", errors="ignore")[:max_chars]


def collect_inputs(inputs: List[str], limit: int) -> List[Path]:
    found: List[Path] = []
    for raw in inputs:
        p = Path(raw).expanduser().resolve()
        if not p.exists():
            raise FileNotFoundError(f"Input não encontrado: {p}")
        if p.is_dir():
            children = sorted([x for x in p.iterdir() if not x.name.startswith(".")], key=lambda x: x.name.lower())
            found.extend(children)
        else:
            found.append(p)
    deduped: List[Path] = []
    seen = set()
    for item in found:
        key = str(item.resolve())
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    if len(deduped) > limit:
        raise ValueError(f"Foram encontrados {len(deduped)} inputs, mas o limite é {limit}. Reduza a pasta ou aumente --limit até no máximo 20.")
    if limit > 20:
        raise ValueError("Limite máximo permitido: 20 skills por execução.")
    return deduped


def input_kind(path: Path) -> str:
    if path.is_dir():
        return "directory"
    ext = path.suffix.lower().lstrip(".") or "file"
    if ext == "skill":
        return "skill-package"
    if ext == "zip":
        return "zip-archive"
    return ext


def copy_source(input_path: Path, skill_dir: Path, warnings: List[str]) -> Path:
    source_dir = skill_dir / "source" / "original_files"
    source_dir.mkdir(parents=True, exist_ok=True)
    if input_path.is_dir():
        target = source_dir / input_path.name
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(input_path, target, ignore=shutil.ignore_patterns(".git", "__pycache__", ".DS_Store"))
    else:
        target = source_dir / input_path.name
        shutil.copy2(input_path, target)
    extracted_dir = skill_dir / "source" / "extracted"
    if input_path.is_file() and input_path.suffix.lower() in {".zip", ".skill"}:
        try:
            extracted_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(input_path, "r") as zf:
                zf.extractall(extracted_dir)
        except Exception as exc:
            warnings.append(f"Não foi possível extrair arquivo compactado: {exc}")
    return source_dir


def iter_text_files(root: Path) -> Iterable[Path]:
    if root.is_file():
        if root.suffix.lower() in TEXT_EXTENSIONS:
            yield root
        return
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in TEXT_EXTENSIONS:
            if any(part in {".git", "__pycache__", "node_modules", ".venv", "venv"} for part in p.parts):
                continue
            yield p


def build_corpus(skill_dir: Path, max_files: int = 60, max_chars: int = 180_000) -> str:
    chunks: List[str] = []
    total = 0
    roots = [skill_dir / "source" / "original_files", skill_dir / "source" / "extracted"]
    for root in roots:
        if not root.exists():
            continue
        for file in list(iter_text_files(root))[:max_files]:
            txt = safe_read_text(file, max_chars=20_000).strip()
            if not txt:
                continue
            rel = file.relative_to(skill_dir)
            block = f"\n\n--- FILE: {rel} ---\n{txt[:20_000]}"
            if total + len(block) > max_chars:
                return "".join(chunks)
            chunks.append(block)
            total += len(block)
    return "".join(chunks)


def detect_domain(title: str, corpus: str) -> Tuple[str, List[str], List[str]]:
    text = f"{title}\n{corpus}".lower()
    warnings: List[str] = []
    tags = list(DEFAULT_TAGS)
    domain = "workflow"
    if any(k in text for k in ["prompt", "llm", "ai", "claude", "chatgpt", "agent"]):
        domain = "ai-workflow"
        tags.extend(["#product", "#data"])
    if any(k in text for k in ["dashboard", "ops", "admin", "sprint", "linear", "agenda"]):
        domain = "operations"
        tags.extend(["#ops", "#workflow"])
    for area, keys in SENSITIVE_KEYWORDS.items():
        if any(k in text for k in keys):
            warnings.append(f"Conteúdo potencialmente sensível detectado: {area}. Incluir boundary explícito.")
            if area == "health":
                tags.append("#risk")
            elif area == "finance":
                tags.append("#finance")
            elif area == "legal":
                tags.append("#risk")
            elif area == "security":
                tags.append("#risk")
    tags = sorted(set(tags), key=tags.index)
    return domain, tags, warnings


def summarize_source(corpus: str, fallback_title: str) -> str:
    clean = re.sub(r"<[^>]+>", " ", corpus)
    clean = re.sub(r"\s+", " ", clean).strip()
    if not clean:
        return f"Skill criada a partir de {fallback_title}. Descrição detalhada deve ser refinada após revisão humana."
    sentences = re.split(r"(?<=[.!?])\s+", clean)
    selected = []
    for s in sentences:
        if 40 <= len(s) <= 260:
            selected.append(s)
        if len(selected) >= 3:
            break
    return " ".join(selected)[:700] or clean[:700]


def make_dirs(skill_dir: Path) -> None:
    for d in ["docs", "references", "schemas", "scripts", "examples", "tests", "source/original_files"]:
        (skill_dir / d).mkdir(parents=True, exist_ok=True)


def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.strip() + "\n", encoding="utf-8")


def render_skill_md(title: str, slug: str, domain: str, tags: List[str], summary: str) -> str:
    return f"""
# {title}

## Description

{summary}

This skill normalizes a raw workflow, document set, script, archive, or operational method into a reusable `SKILL.md` package.

## When to use

Use this skill when the user needs to:

- convert a raw file, ZIP, script, workbook, note, or workflow into a structured skill;
- preserve original source files while creating clean operational documentation;
- produce a reusable package with `SKILL.md`, README, manifest, schemas, examples, tests, references, and validation notes;
- document a workflow using Executive Summary, 5W2H, ICP, applicability examples, risks, mitigations, and validation criteria.

## Inputs

Accepted inputs may include:

- Markdown, TXT, JSON, CSV, HTML, WebArchive, Python scripts, ZIP archives, `.skill` packages, folders, and supporting files;
- rough prompts, workflow notes, research artifacts, dashboards, operational checklists, or source code;
- project-specific constraints, if provided by the user.

## Output contract

The skill should produce or maintain this structure:

```text
{slug}/
├── SKILL.md
├── README.md
├── manifest.json
├── docs/
│   ├── FRAMEWORK.md
│   ├── RISK_BOUNDARY.md
│   └── VALIDATION.md
├── references/
│   ├── metrics.md
│   └── sources.md
├── schemas/
│   └── output_schema.json
├── scripts/
│   └── main.py
├── examples/
│   └── sample_input.md
├── tests/
│   └── smoke_test.py
└── source/
    └── original_files/
```

## Workflow

1. Inspect the source files.
2. Identify the primary goal, domain, user, inputs, outputs, risks, and expected deliverables.
3. Preserve all original files under `source/original_files/`.
4. Generate the standard documentation package.
5. Add a risk boundary when the domain is medical, legal, financial, security-sensitive, or otherwise high-stakes.
6. Validate required files, JSON syntax, Python syntax where applicable, and package integrity.
7. Return one ZIP per skill and, when requested, a `.skill` package.

## Documentation framework

Each generated README must include:

- Resumo Executivo
- 5W2H
- ICP
- 3 exemplos distintos de aplicabilidade
- Entradas
- Saídas
- Riscos
- Mitigações
- Validação
- Próximos passos

## Metadata

| Field | Value |
|---|---|
| Slug | `{slug}` |
| Domain | `{domain}` |
| Tags | `{', '.join(tags)}` |
| Status | Draft |

## Safety and quality rules

- Do not invent missing source facts. Mark unknowns as `TBD`.
- Separate facts, assumptions, risks, metrics, tasks, and decisions.
- For sensitive domains, include a non-clinical, non-legal, non-financial, or non-security boundary as appropriate.
- Prefer concise operational language.
- Preserve source files for auditability.
"""


def render_readme(title: str, slug: str, domain: str, tags: List[str], summary: str) -> str:
    return f"""
# {title}

## Resumo executivo

{summary}

Esta skill transforma um material bruto em um pacote operacional reutilizável. O foco é documentação prática, preservação da fonte, padronização `SKILL.md`, validação mínima e entrega em ZIP individual.

## 5W2H

| Elemento | Resposta |
|---|---|
| What / O quê | Skill para normalizar e operar o workflow `{title}`. |
| Why / Por quê | Reduzir ruído, preservar contexto e transformar material bruto em pacote reutilizável. |
| Who / Quem | Power users de IA, pesquisadores, builders, consultores, operadores e equipes internas. |
| Where / Onde | Claude Code, Claude.ai Projects, repositório GitHub, workspace local ou vault de conhecimento. |
| When / Quando | Quando um arquivo, método, script ou ZIP precisa virar skill padronizada. |
| How / Como | Gerando `SKILL.md`, README, manifest, docs, schemas, exemplos, testes e pacote final. |
| How much / Quanto | Baixo custo técnico; depende do volume e revisão humana necessária. |

## ICP

| Campo | Definição |
|---|---|
| Perfil ideal | Usuário que cria muitos workflows, prompts, scripts, dashboards ou métodos internos. |
| Dor central | Conteúdo útil fica solto, sem estrutura, sem documentação e sem reuso. |
| Desejo | Converter conhecimento bruto em pacote operacional, versionável e reutilizável. |
| Melhor contexto | Skills internas, automações, pesquisa aplicada, playbooks, GitHub, Claude.ai Projects. |
| Não ideal para | Usuário que só precisa de uma resposta única, sem reuso futuro. |

## 3 exemplos distintos de aplicabilidade

| Exemplo | Aplicabilidade | Resultado esperado |
|---|---|---|
| Skill de workflow | Converter um método pessoal em `SKILL.md` reutilizável. | Pacote versionável com instruções claras. |
| Skill de pesquisa | Transformar notas, planilhas e scripts em skill documentada. | Base pronta para análise, auditoria e publicação. |
| Skill operacional | Padronizar um dashboard, checklist ou rotina. | Execução mais simples, com validação e DoD. |

## Entradas

| Tipo | Exemplos |
|---|---|
| Arquivos | `.md`, `.txt`, `.py`, `.json`, `.csv`, `.html`, `.webarchive`, `.zip`, `.skill` |
| Pastas | Diretórios com scripts, docs, planilhas, exemplos e fontes |
| Conteúdo bruto | Prompts, notas, instruções, playbooks, checklists, workflows |

## Saídas

| Saída | Descrição |
|---|---|
| `SKILL.md` | Instrução principal da skill |
| `README.md` | Documentação tabular e operacional |
| `manifest.json` | Metadados do pacote |
| `docs/FRAMEWORK.md` | Novo framework padrão |
| `docs/RISK_BOUNDARY.md` | Limites e cautelas |
| `docs/VALIDATION.md` | Como validar |
| `schemas/output_schema.json` | Schema canônico de saída |
| `references/` | Métricas e fontes |
| `examples/` | Exemplo mínimo de input |
| `tests/` | Smoke test |
| `source/original_files/` | Fonte preservada |

## Riscos

| ID | Risco | Mitigação |
|---|---|---|
| R-001 | Tema inferido incorretamente | Revisão humana do README e `SKILL.md` |
| R-002 | Documentação genérica demais | Adicionar exemplos reais após primeira execução |
| R-003 | Fonte sensível | Usar `RISK_BOUNDARY.md` e evitar claims clínicos/legais/financeiros |
| R-004 | Arquivo corrompido | Checar relatório batch e logs de extração |

## Validação

| Checagem | Critério |
|---|---|
| Estrutura | Arquivos obrigatórios existem |
| JSON | `manifest.json` e schema parseiam |
| Python | Scripts compilam quando existirem |
| Pacote | ZIP abre sem erro |
| Documentação | README contém Resumo Executivo, 5W2H, ICP e exemplos |

## Manifesto operacional

| Campo | Valor |
|---|---|
| Slug | `{slug}` |
| Domínio detectado | `{domain}` |
| Tags | `{', '.join(tags)}` |
| Status | Draft |

## Próximos passos

1. Revisar `SKILL.md` e README.
2. Substituir campos genéricos por exemplos reais.
3. Testar a skill em Claude.ai Projects ou Claude Code.
4. Versionar em GitHub.
5. Publicar quando a validação estiver consistente.
"""


def render_framework(title: str) -> str:
    return f"""
# Framework padrão — {title}

## Blocos obrigatórios

| Bloco | Função |
|---|---|
| Resumo Executivo | Explicar a skill em linguagem simples |
| 5W2H | Definir escopo, usuário, local, momento e operação |
| ICP | Identificar usuário ideal e usuário não ideal |
| 3 Aplicabilidades | Mostrar três usos concretos e distintos |
| Entradas | Listar formatos e fontes aceitas |
| Saídas | Definir artefatos produzidos |
| Riscos | Mapear riscos de interpretação, segurança e qualidade |
| Mitigações | Reduzir erro, overkill, ruído e fragilidade |
| Validação | Especificar testes mínimos |
| Próximos passos | Orientar evolução da skill |

## Vault labels

| Prefixo | Uso |
|---|---|
| A-### | Assumptions |
| R-### | Risks |
| M-### | Metrics |
| T-### | Tasks |
| D-### | Decisions |

## Status válidos

Draft, Active, Validating, Decision, Archived.
"""


def render_risk_boundary(title: str, warnings: List[str]) -> str:
    warn = "\n".join(f"- {w}" for w in warnings) if warnings else "- Nenhum domínio sensível detectado automaticamente."
    return f"""
# Risk Boundary — {title}

## Escopo

Esta skill é uma ferramenta de organização, documentação e workflow. Ela não substitui revisão profissional em domínios clínicos, jurídicos, financeiros, segurança da informação ou compliance.

## Sinais detectados

{warn}

## Regras

| Regra | Aplicação |
|---|---|
| Não inventar | Campos incertos devem ser `TBD` |
| Separar fato de hipótese | Usar A-### para assumptions e R-### para riscos |
| Alta cautela | Evitar recomendações profissionais sem fonte e sem revisão humana |
| Preservar fonte | Guardar arquivos originais em `source/original_files/` |
| Validar antes de publicar | Rodar smoke test e revisão humana |
"""


def render_validation(title: str) -> str:
    return f"""
# Validation — {title}

## Smoke test manual

1. Abrir o ZIP final.
2. Confirmar que `SKILL.md`, `README.md` e `manifest.json` existem.
3. Confirmar que a pasta `source/original_files/` preserva a fonte.
4. Rodar:

```bash
python tests/smoke_test.py
```

## Critérios de aceite

| Critério | Aceite |
|---|---|
| Estrutura | Todos os arquivos obrigatórios existem |
| Metadados | `manifest.json` é JSON válido |
| Schema | `schemas/output_schema.json` é JSON válido |
| Documentação | README inclui framework completo |
| Fonte | Arquivo original preservado |
| Pacote | ZIP testa sem erro |
"""


def render_sources(title: str) -> str:
    return f"""
# Sources — {title}

| Tipo | Fonte | Observação |
|---|---|---|
| Original | `source/original_files/` | Material enviado pelo usuário |
| Extracted | `source/extracted/` | Conteúdo extraído de ZIP ou `.skill`, quando aplicável |
| Generated | `SKILL.md`, `README.md`, `docs/` | Documentação gerada pelo batch builder |

## Nota

Adicionar fontes externas aqui quando a skill usar dados públicos, documentação oficial ou referências científicas.
"""


def render_metrics(title: str) -> str:
    return f"""
# Metrics — {title}

| ID | Métrica | Definição |
|---|---|---|
| M-001 | Completeness | Percentual de arquivos obrigatórios presentes |
| M-002 | Package Integrity | ZIP abre sem erro |
| M-003 | Source Preservation | Fonte original preservada |
| M-004 | Documentation Coverage | README contém todos os blocos do framework |
| M-005 | Review Need | Nível de revisão humana necessário |
"""


def render_schema() -> str:
    schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "Skill Output Contract",
        "type": "object",
        "required": ["skill_name", "summary", "inputs", "outputs", "risks", "validation"],
        "properties": {
            "skill_name": {"type": "string"},
            "summary": {"type": "string"},
            "inputs": {"type": "array", "items": {"type": "string"}},
            "outputs": {"type": "array", "items": {"type": "string"}},
            "risks": {"type": "array", "items": {"type": "string"}},
            "validation": {"type": "array", "items": {"type": "string"}},
        },
    }
    return json.dumps(schema, indent=2, ensure_ascii=False)


def render_main_py(title: str) -> str:
    return f'''#!/usr/bin/env python3
"""Helper script for {title}."""

from pathlib import Path

REQUIRED = [
    "SKILL.md",
    "README.md",
    "manifest.json",
    "docs/FRAMEWORK.md",
    "docs/RISK_BOUNDARY.md",
    "docs/VALIDATION.md",
]


def validate(root: str = ".") -> list[str]:
    base = Path(root)
    missing = [item for item in REQUIRED if not (base / item).exists()]
    return missing


if __name__ == "__main__":
    missing = validate()
    if missing:
        print("Missing required files:")
        for item in missing:
            print(f"- {{item}}")
        raise SystemExit(1)
    print("Skill structure OK")
'''


def render_smoke_test() -> str:
    return '''#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md",
    "README.md",
    "manifest.json",
    "docs/FRAMEWORK.md",
    "docs/RISK_BOUNDARY.md",
    "docs/VALIDATION.md",
    "references/sources.md",
    "references/metrics.md",
    "schemas/output_schema.json",
    "examples/sample_input.md",
]

missing = [p for p in REQUIRED if not (ROOT / p).exists()]
if missing:
    raise SystemExit("Missing required files: " + ", ".join(missing))

json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
json.loads((ROOT / "schemas/output_schema.json").read_text(encoding="utf-8"))
print("Smoke test OK")
'''


def render_sample_input(title: str) -> str:
    return f"""
# Sample input — {title}

Use this file to test the skill.

## Raw request

Convert this workflow into a complete `SKILL.md` package with README, framework documentation, risk boundary, validation, schema, examples, tests, and preserved source files.

## Expected output

One normalized skill directory and one ZIP package.
"""


def write_manifest(skill_dir: Path, title: str, slug: str, index: int, kind: str, domain: str, tags: List[str], input_path: Path) -> None:
    manifest = {
        "name": title,
        "slug": slug,
        "version": "1.0.0",
        "status": "Draft",
        "generated_at": now_iso(),
        "builder": "skill_builder_batch.py",
        "index": index,
        "input": {
            "path": str(input_path),
            "kind": kind,
            "sha256": sha256_file(input_path) if input_path.is_file() else None,
        },
        "domain": domain,
        "tags": tags,
        "required_files": REQUIRED_FILES,
    }
    write_file(skill_dir / "manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))


def validate_skill(skill_dir: Path) -> Tuple[List[str], List[str]]:
    warnings: List[str] = []
    errors: List[str] = []
    for rel in REQUIRED_FILES:
        if not (skill_dir / rel).exists():
            errors.append(f"Arquivo obrigatório ausente: {rel}")
    for rel in ["manifest.json", "schemas/output_schema.json"]:
        try:
            json.loads((skill_dir / rel).read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"JSON inválido em {rel}: {exc}")
    for py_file in list((skill_dir / "scripts").glob("*.py")) + list((skill_dir / "tests").glob("*.py")):
        try:
            compile(py_file.read_text(encoding="utf-8"), str(py_file), "exec")
        except Exception as exc:
            errors.append(f"Python inválido em {py_file.relative_to(skill_dir)}: {exc}")
    if not any((skill_dir / "source" / "original_files").iterdir()):
        warnings.append("Nenhum arquivo original encontrado em source/original_files/")
    return warnings, errors


def make_zip(src_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file in src_dir.rglob("*"):
            if file.is_file():
                zf.write(file, file.relative_to(src_dir.parent))
    with zipfile.ZipFile(zip_path, "r") as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f"ZIP corrompido; primeiro arquivo ruim: {bad}")


def build_one(input_path: Path, out_dir: Path, index: int, make_skill: bool, overwrite: bool) -> BuildResult:
    title = titleize(input_path.name)
    slug = f"skill-{index:03d}-{slugify(title)}"
    skill_dir = out_dir / "skills" / slug
    zip_path = out_dir / "packages" / f"{slug}.zip"
    skill_path = out_dir / "packages" / f"{slug}.skill"
    warnings: List[str] = []
    errors: List[str] = []

    if skill_dir.exists():
        if overwrite:
            shutil.rmtree(skill_dir)
        else:
            raise FileExistsError(f"Diretório já existe: {skill_dir}. Use --overwrite.")

    make_dirs(skill_dir)
    kind = input_kind(input_path)
    copy_source(input_path, skill_dir, warnings)
    corpus = build_corpus(skill_dir)
    domain, tags, domain_warnings = detect_domain(title, corpus)
    warnings.extend(domain_warnings)
    summary = summarize_source(corpus, title)

    write_file(skill_dir / "SKILL.md", render_skill_md(title, slug, domain, tags, summary))
    write_file(skill_dir / "README.md", render_readme(title, slug, domain, tags, summary))
    write_file(skill_dir / "docs" / "FRAMEWORK.md", render_framework(title))
    write_file(skill_dir / "docs" / "RISK_BOUNDARY.md", render_risk_boundary(title, warnings))
    write_file(skill_dir / "docs" / "VALIDATION.md", render_validation(title))
    write_file(skill_dir / "references" / "sources.md", render_sources(title))
    write_file(skill_dir / "references" / "metrics.md", render_metrics(title))
    write_file(skill_dir / "schemas" / "output_schema.json", render_schema())
    write_file(skill_dir / "scripts" / "main.py", render_main_py(title))
    write_file(skill_dir / "tests" / "smoke_test.py", render_smoke_test())
    write_file(skill_dir / "examples" / "sample_input.md", render_sample_input(title))
    write_manifest(skill_dir, title, slug, index, kind, domain, tags, input_path)

    val_warnings, val_errors = validate_skill(skill_dir)
    warnings.extend(val_warnings)
    errors.extend(val_errors)

    if not errors:
        make_zip(skill_dir, zip_path)
        if make_skill:
            shutil.copy2(zip_path, skill_path)
        else:
            skill_path = Path("")

    status = "OK" if not errors else "ERROR"
    return BuildResult(
        index=index,
        input_path=str(input_path),
        slug=slug,
        title=title,
        input_kind=kind,
        skill_dir=str(skill_dir),
        zip_path=str(zip_path) if zip_path.exists() else "",
        skill_path=str(skill_path) if str(skill_path) and skill_path.exists() else "",
        status=status,
        warnings=" | ".join(warnings),
        errors=" | ".join(errors),
    )


def write_reports(out_dir: Path, results: List[BuildResult]) -> None:
    reports_dir = out_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    rows = [asdict(r) for r in results]

    csv_path = reports_dir / "00_BATCH_REPORT.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ["status"])
        writer.writeheader()
        writer.writerows(rows)

    json_path = reports_dir / "00_BATCH_REPORT.json"
    write_file(json_path, json.dumps(rows, indent=2, ensure_ascii=False))

    md_lines = ["# Batch Skill Builder Report", "", f"Generated: {now_iso()}", "", "| # | Status | Title | ZIP | Warnings | Errors |", "|---:|---|---|---|---|---|"]
    for r in results:
        zip_name = Path(r.zip_path).name if r.zip_path else ""
        md_lines.append(f"| {r.index} | {r.status} | {r.title} | {zip_name} | {r.warnings or ''} | {r.errors or ''} |")
    write_file(reports_dir / "00_BATCH_INDEX.md", "\n".join(md_lines))


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build up to 20 normalized SKILL.md packages from raw files/folders.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(
            """
            Examples:
              python skill_builder_batch.py --input ./raw_skills --output ./built_skills --overwrite
              python skill_builder_batch.py --input ADHD.zip empower.skill notes.md --output ./built_skills
              python skill_builder_batch.py --input ./raw_skills --limit 5 --no-skill
            """
        ),
    )
    parser.add_argument("--input", nargs="+", required=True, help="Arquivo(s) ou pasta(s) de entrada.")
    parser.add_argument("--output", default="./built_skills", help="Pasta de saída. Default: ./built_skills")
    parser.add_argument("--limit", type=int, default=20, help="Máximo de skills por execução. Máximo absoluto: 20.")
    parser.add_argument("--no-skill", action="store_true", help="Não gerar cópia .skill; gera apenas .zip.")
    parser.add_argument("--overwrite", action="store_true", help="Sobrescrever saída existente.")
    parser.add_argument("--dry-run", action="store_true", help="Listar inputs detectados sem gerar arquivos.")
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    out_dir = Path(args.output).expanduser().resolve()
    inputs = collect_inputs(args.input, args.limit)

    if args.dry_run:
        print(f"Inputs detectados: {len(inputs)}")
        for i, p in enumerate(inputs, 1):
            print(f"{i:02d}. {p}")
        return 0

    out_dir.mkdir(parents=True, exist_ok=True)
    results: List[BuildResult] = []
    for i, path in enumerate(inputs, 1):
        try:
            result = build_one(path, out_dir, i, make_skill=not args.no_skill, overwrite=args.overwrite)
        except Exception as exc:
            result = BuildResult(
                index=i,
                input_path=str(path),
                slug=f"skill-{i:03d}-{slugify(path.stem or path.name)}",
                title=titleize(path.name),
                input_kind=input_kind(path),
                skill_dir="",
                zip_path="",
                skill_path="",
                status="ERROR",
                warnings="",
                errors=str(exc),
            )
        results.append(result)
        print(f"[{result.status}] {result.title} -> {result.zip_path or result.errors}")

    write_reports(out_dir, results)
    ok = sum(1 for r in results if r.status == "OK")
    failed = len(results) - ok
    print(f"\nDone. OK={ok} ERROR={failed}")
    print(f"Reports: {out_dir / 'reports'}")
    print(f"Packages: {out_dir / 'packages'}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
