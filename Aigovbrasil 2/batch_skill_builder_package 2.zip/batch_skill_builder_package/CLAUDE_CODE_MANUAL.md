# Manual — Claude Code

## Objetivo

Usar Claude Code para revisar, rodar e melhorar o `skill_builder_batch.py` dentro de um repo local.

## Setup

```bash
mkdir batch-skill-builder
cd batch-skill-builder
cp /caminho/skill_builder_batch.py .
mkdir raw_skills built_skills
```

Coloque até 20 arquivos em `raw_skills/`.

## Instalação do Claude Code

macOS/Linux:

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Windows PowerShell:

```powershell
irm https://claude.ai/install.ps1 | iex
```

## Abrir no terminal

```bash
claude
```

## Prompt principal para Claude Code

```text
Revise este repo como operador de build de skills.
Contrato fixo:
- O script deve aceitar até 20 inputs.
- Cada input deve gerar 1 diretório normalizado.
- Cada diretório deve conter SKILL.md, README.md, manifest.json, docs/, references/, schemas/, scripts/, examples/, tests/ e source/original_files/.
- Cada input deve gerar 1 ZIP individual.
- Cada input deve gerar 1 .skill individual, salvo se --no-skill for usado.
- O batch deve gerar relatório em reports/.

Execute:
1. python skill_builder_batch.py --input ./raw_skills --dry-run
2. python skill_builder_batch.py --input ./raw_skills --output ./built_skills --overwrite
3. rode pelo menos um smoke_test.py gerado
4. leia reports/00_BATCH_INDEX.md
5. reporte erros, warnings e correções propostas
```

## Comandos úteis

```bash
python skill_builder_batch.py --input ./raw_skills --dry-run
python skill_builder_batch.py --input ./raw_skills --output ./built_skills --overwrite
python skill_builder_batch.py --input ./raw_skills --output ./built_skills --no-skill --overwrite
ls -la built_skills/packages
cat built_skills/reports/00_BATCH_INDEX.md
```

## Critério de aceite

| Item | Aceite |
|---|---|
| ZIP por skill | Sim |
| `.skill` por skill | Sim, exceto `--no-skill` |
| Fonte preservada | `source/original_files/` existe |
| README completo | Resumo Executivo + 5W2H + ICP + 3 exemplos |
| Teste | `python tests/smoke_test.py` retorna OK |
