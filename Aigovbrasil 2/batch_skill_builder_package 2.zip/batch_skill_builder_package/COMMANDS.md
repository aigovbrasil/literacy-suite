# Command cheat sheet

## Dry run

```bash
python skill_builder_batch.py --input ./raw_skills --dry-run
```

## Build all

```bash
python skill_builder_batch.py --input ./raw_skills --output ./built_skills --overwrite
```

## Build selected files

```bash
python skill_builder_batch.py --input file1.zip file2.skill notes.md --output ./built_skills --overwrite
```

## ZIP only

```bash
python skill_builder_batch.py --input ./raw_skills --output ./built_skills --no-skill --overwrite
```

## Read report

```bash
cat built_skills/reports/00_BATCH_INDEX.md
```

## Test first generated skill

```bash
python built_skills/skills/skill-001-*/tests/smoke_test.py
```
