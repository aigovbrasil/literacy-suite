# Manual — Claude.ai Projects

## Objetivo

Usar Claude.ai Projects como centro de instruções, revisão e operação do Batch Skill Builder.

## Como montar o Project

1. Criar Project: `Batch Skill Builder`.
2. Subir no Project Knowledge:
   - `skill_builder_batch.py`
   - `README.md`
   - `CLAUDE_CODE_MANUAL.md`
   - `CLAUDE_AI_PROJECTS_MANUAL.md`
   - exemplos de skills aprovadas, se existirem
   - relatório `00_BATCH_INDEX.md` depois de rodar localmente
3. Definir Project Instructions.

## Project Instructions

```text
Você é o operador de documentação e validação do Batch Skill Builder.

Objetivo:
Ajudar Leonardo a converter até 20 arquivos/pastas em skills padronizadas.

Contrato de saída por skill:
- SKILL.md
- README.md
- manifest.json
- docs/FRAMEWORK.md
- docs/RISK_BOUNDARY.md
- docs/VALIDATION.md
- references/sources.md
- references/metrics.md
- schemas/output_schema.json
- scripts/main.py
- examples/sample_input.md
- tests/smoke_test.py
- source/original_files/

Framework obrigatório no README:
- Resumo Executivo
- 5W2H
- ICP
- 3 exemplos distintos de aplicabilidade
- Entradas
- Saídas
- Riscos
- Mitigações
- Validação
- Próximos passos

Regras:
- Responder em português.
- Usar tabelas primeiro.
- Não inventar fatos; usar TBD quando faltar informação.
- Preservar a fonte original.
- Alertar sobre domínios sensíveis.
- Recomendar 1 ZIP por skill, nunca apenas um ZIP gigante.
```

## Prompt para usar no Project

```text
Leia o Batch Skill Builder no Project Knowledge.
Vou rodar localmente o script.
Gere os comandos necessários para:
1. validar os inputs;
2. gerar até 20 skills;
3. conferir os pacotes;
4. testar uma skill;
5. revisar o relatório batch.
```

## Prompt após rodar o script

```text
Aqui está o conteúdo de 00_BATCH_INDEX.md e/ou 00_BATCH_REPORT.csv.
Analise:
1. quais skills deram OK;
2. quais deram erro;
3. quais warnings exigem revisão humana;
4. quais READMEs precisam ser enriquecidos;
5. qual ordem de correção recomenda.
```

## Operação correta

| Fase | O que fazer no Claude.ai Projects |
|---|---|
| Antes do build | Revisar contrato, comandos e estrutura esperada |
| Durante o build | Usar Claude para interpretar erros do terminal |
| Depois do build | Subir relatório batch e pedir análise |
| Revisão final | Subir ZIPs ou READMEs específicos para melhoria manual |
