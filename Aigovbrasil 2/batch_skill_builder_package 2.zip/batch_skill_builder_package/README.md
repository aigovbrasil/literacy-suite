# Batch Skill Builder

Script para converter até 20 arquivos ou pastas em pacotes de skill padronizados com `SKILL.md`, README, manifest, documentação, schema, exemplos, testes, ZIP e `.skill`.

## Resumo executivo

O `skill_builder_batch.py` automatiza o processo de transformar arquivos brutos em skills reutilizáveis. Para cada entrada, ele cria uma pasta normalizada, preserva os arquivos originais, gera documentação com framework operacional, valida a estrutura e entrega um ZIP individual por skill.

## 5W2H

| Elemento | Resposta |
|---|---|
| What / O quê | Script Python para gerar pacotes de skill em lote. |
| Why / Por quê | Reduzir trabalho manual e padronizar documentação. |
| Who / Quem | Leonardo, pesquisadores, solo builders, equipes de IA e operadores de workflow. |
| Where / Onde | Terminal, Claude Code, GitHub repo, Claude.ai Projects ou workspace local. |
| When / Quando | Ao receber vários ZIPs, scripts, notas, webarchives, planilhas ou pastas para virar skills. |
| How / Como | Detecta entradas, preserva fonte, gera `SKILL.md`, README, docs, schema, testes e pacotes. |
| How much / Quanto | Sem dependências externas obrigatórias; custo operacional baixo. |

## ICP

| Campo | Definição |
|---|---|
| Usuário ideal | Quem cria muitas skills, playbooks, prompts, dashboards ou workflows internos. |
| Dor central | Padronizar manualmente cada skill consome tempo e gera inconsistência. |
| Desejo | 1 comando → até 20 skills prontas para revisão, GitHub ou Claude.ai Projects. |
| Não ideal | Quem só precisa converter um único texto simples sem reuso futuro. |

## 3 exemplos de aplicabilidade

| Exemplo | Aplicação | Resultado |
|---|---|---|
| Biblioteca de skills pessoais | Converter 20 métodos próprios em pacotes versionáveis. | ZIP por skill + relatório batch. |
| Projetos Claude.ai | Preparar skills com README e fontes para subir em Project Knowledge. | Projeto mais consistente e consultável. |
| Repo GitHub | Gerar estrutura repetível para publicar skills/documentação. | Estrutura limpa, auditável e validável. |

## Estrutura de saída

```text
built_skills/
├── packages/
│   ├── skill-001-name.zip
│   ├── skill-001-name.skill
│   └── ...
├── reports/
│   ├── 00_BATCH_REPORT.csv
│   ├── 00_BATCH_REPORT.json
│   └── 00_BATCH_INDEX.md
└── skills/
    └── skill-001-name/
        ├── SKILL.md
        ├── README.md
        ├── manifest.json
        ├── docs/
        ├── references/
        ├── schemas/
        ├── scripts/
        ├── examples/
        ├── tests/
        └── source/original_files/
```

## Instalação local

Requisito: Python 3.10+.

```bash
python --version
```

Não há dependências externas obrigatórias.

## Comandos essenciais

### Rodar com uma pasta de entrada

```bash
python skill_builder_batch.py \
  --input ./raw_skills \
  --output ./built_skills \
  --overwrite
```

### Rodar com arquivos específicos

```bash
python skill_builder_batch.py \
  --input ADHD.zip empower.skill notes.md \
  --output ./built_skills \
  --overwrite
```

### Gerar apenas ZIP, sem `.skill`

```bash
python skill_builder_batch.py \
  --input ./raw_skills \
  --output ./built_skills \
  --no-skill \
  --overwrite
```

### Testar inputs antes de gerar

```bash
python skill_builder_batch.py \
  --input ./raw_skills \
  --dry-run
```

### Limitar a 5 skills

```bash
python skill_builder_batch.py \
  --input ./raw_skills \
  --limit 5 \
  --output ./built_skills \
  --overwrite
```

## Uso com Claude Code

Claude Code é adequado para este script porque trabalha diretamente no codebase pelo terminal, IDE, web ou Slack, e pode editar arquivos e rodar comandos com aprovação do usuário.

### Setup sugerido

```bash
mkdir batch-skill-builder
cd batch-skill-builder
cp /caminho/skill_builder_batch.py .
mkdir raw_skills built_skills
```

### Instalar Claude Code

macOS/Linux:

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Windows PowerShell:

```powershell
irm https://claude.ai/install.ps1 | iex
```

### Abrir Claude Code no repo

```bash
claude
```

### Prompt para Claude Code

```text
Você está em um repo com o script skill_builder_batch.py.
Tarefa:
1. Revisar o script sem remover o contrato de saída.
2. Criar ou revisar testes mínimos.
3. Rodar dry-run em ./raw_skills.
4. Rodar build real em ./built_skills.
5. Conferir se cada entrada gerou 1 ZIP por skill e 1 .skill por skill.
6. Não alterar arquivos originais dentro de raw_skills.
Contrato obrigatório: cada skill deve conter SKILL.md, README.md, manifest.json, docs/, references/, schemas/, scripts/, examples/, tests/ e source/original_files/.
```

### Comandos que Claude Code deve rodar

```bash
python skill_builder_batch.py --input ./raw_skills --dry-run
python skill_builder_batch.py --input ./raw_skills --output ./built_skills --overwrite
python built_skills/skills/skill-001-*/tests/smoke_test.py
ls -la built_skills/packages
cat built_skills/reports/00_BATCH_INDEX.md
```

## Uso com Claude.ai Projects

Projects funcionam como workspaces com histórico próprio e knowledge base. O fluxo recomendado é subir o script, este README, exemplos e os ZIPs brutos no Project Knowledge, depois usar instruções fixas do projeto para manter o contrato de saída.

### Criar Project

1. Criar um Project chamado `Batch Skill Builder`.
2. Em Project Knowledge, subir:
   - `skill_builder_batch.py`
   - `README.md`
   - arquivos brutos que serão convertidos ou uma lista dos nomes
   - exemplos de skills já aprovadas, se houver
3. Em Project Instructions, colar o bloco abaixo.

### Project Instructions sugeridas

```text
Você é o operador do Batch Skill Builder.
Objetivo: ajudar a converter até 20 arquivos/pastas em skills padronizadas.
Contrato obrigatório por skill:
- SKILL.md
- README.md
- manifest.json
- docs/FRAMEWORK.md
- docs/RISK_BOUNDARY.md
- docs/VALIDATION.md
- references/sources.md
- references/metrics.md
- schemas/output_schema.json
- scripts/main.py
- examples/sample_input.md
- tests/smoke_test.py
- source/original_files/

Framework obrigatório no README:
- Resumo Executivo
- 5W2H
- ICP
- 3 exemplos distintos de aplicabilidade
- Entradas
- Saídas
- Riscos
- Mitigações
- Validação
- Próximos passos

Regras:
- 1 ZIP por skill.
- 1 .skill por skill quando solicitado.
- Não inventar fatos faltantes; usar TBD.
- Preservar fonte original.
- Marcar domínios sensíveis em RISK_BOUNDARY.md.
- Gerar relatório batch com status, warnings, erros e caminhos.
```

### Prompt operacional em Claude.ai

```text
Leia o README e o script skill_builder_batch.py no Project Knowledge.
Quero gerar skills em lote para os arquivos enviados.
Tarefa:
1. Explique quais arquivos de entrada você detecta.
2. Gere os comandos locais para eu rodar.
3. Depois que eu subir o relatório batch, revise os erros/warnings.
4. Para cada skill com erro, proponha correção objetiva sem mudar o contrato de saída.
```

## Validação manual

Depois de rodar:

```bash
find built_skills/packages -maxdepth 1 -type f \( -name "*.zip" -o -name "*.skill" \)
cat built_skills/reports/00_BATCH_INDEX.md
```

Para testar uma skill específica:

```bash
cd built_skills/skills/skill-001-nome
python tests/smoke_test.py
cd -
```

## Riscos e mitigação

| Risco | Mitigação |
|---|---|
| Nome/tema inferido errado | Revisar `README.md` e `SKILL.md` após build. |
| Conteúdo sensível | Usar `docs/RISK_BOUNDARY.md`. |
| Documentação genérica | Adicionar exemplos reais depois da primeira execução. |
| Arquivo ZIP inválido | Verificar `00_BATCH_REPORT.csv/json`. |
| Mais de 20 inputs | Rodar em lotes separados. |

## Decisão operacional

O batch nunca deve criar somente um ZIP gigante. O padrão correto é:

```text
1 input bruto → 1 pasta normalizada → 1 ZIP individual → 1 .skill opcional
```
