# Metrics — Example Raw Skill

| ID | Métrica | Definição |
|---|---|---|
| M-001 | Completeness | Percentual de arquivos obrigatórios presentes |
| M-002 | Package Integrity | ZIP abre sem erro |
| M-003 | Source Preservation | Fonte original preservada |
| M-004 | Documentation Coverage | README contém todos os blocos do framework |
| M-005 | Review Need | Nível de revisão humana necessário |
