# Sources — Example Raw Skill

| Tipo | Fonte | Observação |
|---|---|---|
| Original | `source/original_files/` | Material enviado pelo usuário |
| Extracted | `source/extracted/` | Conteúdo extraído de ZIP ou `.skill`, quando aplicável |
| Generated | `SKILL.md`, `README.md`, `docs/` | Documentação gerada pelo batch builder |

## Nota

Adicionar fontes externas aqui quando a skill usar dados públicos, documentação oficial ou referências científicas.
