# Example Raw Skill

## Resumo executivo

--- FILE: source/original_files/example_raw_skill.md --- # Example raw workflow Convert this raw workflow into a SKILL.md package. Goal: create a reusable research workflow for collecting notes, risks, assumptions, metrics, and publication candidates. Inputs: chat exports, markdown notes, CSV tables.

Esta skill transforma um material bruto em um pacote operacional reutilizável. O foco é documentação prática, preservação da fonte, padronização `SKILL.md`, validação mínima e entrega em ZIP individual.

## 5W2H

| Elemento | Resposta |
|---|---|
| What / O quê | Skill para normalizar e operar o workflow `Example Raw Skill`. |
| Why / Por quê | Reduzir ruído, preservar contexto e transformar material bruto em pacote reutilizável. |
| Who / Quem | Power users de IA, pesquisadores, builders, consultores, operadores e equipes internas. |
| Where / Onde | Claude Code, Claude.ai Projects, repositório GitHub, workspace local ou vault de conhecimento. |
| When / Quando | Quando um arquivo, método, script ou ZIP precisa virar skill padronizada. |
| How / Como | Gerando `SKILL.md`, README, manifest, docs, schemas, exemplos, testes e pacote final. |
| How much / Quanto | Baixo custo técnico; depende do volume e revisão humana necessária. |

## ICP

| Campo | Definição |
|---|---|
| Perfil ideal | Usuário que cria muitos workflows, prompts, scripts, dashboards ou métodos internos. |
| Dor central | Conteúdo útil fica solto, sem estrutura, sem documentação e sem reuso. |
| Desejo | Converter conhecimento bruto em pacote operacional, versionável e reutilizável. |
| Melhor contexto | Skills internas, automações, pesquisa aplicada, playbooks, GitHub, Claude.ai Projects. |
| Não ideal para | Usuário que só precisa de uma resposta única, sem reuso futuro. |

## 3 exemplos distintos de aplicabilidade

| Exemplo | Aplicabilidade | Resultado esperado |
|---|---|---|
| Skill de workflow | Converter um método pessoal em `SKILL.md` reutilizável. | Pacote versionável com instruções claras. |
| Skill de pesquisa | Transformar notas, planilhas e scripts em skill documentada. | Base pronta para análise, auditoria e publicação. |
| Skill operacional | Padronizar um dashboard, checklist ou rotina. | Execução mais simples, com validação e DoD. |

## Entradas

| Tipo | Exemplos |
|---|---|
| Arquivos | `.md`, `.txt`, `.py`, `.json`, `.csv`, `.html`, `.webarchive`, `.zip`, `.skill` |
| Pastas | Diretórios com scripts, docs, planilhas, exemplos e fontes |
| Conteúdo bruto | Prompts, notas, instruções, playbooks, checklists, workflows |

## Saídas

| Saída | Descrição |
|---|---|
| `SKILL.md` | Instrução principal da skill |
| `README.md` | Documentação tabular e operacional |
| `manifest.json` | Metadados do pacote |
| `docs/FRAMEWORK.md` | Novo framework padrão |
| `docs/RISK_BOUNDARY.md` | Limites e cautelas |
| `docs/VALIDATION.md` | Como validar |
| `schemas/output_schema.json` | Schema canônico de saída |
| `references/` | Métricas e fontes |
| `examples/` | Exemplo mínimo de input |
| `tests/` | Smoke test |
| `source/original_files/` | Fonte preservada |

## Riscos

| ID | Risco | Mitigação |
|---|---|---|
| R-001 | Tema inferido incorretamente | Revisão humana do README e `SKILL.md` |
| R-002 | Documentação genérica demais | Adicionar exemplos reais após primeira execução |
| R-003 | Fonte sensível | Usar `RISK_BOUNDARY.md` e evitar claims clínicos/legais/financeiros |
| R-004 | Arquivo corrompido | Checar relatório batch e logs de extração |

## Validação

| Checagem | Critério |
|---|---|
| Estrutura | Arquivos obrigatórios existem |
| JSON | `manifest.json` e schema parseiam |
| Python | Scripts compilam quando existirem |
| Pacote | ZIP abre sem erro |
| Documentação | README contém Resumo Executivo, 5W2H, ICP e exemplos |

## Manifesto operacional

| Campo | Valor |
|---|---|
| Slug | `skill-001-example-raw-skill` |
| Domínio detectado | `workflow` |
| Tags | `#workflow, #ai, #execution` |
| Status | Draft |

## Próximos passos

1. Revisar `SKILL.md` e README.
2. Substituir campos genéricos por exemplos reais.
3. Testar a skill em Claude.ai Projects ou Claude Code.
4. Versionar em GitHub.
5. Publicar quando a validação estiver consistente.
