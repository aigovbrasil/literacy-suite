#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md",
    "README.md",
    "manifest.json",
    "docs/FRAMEWORK.md",
    "docs/RISK_BOUNDARY.md",
    "docs/VALIDATION.md",
    "references/sources.md",
    "references/metrics.md",
    "schemas/output_schema.json",
    "examples/sample_input.md",
]

missing = [p for p in REQUIRED if not (ROOT / p).exists()]
if missing:
    raise SystemExit("Missing required files: " + ", ".join(missing))

json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
json.loads((ROOT / "schemas/output_schema.json").read_text(encoding="utf-8"))
print("Smoke test OK")
