# Example Raw Skill

## Description

--- FILE: source/original_files/example_raw_skill.md --- # Example raw workflow Convert this raw workflow into a SKILL.md package. Goal: create a reusable research workflow for collecting notes, risks, assumptions, metrics, and publication candidates. Inputs: chat exports, markdown notes, CSV tables.

This skill normalizes a raw workflow, document set, script, archive, or operational method into a reusable `SKILL.md` package.

## When to use

Use this skill when the user needs to:

- convert a raw file, ZIP, script, workbook, note, or workflow into a structured skill;
- preserve original source files while creating clean operational documentation;
- produce a reusable package with `SKILL.md`, README, manifest, schemas, examples, tests, references, and validation notes;
- document a workflow using Executive Summary, 5W2H, ICP, applicability examples, risks, mitigations, and validation criteria.

## Inputs

Accepted inputs may include:

- Markdown, TXT, JSON, CSV, HTML, WebArchive, Python scripts, ZIP archives, `.skill` packages, folders, and supporting files;
- rough prompts, workflow notes, research artifacts, dashboards, operational checklists, or source code;
- project-specific constraints, if provided by the user.

## Output contract

The skill should produce or maintain this structure:

```text
skill-001-example-raw-skill/
├── SKILL.md
├── README.md
├── manifest.json
├── docs/
│   ├── FRAMEWORK.md
│   ├── RISK_BOUNDARY.md
│   └── VALIDATION.md
├── references/
│   ├── metrics.md
│   └── sources.md
├── schemas/
│   └── output_schema.json
├── scripts/
│   └── main.py
├── examples/
│   └── sample_input.md
├── tests/
│   └── smoke_test.py
└── source/
    └── original_files/
```

## Workflow

1. Inspect the source files.
2. Identify the primary goal, domain, user, inputs, outputs, risks, and expected deliverables.
3. Preserve all original files under `source/original_files/`.
4. Generate the standard documentation package.
5. Add a risk boundary when the domain is medical, legal, financial, security-sensitive, or otherwise high-stakes.
6. Validate required files, JSON syntax, Python syntax where applicable, and package integrity.
7. Return one ZIP per skill and, when requested, a `.skill` package.

## Documentation framework

Each generated README must include:

- Resumo Executivo
- 5W2H
- ICP
- 3 exemplos distintos de aplicabilidade
- Entradas
- Saídas
- Riscos
- Mitigações
- Validação
- Próximos passos

## Metadata

| Field | Value |
|---|---|
| Slug | `skill-001-example-raw-skill` |
| Domain | `workflow` |
| Tags | `#workflow, #ai, #execution` |
| Status | Draft |

## Safety and quality rules

- Do not invent missing source facts. Mark unknowns as `TBD`.
- Separate facts, assumptions, risks, metrics, tasks, and decisions.
- For sensitive domains, include a non-clinical, non-legal, non-financial, or non-security boundary as appropriate.
- Prefer concise operational language.
- Preserve source files for auditability.
