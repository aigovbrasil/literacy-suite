# Framework padrão — Example Raw Skill

## Blocos obrigatórios

| Bloco | Função |
|---|---|
| Resumo Executivo | Explicar a skill em linguagem simples |
| 5W2H | Definir escopo, usuário, local, momento e operação |
| ICP | Identificar usuário ideal e usuário não ideal |
| 3 Aplicabilidades | Mostrar três usos concretos e distintos |
| Entradas | Listar formatos e fontes aceitas |
| Saídas | Definir artefatos produzidos |
| Riscos | Mapear riscos de interpretação, segurança e qualidade |
| Mitigações | Reduzir erro, overkill, ruído e fragilidade |
| Validação | Especificar testes mínimos |
| Próximos passos | Orientar evolução da skill |

## Vault labels

| Prefixo | Uso |
|---|---|
| A-### | Assumptions |
| R-### | Risks |
| M-### | Metrics |
| T-### | Tasks |
| D-### | Decisions |

## Status válidos

Draft, Active, Validating, Decision, Archived.
