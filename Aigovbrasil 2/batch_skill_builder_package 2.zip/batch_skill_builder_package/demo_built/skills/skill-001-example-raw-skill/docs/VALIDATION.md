# Validation — Example Raw Skill

## Smoke test manual

1. Abrir o ZIP final.
2. Confirmar que `SKILL.md`, `README.md` e `manifest.json` existem.
3. Confirmar que a pasta `source/original_files/` preserva a fonte.
4. Rodar:

```bash
python tests/smoke_test.py
```

## Critérios de aceite

| Critério | Aceite |
|---|---|
| Estrutura | Todos os arquivos obrigatórios existem |
| Metadados | `manifest.json` é JSON válido |
| Schema | `schemas/output_schema.json` é JSON válido |
| Documentação | README inclui framework completo |
| Fonte | Arquivo original preservado |
| Pacote | ZIP testa sem erro |
