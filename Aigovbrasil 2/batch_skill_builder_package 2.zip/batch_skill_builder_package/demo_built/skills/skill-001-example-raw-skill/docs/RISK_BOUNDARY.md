# Risk Boundary — Example Raw Skill

## Escopo

Esta skill é uma ferramenta de organização, documentação e workflow. Ela não substitui revisão profissional em domínios clínicos, jurídicos, financeiros, segurança da informação ou compliance.

## Sinais detectados

- Nenhum domínio sensível detectado automaticamente.

## Regras

| Regra | Aplicação |
|---|---|
| Não inventar | Campos incertos devem ser `TBD` |
| Separar fato de hipótese | Usar A-### para assumptions e R-### para riscos |
| Alta cautela | Evitar recomendações profissionais sem fonte e sem revisão humana |
| Preservar fonte | Guardar arquivos originais em `source/original_files/` |
| Validar antes de publicar | Rodar smoke test e revisão humana |
