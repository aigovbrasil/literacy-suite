# Sample input — Example Raw Skill

Use this file to test the skill.

## Raw request

Convert this workflow into a complete `SKILL.md` package with README, framework documentation, risk boundary, validation, schema, examples, tests, and preserved source files.

## Expected output

One normalized skill directory and one ZIP package.
