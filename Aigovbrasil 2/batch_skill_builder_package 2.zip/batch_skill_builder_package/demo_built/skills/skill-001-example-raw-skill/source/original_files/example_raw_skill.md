# Example raw workflow

Convert this raw workflow into a SKILL.md package.

Goal: create a reusable research workflow for collecting notes, risks, assumptions, metrics, and publication candidates.

Inputs: chat exports, markdown notes, CSV tables.
Outputs: README, SKILL.md, risk boundary, validation checklist.
