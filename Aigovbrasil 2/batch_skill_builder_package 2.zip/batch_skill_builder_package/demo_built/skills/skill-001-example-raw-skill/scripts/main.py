#!/usr/bin/env python3
"""Helper script for Example Raw Skill."""

from pathlib import Path

REQUIRED = [
    "SKILL.md",
    "README.md",
    "manifest.json",
    "docs/FRAMEWORK.md",
    "docs/RISK_BOUNDARY.md",
    "docs/VALIDATION.md",
]


def validate(root: str = ".") -> list[str]:
    base = Path(root)
    missing = [item for item in REQUIRED if not (base / item).exists()]
    return missing


if __name__ == "__main__":
    missing = validate()
    if missing:
        print("Missing required files:")
        for item in missing:
            print(f"- {item}")
        raise SystemExit(1)
    print("Skill structure OK")
