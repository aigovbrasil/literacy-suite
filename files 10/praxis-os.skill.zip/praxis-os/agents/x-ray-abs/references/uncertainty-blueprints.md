# Uncertainty Blueprints — P01→P08 + #arede taxonomy

Fonte: `Prompt-under-uncertany.txt` (Prompt Blueprints para Max Reasoning)

8 blueprints de prompt + taxonomia AREDE para roteamento de output sob
incerteza. Stack canônico de ativação no final.

---

## Quando consultar este arquivo

- Web search ativo (PASSO 2 de x-ray-abs) e usuário pede certeza calibrada
- Usuário diz "preciso de uma decisão clara, não hedge"
- Output precisa separar narrativa de mercado vs métrica verificada
- Usuário pede análise causal ou validação de hipótese
- Pesquisa regulatória / compliance EU AI Act / LGPD

---

## Taxonomia AREDE — tag global de roteamento

```
#arede                  ← tag raiz
  ├── /analise          ← decomposição estruturada de problema
  ├── /rastreio         ← verificação e proveniência de evidências
  ├── /extracao         ← separação sinal/ruído em dados brutos
  ├── /decisao          ← suporte à decisão com certeza calibrada
  └── /execucao         ← orientação para próximo passo concreto
```

Toda Síntese Executiva de x-ray-abs em modo Uncertainty pode anexar tag
`#arede/<sub>` ao final para roteamento downstream (Linear · Notion · etc).

---

## Tabela Mestre — 8 Blueprints

| ID  | Nome                          | Objetivo                                                              | Tag AREDE         | Subtags                              |
|-----|-------------------------------|-----------------------------------------------------------------------|-------------------|---------------------------------------|
| P01 | Market Signal Extractor       | Separar sinal de tendência de ruído conjuntural em dados de mercado    | `#arede/extracao` | /mercado /macro /setor                |
| P02 | Competitive Intelligence Audit| Mapear posição competitiva real, separando claim de evidência          | `#arede/rastreio` | /concorrente /posicionamento /preco   |
| P03 | Decision Certainty Synthesizer| Produzir recomendação binária com certeza calibrada (%)                | `#arede/decisao`  | /binario /probabilidade /go-nogo      |
| P04 | Regulatory Horizon Scanner    | Identificar mudanças regulatórias confirmadas (não especulativas)      | `#arede/rastreio` | /regulatorio /compliance /EU /BR      |
| P05 | Data-Backed Pricing Anchor    | Extrair faixa de preço defensável via dados web com source-trace       | `#arede/extracao` | /precificacao /benchmarking /margem   |
| P06 | Causal Chain Validator        | Verificar se relação causal assumida é suportada por evidências        | `#arede/analise`  | /causalidade /hipotese /validacao     |
| P07 | Execution Risk Screener       | Identificar riscos de execução concretos (não teóricos), com casos     | `#arede/execucao` | /risco /implementacao /casos-reais    |
| P08 | Narrative vs Numbers Splitter | Separar narrativa de mercado (PR/marketing) de métricas verificáveis   | `#arede/extracao` | /dados /pr-vs-fato /due-diligence     |

---

## Mapeamento Blueprint → Lente x-ray-abs

| Blueprint | Lente x-ray-abs principal      | Quando aplicar                                          |
|-----------|--------------------------------|---------------------------------------------------------|
| P01       | `mercado`                      | Web search S06 · contexto de mercado                    |
| P02       | `mercado` + `business-model`   | Análise de concorrência S06                             |
| P03       | qualquer (final)               | Síntese Executiva quando DQ é binária (go/no-go)        |
| P04       | `risco`                        | Compliance · regulatório · LGPD · EU AI Act             |
| P05       | `business-model`               | Pricing S08, S13                                         |
| P06       | `data-driven`                  | Validação de hipótese S07, S09                          |
| P07       | `risco` + `operacional`        | Riscos de execução S11, S16                             |
| P08       | `mercado`                      | Due diligence · separar PR de métrica real              |

---

## Stack Canônico — XML structure para queries de Max Reasoning

Use este stack como **template** quando ativar Uncertainty Mode em
x-ray-abs (PASSO 9 do SKILL.md). Substituir `[QUERY]` pela pergunta real.

```xml
<role>
Senior strategic analyst with web research access.
Mandate: data-driven conclusions under certainty — no hedged non-answers.
</role>

<operating_logic>
STEP 1 — Search web for [QUERY] using multiple queries if needed.
STEP 2 — Audit each source: publisher · date · primary vs secondary.
STEP 3 — Separate signal (verified data) from noise (claim/opinion).
STEP 4 — Build causal chain in <thinking> before writing any output.
STEP 5 — Produce structured output per required_outputs below.
</operating_logic>

<constraints>
- Never produce a conclusion without citing the source that supports it.
- Never conflate claim with evidence — tag them separately.
- If certainty < 60%: declare it explicitly, do not fake confidence.
- If certainty ≥ 80%: produce binary recommendation with no hedge.
</constraints>

<output_format>
<thinking>[full reasoning chain, visible]</thinking>
<evidence_map>[source → data point → certainty weight]</evidence_map>
<decision>[binary or ranked output]</decision>
<certainty_score>[0-100% with justification]</certainty_score>
</output_format>
```

---

## Calibration Bands — Certainty Score

| Range    | Comportamento                                        |
|----------|------------------------------------------------------|
| 90-100%  | Recomendação binária com no-hedge                    |
| 80-89%   | Recomendação clara com 1 risco residual nomeado      |
| 60-79%   | Recomendação com gate intermediário (validar antes)  |
| 40-59%   | Decisão prematura — coletar mais dados antes         |
| 0-39%    | NO_GO em decisão · recomendar pesquisa adicional     |

A certainty band substitui o critério binário AVANÇAR/PAUSAR/PIVOTAR
quando o usuário explicitamente pede certeza calibrada.

---

## Source Quality Hierarchy

Em ordem decrescente de peso (`certainty_weight`):

```
1. Documento oficial governamental (regulação, ANPD, BCB, CADE, ABNT)   peso 1.0
2. Paper peer-reviewed em journal indexado                              peso 0.95
3. Statement oficial de CEO/CFO em 10-K, earnings call, IPO prospectus  peso 0.90
4. Relatório de big-4 (McKinsey, BCG, Bain, Deloitte) com data          peso 0.85
5. Imprensa especializada com autor + data + fonte primária citada      peso 0.75
6. Análise de instituto de pesquisa reconhecido (Pew, Gartner, Forrester) peso 0.70
7. Blog corporativo de empresa do setor                                  peso 0.50
8. Reddit, fóruns, agregadores                                           peso 0.20
9. Sites sem data ou autor                                               peso 0.05 (descartar)
```

Toda evidence_map tag deve declarar peso.

---

## Anti-patterns — banidos em modo Uncertainty

```
❌ "É possível que..." sem certainty_score numérico
❌ Citar dado sem fonte
❌ Misturar narrativa (PR) e métrica (verificada) no mesmo bullet
❌ Recomendação binária sem evidence_map preenchido
❌ Certainty ≥ 80% com peso médio de fontes < 0.6
❌ Usar P03 sem ter rodado P01 ou P02 antes (dado bruto antes de decisão)
```

---

## Pipeline Recomendado — combinação de blueprints

```
Análise de mercado completa:
  P01 → P08 → P02 → P05 → P03
  (extrair sinal · separar narrativa · auditar concorrência · ancorar preço · decidir)

Validação de hipótese de negócio:
  P06 → P01 → P03
  (validar causalidade · extrair sinal de mercado · decidir)

Compliance / regulatório:
  P04 → P07 → P03
  (escanear regulação · screening de risco execução · decidir)

Due diligence de produto novo:
  P02 → P08 → P05 → P07 → P03
  (concorrência · narrativa-vs-fato · pricing · risco execução · decidir)
```

---

## Trigger — Uncertainty Mode em x-ray-abs

Ativar quando:
- Web search ativo (lente=mercado · business-model · data-driven · risco)
- Usuário diz "certeza calibrada", "sem hedge", "decisão binária", "% de certeza"
- Output requer roteamento downstream (#arede tag) para Linear/Notion
- DQ é tipo DQ-3, DQ-4, DQ-5 (validação de mercado)
- Pergunta envolve regulação ou compliance

Comportamento:
1. Selecionar 1-3 blueprints da tabela mestre
2. Para cada blueprint, executar 3 web searches conforme PASSO 2 padrão
3. Aplicar source quality hierarchy aos resultados
4. Emitir `<evidence_map>` antes de qualquer recomendação
5. Calcular `<certainty_score>` ponderado pelos pesos das fontes
6. Síntese Executiva inclui: Decision + Certainty% + #arede tag
