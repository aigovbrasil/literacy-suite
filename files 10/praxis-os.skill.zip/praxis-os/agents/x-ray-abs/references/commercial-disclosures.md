# Commercial Disclosures — LGPD Reference

ID         : XRAY-REF-LGPD-V1
LABEL      : Commercial Use Disclosures · LGPD Compliance Reference
TYPE       : Reference (loadable by SKILL.md)
DOMAIN     : Data Protection · BR Regulatory
PROJECT    : x-ray-abs v2.0.0
LANGUAGE   : PT-BR
STATUS     : READY · LEGAL REVIEW REQUIRED BEFORE COMMERCIAL DEPLOYMENT
EPISTEMIC  : SOURCED (primary statutory + ANPD) + HYPOTHESIS (interpretation gaps)
CREATED    : 2026-04-29

---

## ⚠️ AVISO LEGAL VINCULANTE

> **Esta seção requer revisão por advogado(a) qualificado(a) em proteção
> de dados no Brasil antes do uso comercial.**

Este documento sintetiza fontes primárias para orientação operacional
do consultor. Não constitui parecer jurídico. Decisões de conformidade
devem ser validadas por DPO ou advogado especializado em LGPD.

---

## 1. Fontes Primárias Citadas

### 1.1 LGPD — Lei nº 13.709/2018 · Art. 5º X (definição de tratamento)

[FONTE: Lei nº 13.709/2018 · texto vigente · planalto.gov.br · cross-referenced gov.br/anpd]

Texto verbatim:

> **X - tratamento:** toda operação realizada com dados pessoais, como
> as que se referem a coleta, produção, recepção, classificação,
> utilização, acesso, reprodução, transmissão, distribuição,
> processamento, arquivamento, armazenamento, eliminação, avaliação ou
> controle da informação, modificação, comunicação, transferência,
> difusão ou extração;

**Implicação operacional para x-ray-abs:**
Quando o consultor cola briefing de cliente contendo dados pessoais,
todas as operações executadas pela skill (recepção, processamento,
armazenamento temporário em contexto, transmissão para Anthropic,
classificação como gap/risco) configuram tratamento sob LGPD.

### 1.2 LGPD · Art. 52 (sanções administrativas)

[FONTE: Lei nº 13.709/2018 · Art. 52 · gov.br/anpd]

Penalidades aplicáveis pela ANPD:
- Advertência com prazo para adoção de medidas corretivas
- Multa simples de até 2% do faturamento bruto da empresa,
  limitada a R$ 50.000.000,00 por infração
- Multa diária, observado o limite total acima
- Publicização da infração
- Bloqueio dos dados pessoais a que se refere a infração até regularização
- Eliminação dos dados pessoais a que se refere a infração

### 1.3 Portaria ANPD nº 5/2024 · IA e dados pessoais

[FONTE: Portaria CD/ANPD nº 5 de 2024 · gov.br/anpd · acesso 2026-04-29 via Q5]

Estabelece princípios para tratamento de dados pessoais por sistemas
de IA. Três pilares operacionais:

| Pilar          | Requisito operacional                                 |
|----------------|-------------------------------------------------------|
| Transparência  | Informar titular sobre uso de IA · finalidade · fluxo |
| Auditabilidade | Manter logs e documentação técnica do tratamento      |
| Mitigação de viés | Demonstrar medidas contra discriminação algorítmica |

**Implicação para x-ray-abs:**
- A skill não treina modelos — opera sobre input efêmero
- Logs ficam no histórico Anthropic conforme retenção padrão
- Output não toma decisão automatizada sobre titulares — decision
  support apenas (Art. 20 LGPD não acionado por design)

### 1.4 Radar Tecnológico — IA Generativa (ANPD · Jan 2024)

[FONTE: gov.br/anpd/pt-br/centrais-de-conteudo/documentos-tecnicos-orientativos/radar_tecnologico_ia_generativa_anpd.pdf]

Documento técnico-orientativo. Pontos relevantes para esta skill:

- Princípio da transparência (Art. 6º LGPD): titulares devem ter
  informação clara sobre tratamento de seus dados em sistemas de IA
- Princípio da minimização: tratar apenas dados necessários à finalidade
- Bases legais usadas em IA: consentimento (43%), legítimo interesse
  (31%), execução de contrato (18%) [SOURCED estudo citado pelo Radar]
- Compartilhamento de modelos pré-treinados pode envolver dados
  matematicamente presentes nos pesos — desafio aberto

**Implicação:** consultor deve informar cliente PME que briefings com
dados pessoais passarão por IA generativa Anthropic. Cliente é o
controlador; consultor é operador (Art. 5º VI e VII LGPD).

### 1.5 [HYPOTHESIS] Lacuna regulatória ANPD/IA

[FONTE: revistaft.com.br · estudo acadêmico 2024 · NÃO é fonte primária ANPD]

Pesquisa acadêmica indica que dos 17 guias técnicos publicados pela
ANPD até Q1/2024, apenas 2 endereçam IA, e nenhum estabelece
protocolos detalhados para auditoria algorítmica.

**Status:** mantido como HYPOTHESIS por ser fonte secundária.
Implica: o consultor opera em zona de regulação evolutiva.
Re-verificar trimestralmente em gov.br/anpd.

---

## 2. Modelo Tier-1 — 5 Elementos de Disclosure

### E1 — Stage-0 Disclaimer (na primeira ativação da skill)

Texto inserido pela SKILL.md no primeiro turno:

> **[x-ray.abs] — Aviso LGPD.** Esta skill processa inputs de negócio
> que você cola na conversa. Recomendação: anonimize dados pessoais
> identificáveis de clientes (nomes, CPFs, e-mails, dados de saúde,
> dados financeiros) ANTES de submeter. Os inputs são processados pela
> infraestrutura Anthropic conforme termos vigentes. Para casos com
> tratamento de dados sensíveis em escala, recomenda-se DPIA
> (Avaliação de Impacto à Proteção de Dados).

### E2 — Anthropic Processing Note

Quando consultor pergunta "para onde vai meu input?":

> Inputs nesta conversa são processados pela API/infraestrutura
> Anthropic. Termos comerciais vigentes regem retenção e uso. ZDR
> (Zero Data Retention) NÃO se aplica a Agent Skills por padrão —
> verificar contrato vigente em anthropic.com/legal antes de tratar
> dados sensíveis. Para dados sob LGPD com base legal frágil,
> considerar processamento local fora desta skill.

[FONTE: docs.claude.com — agent-skills overview · "Agent Skills is
not covered by ZDR arrangements" · acesso 2026-04-29]

### E3 — PII Anonymization Recommendation

Antes de colar briefing:
- Substituir nomes por papéis ("CEO", "Cliente A", "Operador 1")
- Substituir CPF/CNPJ por hashes ou IDs sintéticos
- Remover e-mails e telefones · usar placeholders
- Remover dados de saúde, biométricos, étnicos, financeiros
  específicos (Art. 11 LGPD — dados sensíveis)

**Útil:** o diagnóstico não precisa de PII para funcionar — opera
sobre estrutura, não identificação.

### E4 — DPIA Pointer (cenários de alto risco)

Quando o cenário envolver:
- Decisões automatizadas afetando direitos do titular (Art. 20)
- Tratamento em larga escala de dados sensíveis (Art. 11)
- Monitoramento sistemático de espaço público
- Tratamento de dados de crianças/adolescentes (Art. 14)

Recomendar formalmente: cliente PME deve elaborar Avaliação de
Impacto à Proteção de Dados (DPIA / RIPD) antes de prosseguir.
Modelo de referência: ANPD publicou template em gov.br/anpd.

### E5 — Output Limitations (Stage-7 disclaimer)

Inserir na Síntese Executiva quando lente = `risco` ou `proposta`:

> Output é instrumento de decision support. Não constitui parecer
> jurídico, contábil, financeiro ou tributário. Recomendações
> requerem validação por profissional habilitado antes de execução
> com efeitos a terceiros.

---

## 3. Papéis sob LGPD (Art. 5º VI, VII, VIII)

| Papel        | Quem é nesta arquitetura                               |
|--------------|--------------------------------------------------------|
| Controlador  | Cliente PME (decide finalidade do tratamento)          |
| Operador     | Consultor que opera x-ray-abs em nome do cliente       |
| Subprocessor | Anthropic (infraestrutura de IA usada pela skill)      |
| Encarregado  | DPO do cliente PME (se nomeado)                        |
| Titular      | Pessoa física cujos dados aparecem no briefing         |

**Cadeia contratual mínima recomendada:**
- Contrato de prestação de serviços consultor ↔ cliente PME com
  cláusula LGPD (Art. 39) explicitando uso de IA generativa
- Termos Anthropic vigentes aceitos pelo consultor (titular da conta)

---

## 4. Bases Legais Aplicáveis (Art. 7º LGPD)

Para uso desta skill em consultoria comercial, bases legais
tipicamente cabíveis:

| Base legal (Art. 7º)         | Quando se aplica                                |
|------------------------------|-------------------------------------------------|
| II — cumprimento de obrigação legal | Auditoria regulatória obrigatória         |
| V — execução de contrato     | Diagnóstico previsto em contrato consultivo     |
| IX — legítimo interesse      | Análise estratégica para o controlador          |

Consentimento (I) raramente é a base ideal para diagnóstico
empresarial — exige granularidade que dados em briefing não têm.

---

## 5. Direitos dos Titulares (Art. 18 LGPD)

Quando dados pessoais entram no diagnóstico, o titular preserva:
- Confirmação da existência de tratamento
- Acesso aos dados
- Correção de dados incompletos/inexatos
- Anonimização, bloqueio ou eliminação
- Portabilidade
- Eliminação dos dados tratados com consentimento
- Informação sobre compartilhamento
- Informação sobre possibilidade de não consentir
- Revogação do consentimento

**Implicação operacional:** cliente PME (controlador) é responsável
por atender requisições. Consultor (operador) deve cooperar.
A skill não tem mecanismo de "esquecer" um briefing pós-conversa —
recomendar que cliente exclua a conversa em claude.ai se necessário.

---

## 6. Monitoramento Trimestral — Checklist

Re-verificar a cada trimestre (próxima revisão: 2026-Q3):

- [ ] gov.br/anpd → novos guias orientativos sobre IA
- [ ] gov.br/anpd → atualizações de Portaria 5/2024
- [ ] PL Marco Legal de IA (PL 2338/2023) → status no Congresso
- [ ] Resoluções da ANPD sobre transferência internacional (Res 8/2025)
- [ ] Decisões STJ sobre responsabilidade civil em vazamento

---

## 7. EU AI Act — Nota de Acompanhamento

> **EU AI Act relevance:** monitor for founder's EU relocation Sep
> 2026 — not in current ICP scope.

Quando ICP expandir para EU, adicionar:
- Risk categorization (high-risk vs limited-risk AI systems)
- Transparency obligations (Article 13)
- Foundation model obligations (Article 28b)
- CE marking requirements para sistemas de alto risco

Não implementar em v2.0.0 — registrar como roadmap item para v3.

---

## 8. Anti-patterns LGPD a evitar

- Tratar briefing como "dado público" só porque cliente pagou pela consultoria
- Renderizar artefatos HTML com PII de cliente final
- Esquecer de informar cliente que consultor usa IA generativa
- Usar consentimento como base legal sem granularidade real
- Promessa de "100% conforme LGPD" — fora do mandato do consultor

---

## 9. Caveat Final (verbatim · não modificar)

> **Esta seção requer revisão por advogado(a) qualificado(a) em proteção
> de dados no Brasil antes do uso comercial.**
