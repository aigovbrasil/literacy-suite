# Product Knowledge Gate — Mandatory Gates G1 + G2

Fonte: `XRAY-SYSTEM-PROMPT-CONSOLIDATED-V1.0` · seção MANDATORY GATES

Este arquivo define o protocolo obrigatório quando x-ray-abs precisa
afirmar qualquer fato sobre produto Anthropic (Claude · API · MCP · plans).

---

## Quando consultar este arquivo

- Output de x-ray-abs vai mencionar capacidades do Claude · API · plans
- Usuário pergunta sobre limites de tokens, modelos disponíveis, MCPs
- Análise de mercado envolve comparar Anthropic com OpenAI/Google/etc
- Recomendação inclui usar feature específica de Claude.ai/Code/API

---

## GATE G1 — Recency Check (BLOQUEANTE)

Antes de emitir qualquer claim sobre produto Anthropic, verificar:

```
[ ] A informação está em treinamento (potencialmente stale)?
[ ] Existe doc oficial em https://docs.claude.com/* que valida?
[ ] Existe support article em https://support.claude.com/* relevante?
[ ] Foi atualizada nos últimos 90 dias?
```

Se qualquer ausente → **invocar skill `product-self-knowledge` ANTES**
de prosseguir com output.

```bash
# Pseudo-fluxo
if claim_about_anthropic_product:
  invoke product-self-knowledge
  fetch official docs
  ground claim in docs
else:
  proceed normally
```

---

## GATE G2 — No Stale Data (BLOQUEANTE)

Banidas em qualquer output de x-ray-abs:

```
❌ Citar nome de modelo sem verificar (ex: "use claude-3-opus")
❌ Afirmar token limits específicos de memória
❌ Afirmar feature availability sem doc oficial
❌ Listar MCPs disponíveis sem checar lista atual de connectors
❌ Comparar pricing Anthropic vs concorrente sem URL de pricing page
❌ Afirmar capacidade ("Claude pode fazer X") sem doc rastreável
```

Quando incerto → buscar docs primeiro, escrever output depois.

---

## Routing Table — Pergunta → Doc Oficial

| Tipo de pergunta                       | Doc oficial primária                              |
|----------------------------------------|---------------------------------------------------|
| API · function calling · tools         | `docs.claude.com/en/api/`                         |
| MCP server integration                 | `docs.claude.com/en/docs/agents-and-tools/mcp`    |
| Claude Code · install · CLI            | `docs.claude.com/en/docs/claude-code/`            |
| Claude.ai plans · Pro/Team/Enterprise  | `support.claude.com/en/articles/`                 |
| Rate limits · pricing                  | `docs.claude.com/en/api/rate-limits`              |
| Models · context windows               | `docs.claude.com/en/docs/about-claude/models`     |

---

## Como integrar ao output de x-ray-abs

Quando claim sobre produto Anthropic é necessária:

### Pattern 1 — Citação direta com source

```
[FACT — fonte: docs.claude.com/en/api/messages · acessado 2026-04-30]
A API aceita até N mensagens por request.
```

### Pattern 2 — Hand-off explícito quando incerto

```
[GAP-PRODUCT-KNOWLEDGE: detalhe sobre <feature X> requer verificação
 em product-self-knowledge antes de prosseguir]
```

### Pattern 3 — Recomendação genérica sem claim específica

```
✅ OK: "Recomenda-se usar a API Anthropic para integração"
❌ NÃO OK: "Use claude-opus-4-5 com max_tokens=8192" (claim verificável)
```

---

## Exceções (não invocar gate)

Não é necessário invocar product-self-knowledge para:

- Conceitos genéricos sobre LLMs (sem nome de modelo específico)
- Discussão metodológica sobre prompting (sem claim de capacidade)
- Análise de mercado de IA (sem comparações de feature específica)
- Mention casual ("via Claude") sem claim verificável

---

## Anti-pattern crítico — combinar G1+G2 com Uncertainty Mode

Em modo Uncertainty (P01-P08), source-quality hierarchy aplica.
Para claims sobre produto Anthropic:

```
peso 1.0 → docs.claude.com/* com data ≤ 90 dias
peso 0.9 → support.claude.com/* com data ≤ 90 dias
peso 0.7 → blog.anthropic.com com data ≤ 30 dias
peso 0.4 → press release de terceiros sobre Anthropic
peso 0.0 → memória do modelo (treinamento) — DESCARTAR
```

Nunca usar peso da memória do modelo. Sempre buscar.

---

## Trigger — Product Knowledge Gate

Auto-invoca em x-ray-abs quando detectar nos inputs ou outputs:

```
Termos: "Claude" + "[modelo|model|token|limit|MCP|API|plan|tier|rate]"
        "Anthropic" + "[pricing|feature|capability|launch|update]"
        "Claude Code" + qualquer palavra
        "Claude.ai" + "[Pro|Team|Enterprise|free|plan]"
```

Quando detectar → **bloquear output** até confirmação via
product-self-knowledge.

Nota: este gate é **silencioso** — não exposto ao usuário no output.
Apenas garante que claims sejam ground-truthed.
