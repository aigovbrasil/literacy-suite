# Canvas Bridge — Reference Card

ID         : XRAY-REF-CANVAS-V1
LABEL      : x-ray-abs → visual-canvas-studio bridge
TYPE       : Reference (loadable by SKILL.md)
DOMAIN     : Skill Composition · Output Rendering
PROJECT    : x-ray-abs v2.0.0
LANGUAGE   : PT-BR (consultor) + EN (engineering)
STATUS     : READY
EPISTEMIC  : FACT (modes + triggers verificados em /mnt/skills/user/visual-canvas-studio/SKILL.md em 2026-04-29)
CREATED    : 2026-04-29

---

## TL;DR — Quando carregar este arquivo

- Render Bridge offer foi acionado (PASSO 5 da SKILL.md)
- Usuário invocou trigger explícito de canvas
- Decidir qual modo visual aplicar a um diagnóstico específico

NÃO carregar em outputs parciais (single-bloco · self-audit · YAML).

---

## 1. Tabela 1 — Lente x-ray → Modo Canvas (mapping operacional)

Cada lente do x-ray-abs tem 1 modo primário e 1 alternativa.
Default global: Executive Swiss (quando ambíguo).

| Lente x-ray         | Modo primário          | Alternativa            | Output format        |
|---------------------|------------------------|------------------------|----------------------|
| `técnica`           | Linear/Vercel          | Bloomberg Terminal     | single HTML          |
| `business-model`    | Executive Swiss        | McKinsey Consulting    | PDF-style HTML       |
| `data-driven`       | Enterprise Dashboard   | Bloomberg Terminal     | single HTML interativo|
| `mercado`           | McKinsey Consulting    | Editorial Premium      | PDF-style HTML       |
| `operacional`       | Enterprise Dashboard   | Material Design        | single HTML interativo|
| `risco` ⚠️           | Executive Swiss        | (não usar alternativa) | PDF-style HTML       |
| `proposta`          | Executive Swiss        | McKinsey Consulting    | PDF-style HTML       |
| `self-audit`        | NÃO RENDERIZAR         | —                      | —                    |

⚠️ Lente `risco` tem checkpoint LGPD adicional — ver Seção 4.

---

## 2. Tabela 2 — Modos Canvas Disponíveis (verbatim de visual-canvas-studio)

Verificado em `/mnt/skills/user/visual-canvas-studio/SKILL.md` linhas 90-101.

| Modo                 | Quando usar                                       | Sinal de paleta          |
|----------------------|---------------------------------------------------|--------------------------|
| Executive Swiss      | Reports, PDFs, proposals, B2B decks               | Navy #1A2744 + slate     |
| SaaS Premium         | Landing pages, product, AI-first                  | Gradient cards           |
| Enterprise Dashboard | Ops panels, metrics, BI tools                     | Dense gray + blue accent |
| Public Service       | Forms, onboarding, questionnaires                 | High contrast            |
| Editorial Premium    | Manifestos, whitepapers, thought-leadership       | Serif/sans contrast      |
| McKinsey Consulting  | Strategy decks, due diligence                     | Navy #1A2744 boxed       |
| Bloomberg Terminal   | Data cockpits, high-density metrics               | Dark bg + functional     |
| Apple Product        | Premium UX, consumer product                      | White + generous space   |
| Material Design      | Apps, dashboards, prototypes                      | Cards with elevation     |
| Linear/Vercel        | Dev tools, AI product, SaaS tech                  | Dark/neutral thin        |

Modo padrão de visual-canvas-studio: **Executive Swiss**.

---

## 3. Tabela 3 — Trigger Phrases (copy-paste ready)

Frases que ativam visual-canvas-studio diretamente (verbatim do
SKILL.md daquela skill, linhas 7-13). Use em mensagens novas para
forçar o handoff.

### 3.1 Triggers genéricos (qualquer modo)

```
generate a canvas
make an interactive artifact
visual canvas
interactive business report
PDF-style document
business lab
style selector
theme switcher
design system
build an artifact with style modes
```

### 3.2 Triggers por modo (forçar modo específico)

```
create with Swiss style          → Executive Swiss
use McKinsey style               → McKinsey Consulting
SaaS premium layout              → SaaS Premium
```

Para os 7 modos sem trigger explícito documentado, usar fórmula:
```
render como <Modo Exato>
exemplo: render como Bloomberg Terminal
exemplo: render como Linear/Vercel
exemplo: render como Enterprise Dashboard
```

### 3.3 Triggers PT-BR (compatíveis com offer da SKILL.md PASSO 5)

```
render como Executive Swiss
render como McKinsey
dashboard do diagnóstico
relatório executivo PDF
proposta visual
artefato interativo
```

---

## 4. LGPD Checkpoints — Render com dados sensíveis

Aplicar antes de invocar canvas em qualquer um destes casos:

| Cenário                                         | Ação obrigatória                       |
|-------------------------------------------------|----------------------------------------|
| Diagnóstico contém nomes de clientes finais     | Anonimizar antes do render             |
| Output cita CPFs · CNPJs · e-mails · telefones  | Substituir por placeholders            |
| Lente = `risco` com dados de saúde/financeiros  | NÃO renderizar · oferecer só sumário   |
| Artefato será compartilhado externamente        | Confirmar consentimento dos titulares  |
| Cliente PME tem incidente LGPD em curso         | Suspender render · ativar protocolo E2 |

Regra: artefato HTML é facilmente compartilhável fora do contexto
controlado. Toda informação que entra no artefato é potencialmente
exposta. Em dúvida, suprimir.

Para detalhes legais → `references/commercial-disclosures.md`.

---

## 5. Receitas de Invocação (copy-paste para consultor)

### 5.1 Diagnóstico business-model → proposta para cliente

Sequência completa:
```
1. Operar x-ray-abs com lente=business-model
2. Após Síntese Executiva, copiar todo o output
3. Iniciar nova mensagem: "render como Executive Swiss"
4. Visual-canvas-studio gera PDF-style HTML A4
5. present_files retorna link para download
```

### 5.2 Diagnóstico data-driven → dashboard para founder

```
1. Operar x-ray-abs com lente=data-driven (web_search ativo)
2. Garantir que BLOCO B contém dados sourced
3. Mensagem: "dashboard do diagnóstico" ou "render como Enterprise Dashboard"
4. Visual-canvas-studio gera single HTML interativo com KPI cards
```

### 5.3 Diagnóstico mercado → due diligence deck

```
1. Operar x-ray-abs com lente=mercado (web_search obrigatório)
2. BLOCO B precisa ter ≥3 fontes primárias citadas
3. Mensagem: "render como McKinsey Consulting"
4. Output: HTML A4 com structure boxed insights
```

### 5.4 Diagnóstico técnica → spec doc para dev

```
1. Operar x-ray-abs com lente=técnica
2. BLOCO A mermaid deve ter detalhe de arquitetura
3. Mensagem: "render como Linear/Vercel" ou "render como Bloomberg Terminal"
4. Output: dark single HTML com code blocks renderizados
```

### 5.5 Self-audit — NÃO renderizar

```
Self-audit produz tabela ✅⚠️❌ que NÃO deve virar artefato comercial.
Se o usuário pedir explicitamente render de self-audit:
"Self-audit é instrumento interno de qualidade. Recomendo render do
diagnóstico subjacente, não da auditoria. Quer prosseguir mesmo assim?"
```

---

## 6. Anti-patterns

- Renderizar sem ter rodado x-ray-abs antes (canvas vira mock visual)
- Renderizar lente `risco` sem checkpoint LGPD da Seção 4
- Forçar modo McKinsey em diagnóstico técnica (mismatch de tom)
- Misturar modos no mesmo artefato sem theme-factory layer
- Renderizar self-audit como se fosse deliverable comercial

---

## 7. Pipeline completo (referência visual)

```
                  raw_input do consultor
                         │
                         ▼
              ┌────────────────────┐
              │   x-ray-abs        │ ← esta skill
              │   diagnostic synth │
              └────────┬───────────┘
                       │
                       │ output FULL (Blocos A+B+C)
                       │
                       ▼
              ┌────────────────────┐
              │   Render Bridge    │ ← PASSO 5 da SKILL.md
              │   1-line offer     │   (italic PT-BR)
              └────────┬───────────┘
                       │
                       │ usuário aceita · ou aciona explícito
                       │
                       ▼
              ┌────────────────────┐
              │ visual-canvas-     │ ← esta bridge
              │ studio             │   mapeia lente → modo
              │ (10 modos)         │
              └────────┬───────────┘
                       │
                       ▼
                  artefato HTML/SVG/PDF
                       │
                       ▼
                 deliverable cliente
```
