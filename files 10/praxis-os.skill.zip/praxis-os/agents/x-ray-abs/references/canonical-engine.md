# Canonical Engine — consultoria_canonical.json Integration

Fonte: `consultoria_canonical.json` (X-RAY-FORM-CANONICAL-v1)

19 fases · 13 gates · 100+ deliverables. Este arquivo mapeia o schema
canônico de consultoria para o fluxo operacional de x-ray-abs.

---

## Quando consultar este arquivo

- Usuário diz "qual fase estou?", "estou no D5 ou D20?", "qual gate?"
- Usuário envia briefing/diagnóstico e pede classificação D-day
- Usuário pede plano por fase (S00→S19)
- Usuário pergunta deliverables de uma fase específica
- Output de x-ray-abs precisa declarar `executive_context.stage`
- Handoff para x-ray-db precisa preencher `roadmap[].phase` + `roadmap[].gate`

---

## Tabela Mestre — 19 Fases × Gates × D-Day

```
ID    Nome                                    D-Day        Gate          Decisão
────  ──────────────────────────────────────  ───────────  ────────────  ──────────────
S00   Entrada/Qualificação                    D0           GATE-S00      Existe decisão real?
S01   Qualificação Empreendedor               D1-D3        GATE-S01      Fit? (go/reduce/no_go)
S02   Pergunta de Decisão                     D2           GATE-S02      Pergunta aprovada?
S03   Construção do Escopo                    D3-D4        GATE-S03      Escopo aprovado?
S04   Kickoff Oficial                         D4           GATE-S04 (G0) Condições mínimas?
S05   Diagnóstico Interno                     D5-D10       GATE-S05      Dados internos suficientes?
S06   Pesquisa Externa                        D10-D20      GATE-S06      Evidência de dor?
S07   Validação Qualitativa (entrevistas)     D15-D25      GATE-S07 (G1) Dor real+frequente+monetizável?
S08   Validação Quantitativa                  D20-D35      GATE-S08      Unit economics viável?
S09   Diagnóstico Integrado                   D25-D35      GATE-S09 (G2) Diagnóstico causal robusto?
S10   Opções Estratégicas                     D35-D45      GATE-S10 (G3) Opção superior?
S11   Testes Mínimos                          D40-D50      GATE-S11 (G4) Hipótese mínima validada?
S12   Recomendação Estratégica                D45          GATE-S12 (G5) Empreendedor aceita?
S13   Modelo de Negócio                       D45-D55      GATE-S13 (G6) Viável fin+ops?
S14   Roadmap 30/60/90                        D55-D65      GATE-S14 (G7) Plano executável?
S15   Ativos de Execução                      D65-D75      —             (sem gate · build phase)
S16   Piloto Assistido                        D75-D90      GATE-S16 (G8) Sinal positivo?
S17   Padronização                            D90-D105     GATE-S17 (G9) Empreendedor sozinho em sim?
S18   Transferência Conhecimento              D105-D115    GATE-S18 (G10) Método mínimo dominado?
S19   Handover Final                          D115-D120    GATE-S19 (G11) Pronto para operar sem consultoria?
S20   Acompanhamento Opcional                 D120+        GATE-S20 (G12) Autonomia consolidada?
```

---

## Decision Question — 10 perguntas mestras

Toda Decision Question (PASSO 0 do x-ray-abs) deve ancorar em UMA destas 10:

```
DQ-1  Existe uma decisão clara?
DQ-2  Existe fit entre empreendedor e oportunidade?
DQ-3  Existe dor real no mercado?
DQ-4  Existe disposição a pagar?
DQ-5  Existe canal de aquisição viável?
DQ-6  Existe modelo econômico aceitável?
DQ-7  Existe oferta simples o bastante para começar?
DQ-8  Existe piloto com sinal positivo?
DQ-9  Existe processo repetível?
DQ-10 O empreendedor consegue operar sozinho?
```

Mapeamento DQ → Fase principal:
- DQ-1 → S00, S02
- DQ-2 → S01
- DQ-3 → S06, S07
- DQ-4 → S07, S08
- DQ-5 → S08, S11
- DQ-6 → S08, S13
- DQ-7 → S12, S13
- DQ-8 → S16
- DQ-9 → S17
- DQ-10 → S18, S19

---

## Cadeia de Dependência Crítica

```
Sem DQ          → não há escopo
Sem escopo      → não há análise objetiva
Sem hipótese    → não há validação
Sem validação   → não há recomendação
Sem recomendação→ não há roadmap
Sem roadmap     → não há execução
Sem piloto      → não há aprendizado real
Sem padronização→ não há escala
Sem transferência → há dependência da consultoria
```

Use esta cadeia para identificar **onde a operação trava**. Travamento
em qualquer elo invalida tudo a jusante.

---

## Fórmulas de Scoring (5 fórmulas canônicas)

### SCORE-01 — Prioridade Simples (S06, S07, S08)
```
Prioridade = Impacto × Confiança ÷ Esforço
```

### SCORE-02 — Prioridade Completa (S08, S09, S10) ⭐ usado em x-ray-abs BLOCO D
```
Score = (Impacto × Urgência × Confiança × Fit) ÷ (Esforço × Risco)
```
**Esta é a fórmula oficial do x-ray-abs.**

### SCORE-03 — Potencial de Mercado (S05, S06)
```
Potencial = Volume_Problema × Intensidade_Dor × Capacidade_Pagar
```

### SCORE-04 — Cálculo de Gap (S07, S08)
```
Gap = Meta - Resultado_Atual
```

### SCORE-05 — Funil de Conversão (S07, S12)
```
Conversão_total = Compras ÷ Visitas_Totais
CTR_botão       = Cliques ÷ Visitas
Taxa_checkout   = Chegaram_checkout ÷ Cliques
Taxa_compra     = Compras ÷ Chegaram_checkout
```

---

## Sinais de Dor — Checklist S06/S07

Quando lente=`mercado` ou `business-model` e DQ tipo DQ-3 ou DQ-4:

```
[ ] Cliente reclama repetidamente do mesmo problema
[ ] Empresas já pagam por soluções alternativas
[ ] O problema custa tempo ou dinheiro mensurável
[ ] Dor aparece em reviews + fóruns + redes + entrevistas
[ ] Há urgência declarada
[ ] Há orçamento disponível ou alocado
[ ] O decisor reconhece o problema
[ ] A solução atual é cara, lenta ou ruim
```

≥ 5 marcados → dor confirmada (GATE-S07 GO).
≤ 3 marcados → pivot_segment ou no_go.

---

## Critério Go/No-Go por Gate

```
GATE-S00  GO se DQ formulada como pergunta específica/comparável/decidível
GATE-S01  GO se fit ≥ 6/10 · reduce_scope se 4-5 · no_go se < 4
GATE-S02  GO se DQ aprovada pelo empreendedor
GATE-S03  GO se escopo + cronograma + responsabilidades aceitos
GATE-S04  GO se 5/5 condições do kickoff confirmadas
GATE-S05  GO se fatos > suposições no diagnóstico interno
GATE-S06  GO se ≥ 5 sinais de dor + TAM/SAM/SOM estimados
GATE-S07  GO se dor real+frequente+monetizável em ≥ 60% das entrevistas
GATE-S08  GO se LTV > CAC + margem positiva + break-even alcançável
GATE-S09  GO se diagnóstico causal (não só sintomático)
GATE-S10  GO se uma opção tem score dominante + fit claro
GATE-S11  GO se hipótese mínima validada (intent-to-pay ou pagamento)
GATE-S12  GO se empreendedor aceita recomendação E assume risco
GATE-S13  GO se margem positiva + capacidade compatível
GATE-S14  GO se plano executável com recursos atuais
GATE-S16  GO se piloto: cliente pagou + valor percebido + processo repetível
GATE-S17  GO se simulação de operação solo bem-sucedida
GATE-S18  GO se método mínimo dominado (medir→interpretar→decidir→executar)
GATE-S19  GO se 5 condições de handover atendidas
```

---

## 5 Condições de Handover (S19)

Todas devem ser TRUE para autonomia:

```
HOV-1 Clareza estratégica   → sabe público + oferta + canal + meta
HOV-2 Sistema de métricas   → sabe quais números acompanhar
HOV-3 Rotina de decisão     → sabe quando mudar/continuar/parar
HOV-4 Documentação ops      → existe passo a passo escrito
HOV-5 Autonomia crítica     → entende critérios, não só executa ordens
```

Estas 5 são as mesmas do PASSO 7 (Autonomy Endpoint) do x-ray-abs.

---

## Pontos onde APENAS o empreendedor decide

x-ray-abs **orienta**, não substitui. Estes pontos são exclusivos:

1. Define objetivo principal do projeto
2. Aprova escopo
3. Aprova Decision Question
4. Define quais riscos aceita
5. Escolhe qual recomendação seguir
6. Decide crescer · preservar caixa · pivotar · pausar
7. Assume execução do plano
8. Decide sobre extensão da consultoria

**Princípio:** _Data-driven não elimina julgamento. Organiza o julgamento._

---

## Trigger — Canonical Engine Mode

Ativar este mode quando:
- Input é briefing extenso (> 500 palavras) com sinais de fase específica
- Usuário pergunta "qual fase?", "qual gate?", "qual deliverable de Sxx?"
- Output precisa declarar `project.stage` ou `roadmap[].phase` em handoff x-ray-db
- Usuário pede comparação entre fases ("estou em S06 ou S07?")

Comportamento:
1. Identificar fase atual via D-day OU sinais qualitativos
2. Listar deliverables esperados para a fase
3. Identificar gate aplicável + critério Go/No-Go
4. Usar fórmula de scoring correspondente (SCORE-01 a SCORE-05)
5. Marcar deliverables ausentes como `GAP-XX` no BLOCO C de x-ray-abs
