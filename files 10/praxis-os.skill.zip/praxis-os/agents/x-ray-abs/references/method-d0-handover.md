# Método D0→Handover — Reference Card

ID         : XRAY-REF-METHOD-V1
LABEL      : D0→Handover Methodology Compact Reference
TYPE       : Reference (loadable by SKILL.md)
DOMAIN     : Consulting Methodology
PROJECT    : x-ray-abs v2.0.0
LANGUAGE   : PT-BR
STATUS     : READY
EPISTEMIC  : FACT (extraído da especificação metodológica fonte)
CREATED    : 2026-04-29

---

## TL;DR — Quando carregar este arquivo

- Decidir estágio do cliente (D5? D20? D75?) → consultar Tabela 1
- Justificar gate (G2 robustez? G6 viabilidade?) → consultar Tabela 2
- Calcular Score numérico → consultar Seção 4
- Aplicar critério de autonomy endpoint → consultar Seção 5

NÃO ler em diagnósticos de lente única e baixa complexidade.

---

## 1. Tabela 1 — As 19 Fases (D0 → D120+)

| Fase  | Janela        | Foco                                      | Deliverable principal              | Gate de saída |
|-------|---------------|-------------------------------------------|------------------------------------|---------------|
| D0    | Entry         | Contato inicial · escopo bruto            | Decision Question rascunhada       | G0            |
| D1    | D0+1 a D5     | Levantamento contextual                   | Mapa de stakeholders               | —             |
| D5    | D5            | Validação da dor real                     | Hypothesis log v0                  | G1            |
| D5-10 | janela        | Diagnóstico inicial                       | Problem tree v0                    | —             |
| D10-15| janela        | Coleta quantitativa                       | Baseline metrics                   | —             |
| D15-20| janela        | Diagnóstico aprofundado                   | Problem tree v1 com evidências     | G2            |
| D20   | D20           | Geração de opções                         | Options portfolio (3-5 opções)     | —             |
| D20-25| janela        | Comparação de opções                      | Scoring matrix v0                  | —             |
| D25-30| janela        | Modelo da opção vencedora                 | Operating model rascunhado         | —             |
| D30-35| janela        | Validação de hipótese                     | Validation report                  | G3 + G4       |
| D35   | D35           | Decisão de avançar                        | Go/No-go assinado                  | —             |
| D35-50| janela        | Modelagem financeira                      | Pro-forma 12 meses                 | —             |
| D50-65| janela        | Análise de viabilidade                    | Sensitivity analysis               | G6            |
| D65-75| janela        | Preparação de piloto                      | Pilot blueprint                    | —             |
| D75-90| janela        | Execução do piloto                        | Pilot results                      | G8            |
| D90-100| janela       | Análise pós-piloto                        | Learning report                    | —             |
| D100-115| janela     | Simulação de operação solo do founder     | Solo simulation log                | G9            |
| D115  | D115          | Handover                                  | Handover package                   | G10           |
| D120+ | Optional      | Suporte residual · medição de autonomia   | —                                  | —             |

Convenção: "janela" = intervalo aceitável; cliente pode acelerar/atrasar
mas a sequência de gates é imutável.

---

## 2. Tabela 2 — Os 11 Gates

| Gate  | Pergunta binária                                         | Bloqueia se          | Destrava                              |
|-------|----------------------------------------------------------|----------------------|---------------------------------------|
| G0    | As condições de início estão presentes?                  | Sem stakeholder      | Início formal do engagement           |
| G1    | A dor é real, não percebida?                             | Hipótese não validada| Aprofundamento diagnóstico (D5+)      |
| G2    | O diagnóstico é robusto e tem evidência?                 | Sample insuficiente  | Geração de opções (D20)               |
| G3    | A opção escolhida é superior às alternativas?            | Comparação não feita | Modelagem detalhada (D25)             |
| G4    | A hipótese central foi validada empiricamente?           | Sem teste            | Modelagem financeira (D35)            |
| G5    | O escopo de execução está acordado e assinado?           | Sem assinatura       | Início da fase de execução            |
| G6    | A opção é financeiramente viável (pro-forma + sens)?     | NPV negativo         | Preparação de piloto (D65)            |
| G7    | Os recursos para piloto estão alocados?                  | Sem capacity         | Início do piloto (D75)                |
| G8    | O piloto gerou sinal positivo (KPI primário)?            | Sinal nulo/negativo  | Análise pós-piloto + decisão escala   |
| G9    | O founder consegue operar solo (medir/decidir/executar)? | Dependência residual | Handover formal (D115)                |
| G10   | Domínio do método foi transferido?                       | Sem master-trace     | Encerramento do engagement            |

Notas:
- G5 (escopo assinado) é gate comercial · pode acontecer entre D35-50.
- G7 não é numerado em algumas versões da metodologia · tratado como
  pré-requisito operacional de G8.

---

## 3. Cadeia de Dependências (não pular elos)

```
decision_question
   └── scope
       └── analysis
           └── hypothesis
               └── validation
                   └── recommendation
                       └── roadmap
                           └── execution
                               └── learning
                                   └── scale
                                       └── transfer
                                           └── autonomy
```

Regra absoluta: nenhum elo pode ser pulado. Tentar pular gera dívida
metodológica que aparece como blocker em diagnósticos posteriores.

Mapa de elos para fases:
- decision_question → D0
- scope → D1
- analysis → D5-D20
- hypothesis → D20-D30
- validation → D30-D35
- recommendation → D35
- roadmap → D35-D65
- execution → D75-D90
- learning → D90-D100
- scale → D100-D115 (decisão pós-piloto)
- transfer → D115
- autonomy → D120+

---

## 4. Fórmula de Scoring — Aplicação Operacional

### 4.1 Fórmula

```
Score = (Impacto × Urgência × Confiança × Fit) ÷ (Esforço × Risco)
```

### 4.2 Escalas e convenções

| Dimensão  | Símbolo | Escala     | Definição operacional                       |
|-----------|---------|------------|---------------------------------------------|
| Impacto   | I       | 1-10       | Tamanho do efeito esperado se realizado     |
| Urgência  | U       | 1-10       | Custo de atrasar a ação em 1 trimestre      |
| Confiança | C       | 0.0-1.0    | Probabilidade subjetiva das estimativas     |
| Fit       | F       | 1-10       | Alinhamento estratégico com tese vigente    |
| Esforço   | E       | 1-10       | Pessoa-meses (ou equivalente normalizado)   |
| Risco     | R       | 1-10       | Variância negativa esperada do resultado    |

Convenção C: usar buckets RICE-like — 1.0 alta · 0.8 média · 0.5 baixa ·
0.3 moonshot. Evitar valores arbitrários intermediários.

### 4.3 Limiares de leitura

| Score range | Leitura                          | Ação recomendada              |
|-------------|----------------------------------|-------------------------------|
| > 100       | Quick win dominante              | Executar imediatamente        |
| 30 — 100    | Ação imediata                    | Próximo gate de execução      |
| 5 — 30      | Backlog priorizado               | Sequenciar conforme capacity  |
| 1 — 5       | Postergar                        | Re-scorear em próxima rodada  |
| < 1         | Vaidade ou armadilha             | Descartar com justificativa   |

### 4.4 Exemplo numérico (validação da fórmula)

I=8 · U=9 · C=0.7 · F=6 · E=2 · R=1
Score = (8 × 9 × 0.7 × 6) ÷ (2 × 1) = 302.4 ÷ 2 = **151.20** ✓

I=4 · U=3 · C=0.9 · F=5 · E=8 · R=2
Score = (4 × 3 × 0.9 × 5) ÷ (8 × 2) = 54 ÷ 16 = **3.38** ✓

### 4.5 Anti-patterns de scoring (não fazer)

- Inflar C para validar item já decidido emocionalmente
- Usar C = 1.0 sem evidência primária (FACT/SOURCED)
- Comparar scores entre lentes diferentes sem normalização
- Re-scorear apenas itens favoritos (viés de confirmação)
- Esquecer que scoring é ferramenta de discussão, não veredito

---

## 5. Autonomy Endpoint — Definição Binária

### 5.1 Definição

A skill, o consultor e o método concluem quando o founder/operador
opera o negócio — mede, interpreta, decide, executa — sem solicitar
autorização adicional do consultor ou da skill.

### 5.2 Critérios binários (todos TRUE para handover)

| # | Critério                                                       | Verificação                            |
|---|----------------------------------------------------------------|----------------------------------------|
| 1 | Decision Question respondida com critério de sucesso explícito | Síntese Executiva linha 1              |
| 2 | Top-1 ação imediata identificada                               | BLOCO C 🎯 ou BLOCO D rank 1            |
| 3 | Próximo gate de decisão nomeado                                | Próximos Passos · gate explícito       |
| 4 | Riscos residuais registrados com IDs                           | BLOCO C ⚠️ · IDs RISCO-XX              |
| 5 | Critério AVANÇAR/PAUSAR/PIVOTAR emitido                        | Síntese Executiva linha final          |

### 5.3 Falha de handover — protocolo

Se algum critério for FALSE:
- Síntese Executiva DEVE declarar `[HANDOVER INCOMPLETO — falta: <critério>]`
- Não emitir Render Bridge (PASSO 5 da SKILL.md)
- Não anunciar autonomy endpoint atingido
- Recomendar fase remediadora (geralmente volta para D20-35)

---

## 6. Glossário rápido

- **D-XX:** dia/janela do método relativo ao D0 (entrada)
- **G-X:** gate de decisão · binário · não negociável
- **DQ:** Decision Question
- **Pro-forma:** projeção financeira 12 meses
- **Solo simulation:** founder opera 30 dias sem consultor (D100-115)
- **Master-trace:** evidência registrada de domínio metodológico

---

## 7. Mapa rápido lente x-ray-abs → fase do método

Quando atender um cliente novo via x-ray-abs, mapear lente para
fase aproximada para escolher a profundidade da análise:

| Lente x-ray-abs    | Fase típica do método  | Gate prioritário |
|--------------------|------------------------|------------------|
| `técnica`          | D5-D20                 | G2               |
| `business-model`   | D20-D35                | G3 + G6          |
| `data-driven`      | D5-D20 ou D90-D100     | G2 ou pós-G8     |
| `mercado`          | D5-D20                 | G1 + G2          |
| `operacional`      | D75-D100               | G8               |
| `risco`            | qualquer fase          | gate vigente     |
| `proposta`         | D35 ou D115            | G5 ou G10        |
| `self-audit`       | n/a                    | n/a              |
