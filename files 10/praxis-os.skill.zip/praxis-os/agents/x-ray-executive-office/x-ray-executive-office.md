---
description: Gera dashboard interativo de acompanhamento de execução X-Ray — sprint tracker estilo Kanban com fases canônicas S00–S20, gates G0–G12, e tasks decompostas. Modo consultor (visão completa +
  edição) e modo cliente (visão somente-leitura, sem dados sensíveis). ATIVE SEMPRE para "executive office X-Ray", "dashboard de execução", "sprint tracker do caso", "kanban X-Ray", "/x-ray-deliver dashboard",
  "acompanhar progresso do caso", "visão executiva do plano de ação", "tracker de fases canônicas", "embed do executive office no ebook". TAMBÉM ATIVE quando o consultor pedir uma visualização interativa
  do plano_acao.md, ou quando o cliente Toni precisar ver progresso visual do plano dele. NÃO ATIVE para criar issues no Linear (use projects-to-linear) ou para análise estratégica (use x-ray-abs).
name: x-ray-executive-office
---

# X-Ray Executive Office

Dashboard React/JSX standalone que renderiza o estado de execução de um caso X-Ray como sprint tracker visual. Adaptação do padrão remixed-tsx (sprint kanban) para o domínio canonical X-Ray (fases S00–S20, gates G0–G12).

## Dois modos de operação

| Modo | Audiência | Permissões | Dados visíveis |
|---|---|---|---|
| **consultor** | Rogerinho | Read + Write (toggle status, adicionar notas) | Tudo: hipóteses, riscos, tensões, decisões |
| **cliente** | Toni | Read-only | Apenas: tasks, status, prazos, marcos visíveis. Nenhuma hipótese ou tensão estratégica. |

A skill recebe `mode` como input obrigatório. Nunca renderize modo cliente com dados de modo consultor — auditoria de privacidade é parte do contrato.

## Inputs

1. `consultant_config.yaml` — brand do consultor
2. `mode` — `consultor` ou `cliente`
3. `case_id` — ID do caso X-Ray
4. Para modo consultor: `plano_acao.md`, `decision_log.md`, `risks.md`, `hypotheses_log.md`
5. Para modo cliente: apenas `plano_acao.md` filtrado (campos públicos)

Se `mode = cliente` e algum dado sensível for tentado: pare e remova antes de renderizar. **Vazamento aqui quebra confiança do consultor com o cliente.**

## Estrutura do dashboard

### Header
- Logo do consultor + nome do caso
- Linha do tempo do caso (data de início → data atual → próximo gate)
- Contador: "Dia X de Y · Z% concluído"

### Sprint Timeline (canonical X-Ray)
Substitui SP-1..SP-5 do TSX original por fases canônicas X-Ray:

```
S00 → S05 → S10 → S15 → S20
INTAKE   DIAG    PLAN    EXEC    REVIEW
```

Cada bloco mostra: gate associado (G0–G12), status (upcoming/active/completed), % conclusão.

### Kanban Board (3 colunas)

| Coluna | Status | Comportamento (modo consultor) |
|---|---|---|
| A Fazer | not_started | Click em card avança para "Em Andamento" |
| Em Andamento | in_progress | Click avança para "Concluído" |
| Concluído | done | Click reseta para "A Fazer" (cycle) |

Modo cliente: cards são read-only. Click apenas expande detalhes.

### Cards (tasks)

Cada task vem do `plano_acao.md` (formato 5W2H decomposto):

```yaml
- id: ACT-001
  what: "Entrevistar 5 clientes-chave"
  why: "Validar hipótese sobre causa de churn"
  who: "Rogerinho + cliente"
  when: "2026-05-08 a 2026-05-15"
  where: "Remoto / videoconferência"
  how: "Roteiro estruturado de 30min, gravação opt-in"
  how_much: "8h de equipe"
  status: in_progress
  critical: true
  visible_to_client: true   # filtro para modo cliente
  gate_dependency: G3
```

Cards `visible_to_client: false` jamais aparecem no modo cliente.

### Painel de horas e capacidade

Réplica do TSX original mas adaptado:
- Horas alocadas por bloco (Intake / Diagnose / Plan / Execute / Review)
- Capacidade vs Planejado vs Burned
- Buffer percentage

### Reviews (modo consultor)
- EOD (end of day): 4 perguntas estruturadas
- EOW (end of week): 4 perguntas
- Triggers de alerta: 6 condições que disparam revisão

## Pipeline de geração

```
1. Leia consultant_config.yaml e mode
2. Leia plano_acao.md (sempre)
3. Se mode=consultor: leia decision_log, risks, hypotheses
4. Se mode=cliente: filtre tasks por visible_to_client=true
5. Aplique x-ray-brand-layer ao componente (cores e logo)
6. Compile o componente React/JSX como single-file HTML
   (use CDN: react@18, react-dom@18 via esm.sh; inline JSX via Babel standalone)
7. Salve em /mnt/user-data/outputs/{consultant_short}-{case_id}-office-{mode}.html
8. Apresente via present_files
```

Alternativa (preferida quando o output é embarcado em ebook): retorne JSX como string e deixe x-ray-onboarding-ebook fazer o embed inline.

## Tecnologia

Quando standalone:
- React 18 via esm.sh
- Babel standalone para JSX in-browser (acceptable trade-off para ebook self-contained)
- Tailwind via CDN (`<script src="https://cdn.tailwindcss.com"></script>`)
- lucide-react via esm.sh para ícones
- Estado local via `useState` — sem backend, persistência via `sessionStorage` apenas

Quando embarcado em ebook (preferido):
- JSX inline no `<script type="text/babel">`
- Mesmas dependências CDN do ebook host
- Estado isolado por instância (não compartilha com outros componentes do ebook)

## Brand discipline

- Cores: cabeçalhos e accents = consultant_primary
- Tipografia: Poppins (headings) + Lora (body) — sobrescrevíveis
- Bordas: square corners (radius 2px) para alinhar com FORGE Executive Swiss
- Status colors mantidos universais (verde/âmbar/vermelho/cinza) — não personalizam por consultor para preservar legibilidade

## Anti-patterns

- Não use Inter font
- Não embarque dados do consultor em modo cliente (private data leakage)
- Não dependa de localStorage — use useState ou sessionStorage
- Não faça chamadas de rede em runtime — dashboard é estático, dados embedded no HTML
- Não use animações pesadas (parallax, scroll effects) — overhead em mobile
- Não permita edição em modo cliente — read-only é contratual

## Output paths

- Standalone consultor: `/mnt/user-data/outputs/{consultant_short}-{case_id}-office-consultor.html`
- Standalone cliente: `/mnt/user-data/outputs/{consultant_short}-{case_id}-office-cliente.html`
- Embarcado em ebook: retorna string JSX para x-ray-onboarding-ebook

## Validação antes de entregar (modo cliente)

```
✓ Nenhum card com visible_to_client=false aparece
✓ Nenhuma referência a "hipótese", "risco", "tensão" no texto visível
✓ decision_log NÃO está embarcado
✓ Brand do consultor aplicada
✓ Read-only confirmado: tentativa de click em status não muda nada
✓ Nome do cliente final aparece no header (não o nome do consultor sozinho)
```

Falha em qualquer item bloqueia a entrega ao cliente.

## Relação com outras skills X-Ray

- Lê: plano_acao.md, decision_log.md, risks.md, hypotheses_log.md, consultant_config.yaml
- Chama: x-ray-brand-layer
- Embarcado em: x-ray-onboarding-ebook
- Roteado por: x-ray-self-knowledge → x-ray-orchestrator (`/x-ray-deliver dashboard`)
