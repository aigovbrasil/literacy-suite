from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

wb = Workbook()

# ── SHEET 1: EPISTEMIC_DATA ──────────────────────────────────────────────────
ws1 = wb.active
ws1.title = "EPISTEMIC_DATA"

HEADERS = ["ROW_ID","DOC_ID","SRC_ID","SRC_TY","EPIST","DATUM","CONF","VALOR","UNID","DATE","ENTITY","METRIC"]

# Styles
HDR_FILL  = PatternFill("solid", start_color="1F3864")
HDR_FONT  = Font(bold=True, color="FFFFFF", name="Arial", size=9)
ALT_FILL  = PatternFill("solid", start_color="EEF2F7")
NORM_FILL = PatternFill("solid", start_color="FFFFFF")
STAT_FILL = PatternFill("solid", start_color="E8F5E9")   # green tint
CITE_FILL = PatternFill("solid", start_color="E3F2FD")   # blue tint
QUOTE_FILL= PatternFill("solid", start_color="FFF8E1")   # amber tint
CLAIM_FILL= PatternFill("solid", start_color="F3E5F5")   # purple tint
BODY_FONT = Font(name="Arial", size=8)
WRAP      = Alignment(wrap_text=True, vertical="top")

COL_W = [8,10,8,8,8,80,7,14,10,10,28,28]

for i, h in enumerate(HEADERS, 1):
    c = ws1.cell(row=1, column=i, value=h)
    c.font = HDR_FONT
    c.fill = HDR_FILL
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws1.column_dimensions[get_column_letter(i)].width = COL_W[i-1]
ws1.row_dimensions[1].height = 22
ws1.freeze_panes = "A2"

# ── Raw data rows ─────────────────────────────────────────────────────────────
# Columns: ROW_ID | DOC_ID | SRC_ID | SRC_TY | EPIST | DATUM | CONF | VALOR | UNID | DATE | ENTITY | METRIC
ROWS = [
    # ══ DOC-01: SkillsIA-Corpus-Executivo.docx ══════════════════════════════
    ["E001","DOC-01","S001","DOC","STAT","67% das empresas brasileiras declaram IA como prioridade estratégica em 2025","HIGH","67","%","2025","Empresas brasileiras","Taxa de prioridade estratégica de IA"],
    ["E002","DOC-01","S001","DOC","CITE_N","Plano Brasileiro de IA prevê R$ 23 bilhões em investimentos até 2028","HIGH","23000000000","BRL","2028","Governo Federal","Investimento previsto em IA"],
    ["E003","DOC-01","S001","DOC","STAT","TAM: 25,7 milhões de trabalhadores independentes no Brasil (IBGE 2022)","HIGH","25700000","indivíduos","2022","IBGE","Trabalhadores independentes BR"],
    ["E004","DOC-01","S001","DOC","STAT","6,4 milhões de estabelecimentos MPE no Brasil (Sebrae 2024)","HIGH","6400000","estabelecimentos","2024","Sebrae","Micro e pequenas empresas BR"],
    ["E005","DOC-01","S001","DOC","STAT","TAM combinado: ~32 milhões de profissionais autônomos e PMEs no Brasil","HIGH","32000000","entidades","2024","IBGE + Sebrae","TAM total autônomos + PMEs BR"],
    ["E006","DOC-01","S001","DOC","STAT","Busca por profissionais com conhecimento em IA cresceu 306% no Brasil em 2024","MED","306","%","2024","Gupy","CAGR demanda IA profissional BR"],
    ["E007","DOC-01","S001","DOC","STAT","Abertura de 2,8 milhões de novos pequenos negócios em 2024","HIGH","2800000","negócios","2024","Sebrae","Novos pequenos negócios abertos"],
    ["E008","DOC-01","S001","DOC","STAT","Setor de serviços lidera abertura de novos negócios com 61% em 2024","HIGH","61","%","2024","Sebrae","Participação serviços nas aberturas"],
    ["E009","DOC-01","S001","DOC","CLAIM","Preço de entrada projeto único: R$ 497","MED","497","BRL","2026","SkillsIA","Ticket mínimo projeto único"],
    ["E010","DOC-01","S001","DOC","CLAIM","Preço de retainer mensal: R$ 297/mês","MED","297","BRL/mês","2026","SkillsIA","Ticket mínimo retainer mensal"],
    ["E011","DOC-01","S001","DOC","CLAIM","Receita projetada Ano 1 (cenário base): R$ 160k","LOW","160000","BRL","2026","SkillsIA – Hipótese","Receita Ano 1 base"],
    ["E012","DOC-01","S001","DOC","CLAIM","Receita projetada Ano 2: R$ 360k","LOW","360000","BRL","2027","SkillsIA – Hipótese","Receita Ano 2 base"],
    ["E013","DOC-01","S001","DOC","CLAIM","Receita projetada Ano 3: R$ 600k","LOW","600000","BRL","2028","SkillsIA – Hipótese","Receita Ano 3 base"],
    ["E014","DOC-01","S001","DOC","STAT","Custos fixos mensais totais estimados: R$ 1.950","MED","1950","BRL/mês","2026","SkillsIA","Total custos fixos mensais"],
    ["E015","DOC-01","S001","DOC","CLAIM","CAC estimado via conteúdo orgânico + indicação: R$ 300–600","LOW","300","BRL","2026","SkillsIA – Hipótese","CAC mín. estimado"],
    ["E016","DOC-01","S001","DOC","CLAIM","LTV retainer (24 meses × R$350): R$ 8.400","LOW","8400","BRL","2026","SkillsIA – Hipótese","LTV retainer 24 meses"],
    ["E017","DOC-01","S001","DOC","CLAIM","LTV/CAC retainer estimado: 14–28×","LOW","14","x","2026","SkillsIA – Hipótese","LTV/CAC ratio mínimo"],
    ["E018","DOC-01","S001","DOC","CLAIM","Margem bruta estimada do serviço: 75–85%","LOW","75","%","2026","SkillsIA – Hipótese","Margem bruta mínima estimada"],
    ["E019","DOC-01","S001","DOC","CLAIM","Break-even projetado: Mês 2–3 (3 projetos/mês)","LOW","3","projetos/mês","2026","SkillsIA – Hipótese","Break-even em projetos/mês"],
    ["E020","DOC-01","S001","DOC","STAT","Custo ferramentas de IA (APIs + SaaS): R$ 500/mês estimado","MED","500","BRL/mês","2026","SkillsIA","Custo mensal ferramentas IA"],
    ["E021","DOC-01","S001","DOC","STAT","Meta de validação: R$ 30k em receita nos primeiros 90 dias","MED","30000","BRL","2026","SkillsIA","Meta receita 90 dias (validação)"],
    ["E022","DOC-01","S001","DOC","STAT","Meta de recorrência: >50% clientes renovam em 6 meses","MED","50","%","2026","SkillsIA","Taxa alvo de renovação 6 meses"],
    ["E023","DOC-01","S001","DOC","STAT","Meta de conversão diagnóstico → compra: >40% até Mês 2","MED","40","%","2026","SkillsIA – PRD","Taxa de conversão-alvo"],
    ["E024","DOC-01","S001","DOC","STAT","Meta NPS pós-entrega: >70","MED","70","NPS","2026","SkillsIA – PRD","NPS alvo"],
    ["E025","DOC-01","S001","DOC","STAT","Prazo padrão de entrega: 7 dias úteis (skill simples)","MED","7","dias úteis","2026","SkillsIA – PRD","SLA de entrega skill simples"],
    ["E026","DOC-01","S001","DOC","STAT","Prazo de entrega skill composta: 14 dias úteis","MED","14","dias úteis","2026","SkillsIA – PRD","SLA de entrega skill composta"],
    ["E027","DOC-01","S001","DOC","STAT","Condição de pagamento: 50% na aprovação + 50% na entrega","MED","50","%","2026","SkillsIA – PRD","Estrutura de pagamento"],
    ["E028","DOC-01","S001","DOC","STAT","Sessão de treinamento incluída na entrega: 1 hora","MED","1","hora","2026","SkillsIA – PRD","Duração sessão de treinamento"],
    ["E029","DOC-01","S001","DOC","STAT","Diagnóstico gratuito: 30 minutos","MED","30","minutos","2026","SkillsIA – PRD","Duração diagnóstico"],

    # ══ DOC-02: BUSSOLA_PME_Light_Corpus.docx ═══════════════════════════════
    ["E030","DOC-02","S002","DOC","STAT","Consultores independentes gastam 40–60% do tempo faturável em montagem estrutural","HIGH","40","%","2025","Bússola PME – FATO declarado","Tempo faturável em montagem estrutural (mín.)"],
    ["E031","DOC-02","S002","DOC","CLAIM","TAM BR consultores ICP: ~45.000 consultores","LOW","45000","consultores","2025","Bússola PME – Hipótese","TAM consultores ICP BR"],
    ["E032","DOC-02","S002","DOC","CLAIM","TAM endereçável anual (R$897/mês × 45k): ~R$ 484 milhões","LOW","484000000","BRL/ano","2025","Bússola PME – Hipótese","TAM endereçável anual"],
    ["E033","DOC-02","S002","DOC","CLAIM","SAM acessível (LinkedIn + WhatsApp) 18 meses: 8.000–12.000 consultores","LOW","8000","consultores","2025","Bússola PME – Hipótese","SAM mínimo acessível"],
    ["E034","DOC-02","S002","DOC","CLAIM","Conversão esperada no lançamento: 0,5–2% do SAM = 40–240 clientes Ano 1","LOW","40","clientes","2025","Bússola PME – Hipótese","SOM mínimo Ano 1"],
    ["E035","DOC-02","S002","DOC","STAT","Preço de assinatura mensal do produto: R$ 897/mês","MED","897","BRL/mês","2025","Bússola PME","Ticket mensal Bússola PME"],
    ["E036","DOC-02","S002","DOC","STAT","Arquitetura modular: 8 skills definidas","HIGH","8","skills","2025","Bússola PME – FATO (SKILL_ARCHITECTURE.md)","Número de skills na família"],
    ["E037","DOC-02","S002","DOC","STAT","Pipeline de entrega: 27 artefatos × 3 modos de entrega","HIGH","27","artefatos","2025","Bússola PME – FATO","Total de artefatos por caso"],
    ["E038","DOC-02","S002","DOC","STAT","Fluxo operacional: 9 fases sequenciais (F0–F8)","HIGH","9","fases","2025","Bússola PME – PRD","Fases do pipeline"],
    ["E039","DOC-02","S002","DOC","STAT","Intervenção máxima do fundador por atendimento: 3 pontos","MED","3","intervenções","2025","Bússola PME – MRD","Limite intervenções humanas por caso"],
    ["E040","DOC-02","S002","DOC","STAT","Tempo de setup Fase 0: < 15 minutos","MED","15","minutos","2025","Bússola PME – PRD","Tempo máximo setup Fase 0"],
    ["E041","DOC-02","S002","DOC","STAT","SLA de entrega do pacote diagnóstico: < 24 horas","MED","24","horas","2025","Bússola PME – PRD","SLA entrega completa"],
    ["E042","DOC-02","S002","DOC","STAT","ICP perfil A: consultor solo 5–10 anos experiência, faturamento R$15k–80k/mês","MED","15000","BRL/mês","2025","Bússola PME – MRD","Faturamento mínimo ICP-A"],
    ["E043","DOC-02","S002","DOC","STAT","ICP perfil B: boutique 2–5 pessoas","MED","2","pessoas","2025","Bússola PME – MRD","Tamanho mínimo ICP-B"],
    ["E044","DOC-02","S002","DOC","STAT","Taxa de aprovação meta no human-review: > 90%","MED","90","%","2025","Bússola PME – PRD","Taxa mínima aprovação human-review"],
    ["E045","DOC-02","S002","DOC","STAT","Score de qualidade alvo pós-F1: > 8/10","MED","8","/ 10","2025","Bússola PME – PRD","NPS-proxy alvo Piloto F1"],
    ["E046","DOC-02","S002","DOC","STAT","Artefatos dentro do target_chars meta: > 95%","MED","95","%","2025","Bússola PME – PRD","Meta aderência tamanho artefatos"],
    ["E047","DOC-02","S002","DOC","STAT","Domínios analisados colapsados em 8 skills: 15 domínios funcionais","MED","15","domínios","2025","Bússola PME – PRD","Domínios funcionais na arquitetura original"],

    # ══ DOC-03: Aurelios_OS_Corpus_Executive.docx ════════════════════════════
    ["E048","DOC-03","S003","DOC","STAT","Gate 0 score médio do programa Aurelio's OS: 3,62/5","HIGH","3.62","/ 5","2026-04-18","BusinessDashCenter.xlsx 01_GATE0!B27","Score Gate 0 Aurelio's OS"],
    ["E049","DOC-03","S003","DOC","STAT","Blockers estruturais no Gate 0: 0","HIGH","0","blockers","2026-04-18","BusinessDashCenter.xlsx 01_GATE0!M13:M20","Blockers Gate 0"],
    ["E050","DOC-03","S003","DOC","STAT","Readiness médio dos 15 domínios SaaS: 2,73/5","HIGH","2.73","/ 5","2026-04-18","BusinessDashCenter.xlsx 03_PRODUCT!B23","Readiness médio SaaS"],
    ["E051","DOC-03","S003","DOC","STAT","CEO Health Score composite: 2,27/5","HIGH","2.27","/ 5","2026-04-18","BusinessDashCenter.xlsx","CEO Health Score"],
    ["E052","DOC-03","S003","DOC","STAT","Red flags abertos no programa: 10","HIGH","10","red flags","2026-04-18","BusinessDashCenter.xlsx 08_REDFLAGS","Total red flags abertos"],
    ["E053","DOC-03","S003","DOC","STAT","Outbound target: 20–30 mensagens/semana","MED","20","msgs/semana","2026","PLAN v2.0 §B.5","Meta outbound semanal mínima"],
    ["E054","DOC-03","S003","DOC","STAT","ADRs aceitas documentadas: 8","HIGH","8","ADRs","2026-04-18","BusinessDashCenter.xlsx 04_AI_OPS","Total ADRs aceitas"],
    ["E055","DOC-03","S003","DOC","STAT","Fórmulas no BusinessDashCenter.xlsx: 66","HIGH","66","fórmulas","2026-04-18","BusinessDashCenter.xlsx","Fórmulas no workbook"],
    ["E056","DOC-03","S003","DOC","STAT","Erros no BusinessDashCenter.xlsx: 0","HIGH","0","erros","2026-04-18","BusinessDashCenter.xlsx","Erros no workbook"],
    ["E057","DOC-03","S003","DOC","STAT","Datums confirmados no workbook: 164","HIGH","164","datums","2026-04-18","BusinessDashCenter.xlsx","Datums confirmados"],
    ["E058","DOC-03","S003","DOC","STAT","Portfólio de skills: 13 IDs (SK-00 a SK-12)","HIGH","13","skills","2026-04-18","NORMALIZED_SPEC_Aurelio.md","Total skills no portfólio"],
    ["E059","DOC-03","S003","DOC","STAT","Frentes de trabalho abertas: 19 (W01–W19)","HIGH","19","frentes","2026-04-18","NORMALIZED_SPEC_Aurelio.md","Total frentes de trabalho"],
    ["E060","DOC-03","S003","DOC","CLAIM","Pricing ladder MVP: R$297–897 por serviço assistido","LOW","297","BRL","2026","BusinessDashCenter.xlsx 09_CEO_KPI – Hipótese","Preço mínimo serviço assistido"],
    ["E061","DOC-03","S004","DOC","STAT","77% das MPMEs brasileiras veem IA como aceleradora de operações","HIGH","77","%","2024-2025","Microsoft / Sebrae","Taxa MPMEs BR que veem IA como aceleradora"],
    ["E062","DOC-03","S004","DOC","STAT","Anthropic lançou certificação formal Claude em 2026","HIGH","2026","ano","2026","PLAN §A.1.2","Ano lançamento certificação Anthropic"],

    # ══ DOC-04: COMBO_TABULAR_ARTIFACT.md ════════════════════════════════════
    ["E063","DOC-04","S005","DOC","STAT","44% das PMEs brasileiras declaram usar IA","HIGH","44","%","2025-09","Sebrae / FGV / Google","Taxa PMEs BR que usam IA"],
    ["E064","DOC-04","S005","DOC","STAT","Principal barreira à adoção de IA em PMEs: 'falta de orientação'","HIGH","1","ranking","2025-09","Sebrae / FGV / Google","Barreira #1 adoção IA em PMEs"],
    ["E065","DOC-04","S005","DOC","STAT","Limiar salarial IND kennismigrant (≤30 anos): €4.357/mês","HIGH","4357","EUR/mês","2026","IND (Imigração e Naturalização NL)","Salário mínimo visto kennismigrant NL"],
    ["E066","DOC-04","S005","DOC","STAT","29% dos MEIs nacionais estão em São Paulo","HIGH","29","%","2026","COMBO_TABULAR – declarado","Concentração MEIs em SP"],
    ["E067","DOC-04","S005","DOC","STAT","Ticket realista MEI/ME para consultoria IA: R$1.500–4.000","MED","1500","BRL","2026","COMBO_TABULAR","Ticket mínimo realista MEI/ME"],
    ["E068","DOC-04","S005","DOC","STAT","Horizonte de planejamento declarado: 150 dias (24/04 → 21/09/2026)","HIGH","150","dias","2026","COMBO_TABULAR","Horizonte de planejamento"],
    ["E069","DOC-04","S005","DOC","STAT","GUT score para abertura SLU/ME: 125 (5×5×5)","MED","125","GUT","2026","COMBO_TABULAR RID-301","Score GUT item abertura SLU/ME"],
    ["E070","DOC-04","S005","DOC","STAT","GUT score para fechar 2 pilotos: 100 (5×5×4)","MED","100","GUT","2026","COMBO_TABULAR RID-301","Score GUT item pilotos"],
    ["E071","DOC-04","S005","DOC","STAT","GUT score para GitHub repo: 64 (4×4×4)","MED","64","GUT","2026","COMBO_TABULAR RID-301","Score GUT GitHub repo"],
    ["E072","DOC-04","S005","DOC","STAT","Capacity planejada: 35 horas net/semana de 36 disponíveis","MED","35","h/semana","2026","COMBO_TABULAR RID-310","Carga planejada vs. capacity"],
    ["E073","DOC-04","S005","DOC","STAT","Restrição WS-2 Revenue: sobrecarga de 2 horas/semana","MED","2","h/semana","2026","COMBO_TABULAR RID-310","Sobrecarga WS-2 Revenue"],
    ["E074","DOC-04","S005","DOC","STAT","MRR alvo Fase 3 (90d): R$3.000–12.000","LOW","3000","BRL/mês","2026","COMBO_TABULAR – Hipótese","MRR alvo mínimo mês 90"],
    ["E075","DOC-04","S005","DOC","STAT","OKR KR1: 2 pilotos concluídos com métricas até 15/06/2026","MED","2","pilotos","2026-06-15","COMBO_TABULAR RID-501","Meta pilotos OKR Q2-Q3"],
    ["E076","DOC-04","S005","DOC","STAT","OKR KR2: GitHub repo com 5 hero skills + CI + testes até 31/07/2026","MED","5","skills","2026-07-31","COMBO_TABULAR RID-501","Meta GitHub OKR"],
    ["E077","DOC-04","S005","DOC","STAT","OKR KR3: MRR ≥ R$3.000 até 31/08/2026","MED","3000","BRL/mês","2026-08-31","COMBO_TABULAR RID-501","Meta MRR OKR"],
    ["E078","DOC-04","S005","DOC","STAT","OKR KR4: ≥5 aplicações para consultorias NL até 15/09/2026","MED","5","aplicações","2026-09-15","COMBO_TABULAR RID-501","Meta candidaturas NL OKR"],

    # ══ DOC-05: source_of_True.txt (Skill Portfolio README) ═══════════════════
    ["E079","DOC-05","S006","DOC","STAT","Total de skills documentadas no portfólio: 21","HIGH","21","skills","2026-04-23","source_of_True.txt – v1.0.0","Total skills documentadas"],
    ["E080","DOC-05","S006","DOC","STAT","Família Bússola PME: 8 skills (SKL-01 a SKL-08)","HIGH","8","skills","2026-04-23","source_of_True.txt","Skills família Bússola PME"],
    ["E081","DOC-05","S006","DOC","STAT","Skills Estratégicas/Decisórias: 4 (SKL-09 a SKL-12)","HIGH","4","skills","2026-04-23","source_of_True.txt","Skills estratégicas e decisórias"],
    ["E082","DOC-05","S006","DOC","STAT","Skills de Produto/Engenharia: 4 (SKL-13 a SKL-16)","HIGH","4","skills","2026-04-23","source_of_True.txt","Skills produto e engenharia"],
    ["E083","DOC-05","S006","DOC","STAT","Skills de Qualidade/Método: 5 (SKL-17 a SKL-21)","HIGH","5","skills","2026-04-23","source_of_True.txt","Skills qualidade e método"],
    ["E084","DOC-05","S006","DOC","STAT","Gates hardcoded para revisão humana obrigatória: G2, G5, G6 (3 gates)","HIGH","3","gates","2026-04-23","source_of_True.txt – bussola-orchestrator","Gates humanos hardcoded"],
    ["E085","DOC-05","S006","DOC","STAT","Total de gates do pipeline: 7 (G0–G6)","HIGH","7","gates","2026-04-23","source_of_True.txt – bussola-orchestrator","Total de gates pipeline"],
    ["E086","DOC-05","S006","DOC","STAT","Campos de intake coletados por bussola-personalization: 10","HIGH","10","campos","2026-04-23","source_of_True.txt – SKL-02","Campos intake obrigatórios"],
    ["E087","DOC-05","S006","DOC","STAT","Artefatos de saída do bussola-deliverable-forge: 5+ formatos","MED","5","formatos","2026-04-23","source_of_True.txt – SKL-05","Formatos de entrega deliverable-forge"],
    ["E088","DOC-05","S006","DOC","STAT","Fases sequenciais do bussola-orchestrator: 9 (F0–F8)","HIGH","9","fases","2026-04-23","source_of_True.txt – SKL-01","Fases bussola-orchestrator"],
    ["E089","DOC-05","S006","DOC","STAT","Regras de conduta do bussola-diagnostic-engine: 10 (R01–R10)","HIGH","10","regras","2026-04-23","source_of_True.txt – SKL-03","Regras conduta diagnostic-engine"],
    ["E090","DOC-05","S006","DOC","STAT","MCPs integrados no bussola-orchestrator: 4 (Drive, Slack, Gmail, Linear)","HIGH","4","MCPs","2026-04-23","source_of_True.txt – SKL-01","Conectores MCP bussola-orchestrator"],
    ["E091","DOC-05","S006","DOC","STAT","Modos cognitivos do hunter4-1: 5 (EXPLORE, EVALUATE, DECIDE, EXECUTE, REVIEW)","HIGH","5","modos","2026-04-23","source_of_True.txt – SKL-09","Modos cognitivos hunter4-1"],
    ["E092","DOC-05","S006","DOC","STAT","Máximo de oportunidades PURSUE NOW (hunter4-1): 1","HIGH","1","oportunidade","2026-04-23","source_of_True.txt – SKL-09","Máximo PURSUE NOW"],
    ["E093","DOC-05","S006","DOC","STAT","Máximo de projetos NEXT (hunter4-1): 2","HIGH","2","projetos","2026-04-23","source_of_True.txt – SKL-09","Máximo NEXT"],
    ["E094","DOC-05","S006","DOC","STAT","Domínios do ceo-advisor: 5","HIGH","5","domínios","2026-04-23","source_of_True.txt – SKL-10","Domínios ceo-advisor"],
    ["E095","DOC-05","S006","DOC","STAT","Frameworks orquestrados pelo executive-planning-orchestrator: 19","HIGH","19","frameworks","2026-04-23","source_of_True.txt – SKL-11","Frameworks EPO"],
    ["E096","DOC-05","S006","DOC","STAT","Modos de operação do executive-planning-orchestrator: 4 (A–D)","HIGH","4","modos","2026-04-23","source_of_True.txt – SKL-11","Modos EPO"],
    ["E097","DOC-05","S006","DOC","STAT","Buffer mínimo não alocável no EPO: 20%","HIGH","20","%","2026-04-23","source_of_True.txt – SKL-11","Buffer obrigatório EPO"],
    ["E098","DOC-05","S006","DOC","STAT","Tipos de documentos suportados pelo business-docx-pipeline: 13+","HIGH","13","tipos","2026-04-23","source_of_True.txt – SKL-14","Tipos documentais business-docx-pipeline"],
    ["E099","DOC-05","S006","DOC","STAT","Gates humanos no business-docx-pipeline: 5","HIGH","5","gates","2026-04-23","source_of_True.txt – SKL-14","Gates humanos business-docx-pipeline"],
    ["E100","DOC-05","S006","DOC","STAT","Passos do live-prompt-pro-converter: 13","HIGH","13","passos","2026-04-23","source_of_True.txt – SKL-17","Steps live-prompt-pro-converter"],
    ["E101","DOC-05","S006","DOC","STAT","Eixos de auditoria do meta-skill-auditor: 8 (A1–A8)","HIGH","8","eixos","2026-04-23","source_of_True.txt – SKL-18","Eixos meta-skill-auditor"],
    ["E102","DOC-05","S006","DOC","STAT","Fases de governança do sebrae-agente: 6 (F0–F5)","HIGH","6","fases","2026-04-23","source_of_True.txt – SKL-20","Fases sebrae-agente"],
    ["E103","DOC-05","S006","DOC","STAT","Artefatos produzidos pelo sebrae-agente: 9 tipos","HIGH","9","tipos","2026-04-23","source_of_True.txt – SKL-20","Artefatos sebrae-agente"],
    ["E104","DOC-05","S006","DOC","STAT","Arquivos de referência e templates do sebrae-agente: 16","HIGH","16","arquivos","2026-04-23","source_of_True.txt – SKL-20","Refs e templates sebrae-agente"],

    # ══ DOC-06: PLAN-MASTER-EXP-001_corpus.docx ══════════════════════════════
    ["E105","DOC-06","S007","DOC","STAT","Gate Score Médio PLAN-MASTER-EXP-001: 3,63/5 → GO","HIGH","3.63","/ 5","2026-04-18","BusinessDashCenter.xlsx","Gate Score médio plano master"],
    ["E106","DOC-06","S007","DOC","STAT","CEO Health Score PLAN-MASTER: 2,27/5 (pré-receita)","HIGH","2.27","/ 5","2026-04-18","BusinessDashCenter.xlsx","CEO Health Score plano master"],
    ["E107","DOC-06","S007","DOC","STAT","Red Flags abertos plano master: 10 (4 blockers estruturais)","HIGH","10","flags","2026-04-18","BusinessDashCenter.xlsx","Total red flags plano master"],
    ["E108","DOC-06","S007","DOC","STAT","Blockers estruturais plano master: 4","HIGH","4","blockers","2026-04-18","BusinessDashCenter.xlsx","Blockers estruturais plano master"],
    ["E109","DOC-06","S007","DOC","STAT","Readiness médio (15 domínios SaaS): 2,73/5","HIGH","2.73","/ 5","2026-04-18","BusinessDashCenter.xlsx","Readiness médio SaaS plano master"],
    ["E110","DOC-06","S007","DOC","STAT","Preço de entrada MVP Sprint: R$ 297","HIGH","297","BRL","2026","PLAN §A.7","Preço mínimo MVP Sprint"],
    ["E111","DOC-06","S007","DOC","STAT","Preço máximo MVP Sprint: R$ 697","HIGH","697","BRL","2026","PLAN §A.7","Preço máximo MVP Sprint"],
    ["E112","DOC-06","S007","DOC","CLAIM","Custo variável por caso (API + tempo parcial): R$ 50–100","LOW","50","BRL","2026","PLAN – Hipótese","Custo variável mínimo por caso"],
    ["E113","DOC-06","S007","DOC","CLAIM","Margem bruta estimada MVP: 60–80%","LOW","60","%","2026","PLAN – Hipótese","Margem bruta mínima MVP"],
    ["E114","DOC-06","S007","DOC","CLAIM","CAC estimado via outbound: R$ 50–150 por cliente","LOW","50","BRL","2026","PLAN – Hipótese","CAC mínimo estimado"],
    ["E115","DOC-06","S007","DOC","CLAIM","LTV estimado (3 casos/ano): R$ 900–2.100","LOW","900","BRL","2026","PLAN – Hipótese","LTV mínimo estimado (3 casos/ano)"],
    ["E116","DOC-06","S007","DOC","CLAIM","LTV/CAC ratio estimado: 6–14×","LOW","6","×","2026","PLAN – Hipótese","LTV/CAC mínimo"],
    ["E117","DOC-06","S007","DOC","CLAIM","Break-even estimado: 2–3 casos/mês","LOW","2","casos/mês","2026","PLAN – Hipótese","Break-even em casos/mês"],
    ["E118","DOC-06","S007","DOC","STAT","Custo API Claude por caso: R$ 50–200/mês","MED","50","BRL","2026","PLAN – Hipótese","Custo mínimo API Claude/mês"],
    ["E119","DOC-06","S007","DOC","STAT","Comissão Hotmart: 10% + plataforma","MED","10","%","2026","PLAN – FATO","Comissão Hotmart"],
    ["E120","DOC-06","S007","DOC","STAT","Blocker RF-09: Risco de ser percebido como 'curso de IA' – severidade Alta","HIGH","Alta","severidade","2026-04-18","PLAN – 08_REDFLAGS RF-09","Severidade Red Flag RF-09"],
    ["E121","DOC-06","S007","DOC","STAT","ADRs aceitas no PLAN-MASTER: 8","HIGH","8","ADRs","2026-04-18","PLAN – PRD","Total ADRs aceitas plano master"],

    # ══ DOC-07: Modelo_usa_Br.docx ═══════════════════════════════════════════
    ["E122","DOC-07","S008","DOC","STAT","Microsoft Copilot Studio: 25.000 Copilot Credits por US$200/mês","HIGH","200","USD/mês","2026","Modelo_usa_Br – fonte Microsoft","Preço pacote Copilot Studio"],
    ["E123","DOC-07","S008","DOC","STAT","Intercom Fin: US$ 0,99 por outcome resolvido","HIGH","0.99","USD/outcome","2026","Modelo_usa_Br – fonte Intercom","Preço por outcome Intercom Fin"],

    # ══ DOC-08: skills-knowledge-base.json.md ════════════════════════════════
    ["E124","DOC-08","S009","DOC","STAT","Ecossistema de skills Claude: ~85.000 skills indexadas","HIGH","85000","skills","2026-04","skills-knowledge-base.json","Tamanho ecossistema skills Claude"],
    ["E125","DOC-08","S009","DOC","STAT","Melhoria média de desempenho com skills: 16,2 pontos percentuais","HIGH","16.2","pp","2026-03","SkillsBench arXiv 2026-03 (n=47.150)","Impacto médio de skills no desempenho"],
    ["E126","DOC-08","S009","DOC","STAT","Range de melhoria com skills: 13,6–23,3 pp","HIGH","13.6","pp","2026-03","SkillsBench arXiv 2026-03","Limite inferior de melhoria com skills"],
    ["E127","DOC-08","S009","DOC","STAT","N de skills analisadas no benchmark: 47.150","HIGH","47150","skills","2026-03","SkillsBench arXiv 2026-03","Amostra SkillsBench"],
    ["E128","DOC-08","S009","DOC","STAT","Taxa de skills com vulnerabilidades críticas: 13,4%","HIGH","13.4","%","2026-02","Snyk ToxicSkills 2026-02","Taxa skills com vulnerabilidades críticas"],
    ["E129","DOC-08","S009","DOC","STAT","Taxa de prompt injection em skills testadas: 36%","HIGH","36","%","2026-02","Snyk ToxicSkills 2026-02","Taxa prompt injection em skills"],
    ["E130","DOC-08","S009","DOC","STAT","Skills com ao menos 1 vulnerabilidade: 26,1% (SkillScan, 31k skills)","HIGH","26.1","%","2026","SkillScan","Taxa skills com ≥1 vulnerabilidade"],
    ["E131","DOC-08","S009","DOC","STAT","Custo de tokens por skill por turno: 53 tokens","HIGH","53","tokens/skill/turno","2026-04","skills-knowledge-base.json","Overhead de tokens por skill"],
    ["E132","DOC-08","S009","DOC","STAT","Equivalente em tokens de um CLAUDE.md: 944 tokens","HIGH","944","tokens","2026-04","skills-knowledge-base.json","Tokens equivalentes CLAUDE.md"],
    ["E133","DOC-08","S009","DOC","STAT","Eficiência multiplicadora skills vs CLAUDE.md: 18×","HIGH","18","×","2026-04","skills-knowledge-base.json","Multiplicador eficiência skills"],
    ["E134","DOC-08","S009","DOC","STAT","Skills ativas máximas antes de invisibilidade: ≤15 (limite 16k chars)","HIGH","15","skills","2026-04","skills-knowledge-base.json","Limite prático skills simultâneas"],
    ["E135","DOC-08","S009","DOC","STAT","Instalações find-skills (Vercel): 418.600","HIGH","418600","instalações","2026-04","skills-knowledge-base.json – SkillsMP","Instalações #1 skill mais popular"],
    ["E136","DOC-08","S009","DOC","STAT","Stars GitHub obra/superpowers: ~137k","HIGH","137000","stars","2026-04","skills-knowledge-base.json","Stars repo obra/superpowers"],
    ["E137","DOC-08","S009","DOC","STAT","Stars GitHub ComposioHQ/awesome-claude-skills: ~41.3k","HIGH","41300","stars","2026-04","skills-knowledge-base.json","Stars ComposioHQ repo"],
    ["E138","DOC-08","S009","DOC","STAT","Stars GitHub garrytan/gstack: ~54.2k (lista) / ~20.1k","MED","54200","stars","2026-04","skills-knowledge-base.json","Stars garrytan/gstack (lista)"],
    ["E139","DOC-08","S009","DOC","STAT","Skills de Engenharia disponíveis (SkillsDir): 12.476","HIGH","12476","skills","2026-04","skills-knowledge-base.json – SkillsDir","Supply skills categoria Engineering"],
    ["E140","DOC-08","S009","DOC","STAT","Skills de Design disponíveis (SkillsDir): 5.488","HIGH","5488","skills","2026-04","skills-knowledge-base.json – SkillsDir","Supply skills categoria Design"],
    ["E141","DOC-08","S009","DOC","STAT","Skills Finanças disponíveis (SkillsDir): 491","HIGH","491","skills","2026-04","skills-knowledge-base.json – SkillsDir","Supply skills categoria Finance"],
    ["E142","DOC-08","S009","DOC","STAT","Skills Jurídico disponíveis (SkillsDir): 916","HIGH","916","skills","2026-04","skills-knowledge-base.json – SkillsDir","Supply skills categoria Legal"],
    ["E143","DOC-08","S009","DOC","STAT","Preço Cursor Pro: US$20/mês","HIGH","20","USD/mês","2026","skills-knowledge-base.json – cursor.com/pricing","Preço Cursor Pro"],
    ["E144","DOC-08","S009","DOC","STAT","Preço Cursor Ultra: US$200/mês","HIGH","200","USD/mês","2026","skills-knowledge-base.json – cursor.com/pricing","Preço Cursor Ultra"],
    ["E145","DOC-08","S009","DOC","STAT","Preço GitHub Copilot Pro+: US$39/mês","HIGH","39","USD/mês","2026","skills-knowledge-base.json – github.com/features/copilot","Preço GitHub Copilot Pro+"],
    ["E146","DOC-08","S009","DOC","STAT","Preço Windsurf Pro: US$15/mês (500 créditos)","HIGH","15","USD/mês","2026","skills-knowledge-base.json – windsurf.com","Preço Windsurf Pro"],
    ["E147","DOC-08","S009","DOC","STAT","Usuários Windsurf: 1M+","HIGH","1000000","usuários","2026","skills-knowledge-base.json","Usuários Windsurf"],
    ["E148","DOC-08","S009","DOC","STAT","Clientes Snowflake: 12.600+","HIGH","12600","clientes","2026","skills-knowledge-base.json","Clientes Snowflake"],
    ["E149","DOC-08","S009","DOC","STAT","Clientes HubSpot: 228k+","HIGH","228000","clientes","2026","skills-knowledge-base.json","Clientes HubSpot"],
    ["E150","DOC-08","S009","DOC","STAT","Preço Apollo MCP (planos pagos a partir de): US$49/mês","HIGH","49","USD/mês","2026","skills-knowledge-base.json – apollo.io","Preço mínimo Apollo pago"],
    ["E151","DOC-08","S009","DOC","STAT","Preço Vibe Skills Marketing Pack Standard: US$199 one-time","HIGH","199","USD","2026","skills-knowledge-base.json – thevibemarketer.com","Preço Vibe Skills Pack Standard"],
    ["E152","DOC-08","S009","DOC","STAT","Usuários Vibe Skills em 47 países: 2.600+","HIGH","2600","usuários","2026","skills-knowledge-base.json","Usuários Vibe Skills global"],
    ["E153","DOC-08","S009","DOC","STAT","Stars RefoundAI/lenny-skills: ~581","MED","581","stars","2026-04","skills-knowledge-base.json","Stars lenny-skills"],
    ["E154","DOC-08","S009","DOC","STAT","Stars alirezarezvani/claude-skills: ~10.2k; forks: 1.3k","HIGH","10200","stars","2026-04","skills-knowledge-base.json","Stars alirezarezvani repo"],
    ["E155","DOC-08","S009","DOC","STAT","alirezarezvani/claude-skills: 233 skills + 305 ferramentas em 9 domínios","HIGH","233","skills","2026-04","skills-knowledge-base.json","Skills alirezarezvani repo"],
    ["E156","DOC-08","S009","DOC","STAT","Preço Claude Managed Agents por hora de sessão: US$0,08","HIGH","0.08","USD/h","2026-04-08","skills-knowledge-base.json – platform.claude.com","Preço hora sessão Managed Agents"],
    ["E157","DOC-08","S009","DOC","STAT","Preço web search Managed Agents: US$10 por 1.000 buscas","HIGH","10","USD/1000 buscas","2026-04-08","skills-knowledge-base.json – platform.claude.com","Preço busca web Managed Agents"],
    ["E158","DOC-08","S009","DOC","STAT","Clientes ServiceNow usando Claude: 29.000 funcionários internos","HIGH","29000","funcionários","2026","skills-knowledge-base.json","Usuários Claude @ ServiceNow"],
    ["E159","DOC-08","S009","DOC","STAT","Workflows processados pela plataforma ServiceNow: 80 bilhões+/ano","HIGH","80000000000","workflows/ano","2026","skills-knowledge-base.json","Volume workflows ServiceNow"],
    ["E160","DOC-08","S009","DOC","STAT","Parceria Anthropic–Snowflake declarada em US$200M","HIGH","200000000","USD","2026","skills-knowledge-base.json","Valor parceria Anthropic-Snowflake"],
    ["E161","DOC-08","S009","DOC","STAT","Benchmark Valyu FreshQA: 79% vs Google 39%","HIGH","79","%","2026","skills-knowledge-base.json – Valyu","Acurácia Valyu FreshQA benchmark"],

    # ══ DOC-09: guest-insights.md ════════════════════════════════════════════
    ["E162","DOC-09","S010","DOC","STAT","Limiar de latência para autocomplete sem interrupção do flow: ~200ms","HIGH","200","ms","2025","Ryan J. Salva – GitHub Copilot; guest-insights.md","Latência ideal sugestão autocomplete"],
    ["E163","DOC-09","S010","DOC","STAT","Estimativa de melhoria de produtividade em tarefas de engenharia com IA: ≥50%","MED","50","%","2025","Logan Kilpatrick; guest-insights.md","Ganho de produtividade em engenharia com IA"],
    ["E164","DOC-09","S010","DOC","QUOTE","'The difference between people who use Claude Code very effectively... is are they asking for the ambitious change?'","MED","","","2025","Benjamin Mann; guest-insights.md","Citação sobre uso eficaz Claude Code"],
    ["E165","DOC-09","S010","DOC","STAT","Iterações máximas de auto-refinamento no live-prompt-pro-converter: 3×","HIGH","3","iterações","2026-04-23","source_of_True.txt – SKL-17","Máx. iterações auto-refinamento"],
]

EPIST_COLOR = {"STAT": STAT_FILL, "CITE_N": CITE_FILL, "QUOTE": QUOTE_FILL, "CLAIM": CLAIM_FILL, "WEB_SR": NORM_FILL}

for r_idx, row in enumerate(ROWS, start=2):
    fill = EPIST_COLOR.get(row[4], NORM_FILL)
    for c_idx, val in enumerate(row, start=1):
        cell = ws1.cell(row=r_idx, column=c_idx, value=val)
        cell.font = BODY_FONT
        cell.fill = fill
        cell.alignment = WRAP
    ws1.row_dimensions[r_idx].height = 28

# Autofilter
ws1.auto_filter.ref = f"A1:{get_column_letter(len(HEADERS))}{len(ROWS)+1}"

# ── SHEET 2: SOURCE_REGISTRY ─────────────────────────────────────────────────
ws2 = wb.create_sheet("SOURCE_REGISTRY")
S_HDRS = ["SRC_ID","FULL_SOURCE","TYPE","YEAR","URL_OR_PATH","NOTES"]
S_W    = [10,60,10,8,55,40]

for i, h in enumerate(S_HDRS, 1):
    c = ws2.cell(row=1, column=i, value=h)
    c.font = HDR_FONT; c.fill = HDR_FILL
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws2.column_dimensions[get_column_letter(i)].width = S_W[i-1]
ws2.row_dimensions[1].height = 22

SOURCES = [
    ["S001","SkillsIA — Skills de IA para Profissionais de Serviços (Business Document Corpus)","DOC","2026-04-13","DOC-01: SkillsIA-Corpus-Executivo.docx","Vision Framing, MRD, PR/FAQ, Business Case, PRD, ADRs, Roadmap, User Stories, Backlog"],
    ["S002","Bússola PME Light Strategy Corpus v1.0","DOC","2025-04","DOC-02: BUSSOLA_PME_Light_Corpus.docx","Vision Framing, MRD-lite, PRFAQ-lite, PRD-lite + BUSSOLA_PME__SKILL_ARCHITECTURE.md"],
    ["S003","Aurelio's OS Business Corpus (Ultralight)","DOC","2026-04-18","DOC-03: Aurelios_OS_Corpus_Executive.docx","6 canonical docs + BusinessDashCenter.xlsx + NORMALIZED_SPEC_Aurelio.md"],
    ["S004","Microsoft / Sebrae – Relatório IA para MPMEs 2024-2025","DOC","2024-2025","Referenciado em DOC-03 §A.1.2","77% MPMEs BR veem IA como aceleradora"],
    ["S005","COMBO TABULAR ARTIFACT — Sistema Bússola PME Strategic Corpus","DOC","2026-04-24","DOC-04: COMBO_TABULAR_ARTIFACT.md","EPO Mode C, RIDs 000–999, análise estratégica 150-day plan"],
    ["S006","Skill Portfolio README — 21 Skills Decomposto","DOC","2026-04-23","DOC-05: source_of_True.txt v1.0.0","RE + EX + PT + 5W2H para todas as 21 skills do portfólio"],
    ["S007","PLAN-MASTER-EXP-001 Sprint de Proposta Comercial com Claude — Corpus","DOC","2026-04-18","DOC-06: PLAN-MASTER-EXP-001_corpus.docx","9 documentos: Vision, MRD, PRFAQ, Business Case, BRD, PRD, ADRs, Roadmap, Backlog"],
    ["S008","Modelo EUA vs Brasil — Monetização de Skills Claude","DOC","2026","DOC-07: Modelo_usa_Br.docx","Análise comparativa de modelos de monetização EUA/BR"],
    ["S009","Skills Knowledge Base — MECE Structured Index v1.0","DOC","2026-04","DOC-08: skills-knowledge-base.json.md","50 skills (25 OS + 25 Premium), benchmarks, preços, ecosystem stats"],
    ["S010","Building with LLMs — All Guest Insights (60 guests, 110 mentions)","DOC","2025","DOC-09: guest-insights.md","Citações e insights de 60 convidados sobre LLMs em produção"],
    ["S011","SkillsBench arXiv 2026-03","URL","2026-03","https://arxiv.org (arXiv 2026-03)","Benchmark n=47.150 skills; impacto médio +16,2pp"],
    ["S012","Snyk ToxicSkills Report 2026-02","URL","2026-02","https://snyk.io (report 2026-02)","13,4% críticos; 36% prompt injection"],
    ["S013","IBGE — Trabalhadores Independentes 2022","URL","2022","https://ibge.gov.br","25,7M trabalhadores independentes"],
    ["S014","Sebrae — Micro e Pequenas Empresas 2024","URL","2024","https://sebrae.com.br","6,4M estabelecimentos MPE; 2,8M novos negócios 2024; 61% serviços"],
    ["S015","Gupy — Relatório Mercado de Trabalho IA 2024","URL","2024","https://gupy.io","Busca profissionais IA +306% em 2024"],
    ["S016","Governo Federal — Plano Brasileiro de IA","URL","2024","https://gov.br","R$ 23 bilhões investimentos IA até 2028"],
    ["S017","Alura / Central do Varejo 2025","URL","2025","https://alura.com.br","67% empresas BR declararam IA como prioridade 2025"],
    ["S018","IND — Immigratie- en Naturalisatiedienst (Países Baixos)","URL","2026","https://ind.nl","Limiar kennismigrant: €4.357/mês (≤30 anos)"],
]

for r_idx, row in enumerate(SOURCES, start=2):
    for c_idx, val in enumerate(row, start=1):
        cell = ws2.cell(row=r_idx, column=c_idx, value=val)
        cell.font = BODY_FONT
        cell.alignment = WRAP
        cell.fill = ALT_FILL if r_idx % 2 == 0 else NORM_FILL
    ws2.row_dimensions[r_idx].height = 32
ws2.auto_filter.ref = f"A1:{get_column_letter(len(S_HDRS))}{len(SOURCES)+1}"
ws2.freeze_panes = "A2"

# ── SHEET 3: EPISTEMIC_LEGEND ─────────────────────────────────────────────────
ws3 = wb.create_sheet("EPISTEMIC_LEGEND")

LEGEND = [
    ("FIELD","CODE","DEFINITION","USAGE RULE"),
    ("","","",""),
    ("EPIST","STAT","Statistical/numerical datum with explicit source","Number + unit + source required"),
    ("EPIST","CITE_N","Named citation: author, institution, year attributed","Must name originating entity"),
    ("EPIST","QUOTE","Verbatim text reproduced with full source traceability","Must be exact; source URL/path required"),
    ("EPIST","CLAIM","Sourced factual assertion (non-numeric)","Must have SRC_ID; no pure inference"),
    ("EPIST","WEB_SR","Web search snippet result","Mark source as URL; add DATE"),
    ("","","",""),
    ("CONF","HIGH","2+ independent sources confirm the datum","Cross-validated across docs or external refs"),
    ("CONF","MED","1 reliable/primary source","Single authoritative source"),
    ("CONF","LOW","1 unverified or projected source (e.g., HIPÓTESE)","Projections, estimates, unvalidated hypotheses"),
    ("CONF","NULL","Source completely unknown","Do not use; skip the datum instead"),
    ("","","",""),
    ("SRC_TY","DOC","Internal project document","Files listed in project context"),
    ("SRC_TY","URL","Public web URL","Must include full URL in SOURCE_REGISTRY"),
    ("SRC_TY","API","API response or programmatic data","Include endpoint and date"),
    ("SRC_TY","USR","Direct user-provided datum","Confirmed by user in conversation"),
    ("","","",""),
    ("SCOPE","✅ INCLUDE","Market data · numerical facts · named citations · direct quotes · structural facts","One atomic fact per row; skip if no SRC_ID"),
    ("SCOPE","❌ EXCLUDE","Narrative · synthesis · inference · opinion · datum without attribution","R2: no row without SRC_ID + SRC_TY + EPIST"),
    ("","","",""),
    ("EPIST COLOR","STAT","Light green background (E8F5E9)",""),
    ("EPIST COLOR","CITE_N","Light blue background (E3F2FD)",""),
    ("EPIST COLOR","QUOTE","Light amber background (FFF8E1)",""),
    ("EPIST COLOR","CLAIM","Light purple background (F3E5F5)",""),
    ("","","",""),
    ("VERSION","v1.0","Generated 2026-05-03 — CMD v3 Epistemic Data Extraction","Total rows: " + str(len(ROWS)) + " | Sources: " + str(len(SOURCES))),
]

L_W = [16,12,60,45]
L_HDRS = LEGEND[0]
for i, h in enumerate(L_HDRS, 1):
    c = ws3.cell(row=1, column=i, value=h)
    c.font = HDR_FONT; c.fill = HDR_FILL
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws3.column_dimensions[get_column_letter(i)].width = L_W[i-1]
ws3.row_dimensions[1].height = 22

for r_idx, row in enumerate(LEGEND[1:], start=2):
    is_section = row[0] != "" and row[1] == "" and row[2] == ""
    for c_idx, val in enumerate(row, start=1):
        cell = ws3.cell(row=r_idx, column=c_idx, value=val)
        if is_section:
            cell.font = Font(name="Arial", size=9, bold=True, color="1F3864")
            cell.fill = PatternFill("solid", start_color="D0E4FF")
        else:
            cell.font = BODY_FONT
            cell.fill = ALT_FILL if r_idx % 2 == 0 else NORM_FILL
        cell.alignment = WRAP
    ws3.row_dimensions[r_idx].height = 20

ws3.freeze_panes = "A2"

# ── Save ──────────────────────────────────────────────────────────────────────
OUT = "/mnt/user-data/outputs/epistemic_data_extraction.xlsx"
wb.save(OUT)
print(f"Saved → {OUT}")
print(f"EPISTEMIC_DATA rows: {len(ROWS)}")
print(f"SOURCE_REGISTRY entries: {len(SOURCES)}")
