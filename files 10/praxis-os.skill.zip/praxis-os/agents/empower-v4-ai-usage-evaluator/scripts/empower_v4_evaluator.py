#!/usr/bin/env python3
"""
Empower V4 — AI Usage Evaluator

Normalizes Claude/AI conversation exports, computes maturity scores,
detects risky prompt patterns, compares accounts, and generates
quality-lift reports when human labels are available.

Usage:
    python empower_v4_evaluator.py --input data.csv --mode full --output ./out
"""

import argparse
import hashlib
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

# Optional dependencies
try:
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend
    CHARTS_AVAILABLE = True
except ImportError:
    CHARTS_AVAILABLE = False
    print("Warning: matplotlib not available. Charts will not be generated.")


class EmpowerV4Evaluator:
    """Main evaluator for Empower V4 framework."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._default_config()
        self.mode = "canonical"
        self.df = None
        self.labels_df = None
        self.accounts = []
        self.results = {}
        
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration."""
        return {
            "maturity_weights": {
                "prompt_structure": 0.30,
                "context_richness": 0.25,
                "output_control": 0.20,
                "task_diversity": 0.10,
                "high_value_task_share": 0.10,
                "evidence_attachment": 0.05
            },
            "confidence_thresholds": {
                "very_low": 20,
                "low": 50,
                "medium": 100
            },
            "label_thresholds": {
                "exploratory": 20,
                "low": 50,
                "usable": 100
            },
            "task_categories": {
                "high_value": ["analysis", "research", "code", "writing", "strategy"],
                "medium_value": ["prompt_engineering", "planning"],
                "low_value": ["general", "chat", "other"]
            },
            "prompt_formats": ["short_direct", "standard", "structured", "long_context", "multi_instruct"],
            "context_levels": ["low", "medium", "high"]
        }
    
    def auto_detect_format(self, filepath: Path) -> str:
        """Auto-detect input format and select pipeline."""
        try:
            # Try reading as CSV first
            df = pd.read_csv(filepath, nrows=5)
            cols = set(df.columns.str.lower())
            
            # Check for canonical format
            required_canonical = {'interaction_id', 'user_prompt', 'assistant_response'}
            if required_canonical.issubset(cols):
                print(f"✓ Detected canonical format")
                return "canonical"
            
            # Check for raw Claude export indicators
            claude_indicators = {'content', 'role', 'model', 'created_at'}
            if any(ind in cols for ind in claude_indicators):
                print(f"⚠ Detected raw Claude export format")
                return "raw_claude"
            
            # Fallback to quick proxy
            print(f"⚠ Using quick_proxy mode (some columns missing)")
            return "quick_proxy"
            
        except Exception as e:
            print(f"Error detecting format: {e}")
            return "quick_proxy"
    
    def load_data(self, filepath: Path) -> pd.DataFrame:
        """Load and normalize input data."""
        print(f"\nLoading data from: {filepath}")
        
        # Auto-detect format
        self.mode = self.auto_detect_format(filepath)
        
        # Load based on extension
        if filepath.suffix == '.csv':
            df = pd.read_csv(filepath)
        elif filepath.suffix == '.jsonl':
            df = pd.read_json(filepath, lines=True)
        elif filepath.suffix == '.json':
            df = pd.read_json(filepath)
        else:
            raise ValueError(f"Unsupported file format: {filepath.suffix}")
        
        print(f"Loaded {len(df)} rows")
        
        # Normalize based on detected mode
        if self.mode == "canonical":
            df = self._normalize_canonical(df)
        elif self.mode == "raw_claude":
            df = self._normalize_raw_claude(df)
        else:
            df = self._normalize_quick_proxy(df)
        
        self.df = df
        self.accounts = sorted(df['account_id'].unique().tolist())
        print(f"Found {len(self.accounts)} account(s): {', '.join(self.accounts)}")
        
        return df
    
    def _normalize_canonical(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalize canonical format data."""
        # Ensure required columns exist
        required = ['interaction_id', 'user_prompt', 'assistant_response']
        missing = [col for col in required if col not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        
        # Ensure account_id exists
        if 'account_id' not in df.columns:
            df['account_id'] = self._infer_account_id(df)
        
        # Add missing optional columns with defaults
        if 'conversation_id' not in df.columns:
            df['conversation_id'] = df['interaction_id'].apply(lambda x: x.split('_')[0] if '_' in x else 'conv_unknown')
        
        if 'timestamp' not in df.columns:
            df['timestamp'] = datetime.now().isoformat()
        
        if 'turn_sequence' not in df.columns:
            df['turn_sequence'] = df.groupby('conversation_id').cumcount() + 1
        
        # Compute derived columns if missing
        if 'prompt_length' not in df.columns:
            df['prompt_length'] = df['user_prompt'].fillna('').str.len()
        
        if 'response_length' not in df.columns:
            df['response_length'] = df['assistant_response'].fillna('').str.len()
        
        if 'task_type' not in df.columns:
            df['task_type'] = df.apply(self._infer_task_type, axis=1)
        
        if 'prompt_format' not in df.columns:
            df['prompt_format'] = df.apply(self._infer_prompt_format, axis=1)
        
        if 'context_richness' not in df.columns:
            df['context_richness'] = df.apply(self._infer_context_richness, axis=1)
        
        # Compute expansion ratio
        df['expansion_ratio'] = df['response_length'] / (df['prompt_length'] + 1)
        
        return df
    
    def _normalize_raw_claude(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalize raw Claude export format."""
        print("⚠ Raw Claude export normalization not fully implemented yet.")
        print("⚠ Treating as quick_proxy mode.")
        return self._normalize_quick_proxy(df)
    
    def _normalize_quick_proxy(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalize incomplete data with proxy inference."""
        print("\n⚠ PROXY MODE ACTIVE")
        print("⚠ These are proxy metrics, not validated quality metrics.")
        
        # Try to find prompt/response columns with fuzzy matching
        prompt_col = None
        response_col = None
        
        for col in df.columns:
            col_lower = col.lower()
            if 'prompt' in col_lower or 'user' in col_lower or 'input' in col_lower:
                prompt_col = col
            if 'response' in col_lower or 'assistant' in col_lower or 'output' in col_lower:
                response_col = col
        
        if not prompt_col or not response_col:
            raise ValueError("Could not identify prompt and response columns. Please provide canonical format.")
        
        # Create canonical columns
        df_norm = df.copy()
        df_norm['user_prompt'] = df[prompt_col]
        df_norm['assistant_response'] = df[response_col]
        
        # Generate interaction IDs
        if 'interaction_id' not in df_norm.columns:
            df_norm['interaction_id'] = [f"int_{i:06d}" for i in range(len(df_norm))]
        
        # Infer account
        df_norm['account_id'] = self._infer_account_id(df_norm)
        
        # Add defaults
        df_norm['conversation_id'] = df_norm['interaction_id'].apply(lambda x: x.split('_')[0])
        df_norm['timestamp'] = datetime.now().isoformat()
        df_norm['turn_sequence'] = 1
        
        # Compute metrics
        df_norm['prompt_length'] = df_norm['user_prompt'].fillna('').str.len()
        df_norm['response_length'] = df_norm['assistant_response'].fillna('').str.len()
        df_norm['expansion_ratio'] = df_norm['response_length'] / (df_norm['prompt_length'] + 1)
        
        df_norm['task_type'] = df_norm.apply(self._infer_task_type, axis=1)
        df_norm['prompt_format'] = df_norm.apply(self._infer_prompt_format, axis=1)
        df_norm['context_richness'] = df_norm.apply(self._infer_context_richness, axis=1)
        
        return df_norm
    
    def _infer_account_id(self, df: pd.DataFrame) -> str:
        """Infer account ID from data or generate stable hash."""
        # Try to find account column
        for col in df.columns:
            if 'account' in col.lower():
                return df[col].iloc[0] if not df[col].isna().all() else self._generate_account_hash(df)
        
        # Generate stable hash
        return self._generate_account_hash(df)
    
    def _generate_account_hash(self, df: pd.DataFrame) -> str:
        """Generate stable 12-char hash for account ID."""
        # Use first few rows as fingerprint
        fingerprint = str(df.head(3).to_dict())
        hash_val = hashlib.md5(fingerprint.encode()).hexdigest()[:12]
        return f"acct_{hash_val}"
    
    def _infer_task_type(self, row: pd.Series) -> str:
        """Infer task type from prompt content."""
        prompt = str(row.get('user_prompt', '')).lower()
        
        # Keywords for different task types
        if any(kw in prompt for kw in ['analyze', 'analysis', 'evaluate', 'assess', 'compare']):
            return 'analysis'
        elif any(kw in prompt for kw in ['code', 'python', 'javascript', 'function', 'class', 'debug']):
            return 'code'
        elif any(kw in prompt for kw in ['research', 'find', 'search', 'investigate', 'study']):
            return 'research'
        elif any(kw in prompt for kw in ['write', 'draft', 'compose', 'create', 'blog', 'article']):
            return 'writing'
        elif any(kw in prompt for kw in ['prompt', 'improve', 'rewrite', 'optimize']):
            return 'prompt_engineering'
        elif any(kw in prompt for kw in ['strategy', 'plan', 'roadmap', 'framework']):
            return 'strategy'
        else:
            return 'general'
    
    def _infer_prompt_format(self, row: pd.Series) -> str:
        """Infer prompt format from structure."""
        prompt = str(row.get('user_prompt', ''))
        length = len(prompt)
        
        # Check for structured indicators
        structured_indicators = ['\n##', '\n#', '---', '```', 'CONTEXT:', 'TASK:', 'OUTPUT:']
        has_structure = any(ind in prompt for ind in structured_indicators)
        
        # Check for multi-step instructions
        has_steps = any(ind in prompt for ind in ['\n1.', '\n2.', '\n-', '\n*'])
        
        if length < 100:
            return 'short_direct'
        elif length < 300:
            return 'standard'
        elif has_structure or has_steps:
            if has_steps:
                return 'multi_instruct'
            else:
                return 'structured'
        elif length >= 500:
            return 'long_context'
        else:
            return 'standard'
    
    def _infer_context_richness(self, row: pd.Series) -> str:
        """Infer context richness from prompt content."""
        prompt = str(row.get('user_prompt', ''))
        
        # Context indicators
        context_markers = [
            'context:', 'background:', 'given', 'assuming', 'based on',
            'file:', 'data:', 'document:', 'previous', 'earlier'
        ]
        
        context_count = sum(1 for marker in context_markers if marker in prompt.lower())
        
        # Check for attachments/evidence
        has_evidence = '[' in prompt and ']' in prompt  # Links or references
        
        if context_count >= 3 or has_evidence:
            return 'high'
        elif context_count >= 1:
            return 'medium'
        else:
            return 'low'
    
    def load_quality_labels(self, filepath: Path) -> pd.DataFrame:
        """Load quality labels and join to interactions."""
        print(f"\nLoading quality labels from: {filepath}")
        
        labels_df = pd.read_csv(filepath)
        print(f"Loaded {len(labels_df)} labels")
        
        # Validate required columns
        required = ['interaction_id']
        missing = [col for col in required if col not in labels_df.columns]
        if missing:
            raise ValueError(f"Labels file missing required columns: {missing}")
        
        # Join to main dataframe
        if self.df is None:
            raise ValueError("Must load interaction data before labels")
        
        self.labels_df = labels_df
        
        # Merge
        df_merged = self.df.merge(labels_df, on='interaction_id', how='left')
        labeled_count = df_merged['usefulness_score'].notna().sum()
        
        print(f"Joined {labeled_count}/{len(self.df)} interactions with labels ({labeled_count/len(self.df)*100:.1f}% coverage)")
        
        if labeled_count < self.config['label_thresholds']['exploratory']:
            print(f"⚠ Warning: Only {labeled_count} labels (< {self.config['label_thresholds']['exploratory']}). Quality metrics are exploratory only.")
        
        self.df = df_merged
        return df_merged
    
    def compute_maturity_score(self, account_id: Optional[str] = None) -> Dict[str, float]:
        """Compute maturity score for account or overall."""
        df = self.df if account_id is None else self.df[self.df['account_id'] == account_id]
        
        if len(df) < self.config['confidence_thresholds']['very_low']:
            confidence = "very_low_confidence"
        elif len(df) < self.config['confidence_thresholds']['low']:
            confidence = "low_confidence"
        elif len(df) < self.config['confidence_thresholds']['medium']:
            confidence = "medium_confidence"
        else:
            confidence = "high_confidence"
        
        # Component scores
        prompt_structure = self._score_prompt_structure(df)
        context_richness = self._score_context_richness(df)
        output_control = self._score_output_control(df)
        task_diversity = self._score_task_diversity(df)
        high_value_share = self._score_high_value_share(df)
        evidence_attachment = self._score_evidence_attachment(df)
        
        # Weighted maturity score
        weights = self.config['maturity_weights']
        maturity = 1 + 4 * (
            weights['prompt_structure'] * prompt_structure +
            weights['context_richness'] * context_richness +
            weights['output_control'] * output_control +
            weights['task_diversity'] * task_diversity +
            weights['high_value_task_share'] * high_value_share +
            weights['evidence_attachment'] * evidence_attachment
        )
        
        # Determine level
        if maturity < 2.0:
            level = "L1 Ad-hoc"
        elif maturity < 3.0:
            level = "L2 Functional"
        elif maturity < 4.0:
            level = "L3 Structured"
        elif maturity < 4.6:
            level = "L4 Optimized"
        else:
            level = "L5 Systematic"
        
        return {
            'maturity_score': round(maturity, 2),
            'level': level,
            'confidence': confidence,
            'n_interactions': len(df),
            'components': {
                'prompt_structure': round(prompt_structure, 3),
                'context_richness': round(context_richness, 3),
                'output_control': round(output_control, 3),
                'task_diversity': round(task_diversity, 3),
                'high_value_task_share': round(high_value_share, 3),
                'evidence_attachment': round(evidence_attachment, 3)
            }
        }
    
    def _score_prompt_structure(self, df: pd.DataFrame) -> float:
        """Score prompt structure quality."""
        # Higher score for structured/multi_instruct formats
        format_scores = {
            'short_direct': 0.0,
            'standard': 0.3,
            'structured': 0.7,
            'long_context': 0.5,
            'multi_instruct': 1.0
        }
        
        dist = df['prompt_format'].value_counts(normalize=True)
        score = sum(dist.get(fmt, 0) * format_scores.get(fmt, 0) for fmt in format_scores)
        return score
    
    def _score_context_richness(self, df: pd.DataFrame) -> float:
        """Score context richness."""
        richness_scores = {'low': 0.0, 'medium': 0.5, 'high': 1.0}
        dist = df['context_richness'].value_counts(normalize=True)
        score = sum(dist.get(lvl, 0) * richness_scores[lvl] for lvl in richness_scores)
        return score
    
    def _score_output_control(self, df: pd.DataFrame) -> float:
        """Score output control (presence of format specifications)."""
        # Proxy: check for output-related keywords in prompts
        control_keywords = ['format:', 'output:', 'return:', 'structure:', 'json', 'csv', 'markdown']
        has_control = df['user_prompt'].fillna('').str.lower().apply(
            lambda x: any(kw in x for kw in control_keywords)
        )
        return has_control.mean()
    
    def _score_task_diversity(self, df: pd.DataFrame) -> float:
        """Score task diversity."""
        task_counts = df['task_type'].value_counts()
        diversity = len(task_counts) / 7  # Normalize by max possible types
        return min(diversity, 1.0)
    
    def _score_high_value_share(self, df: pd.DataFrame) -> float:
        """Score share of high-value tasks."""
        high_value = self.config['task_categories']['high_value']
        high_value_count = df['task_type'].isin(high_value).sum()
        return high_value_count / len(df) if len(df) > 0 else 0.0
    
    def _score_evidence_attachment(self, df: pd.DataFrame) -> float:
        """Score evidence/attachment usage."""
        # Proxy: check for file references, links, data mentions
        evidence_markers = ['file:', 'attached', 'document:', '[http', 'data:', 'csv', 'excel']
        has_evidence = df['user_prompt'].fillna('').str.lower().apply(
            lambda x: any(marker in x for marker in evidence_markers)
        )
        return has_evidence.mean()
    
    def detect_risk_clusters(self) -> pd.DataFrame:
        """Detect high-risk prompt patterns."""
        risks = []
        
        for idx, row in self.df.iterrows():
            risk_score = 0
            risk_reasons = []
            
            # Risk: short_direct + low_context
            if row['prompt_format'] == 'short_direct' and row['context_richness'] == 'low':
                risk_score += 2
                risk_reasons.append("short_direct+low_context")
            
            # Risk: high expansion ratio
            if row['expansion_ratio'] > 20:
                risk_score += 1
                risk_reasons.append(f"high_expansion({row['expansion_ratio']:.1f})")
            
            # Risk: very short prompt for high-value task
            high_value = self.config['task_categories']['high_value']
            if row['task_type'] in high_value and row['prompt_length'] < 50:
                risk_score += 1
                risk_reasons.append(f"short_prompt_for_{row['task_type']}")
            
            if risk_score > 0:
                risks.append({
                    'interaction_id': row['interaction_id'],
                    'account_id': row['account_id'],
                    'risk_score': risk_score,
                    'risk_reasons': ', '.join(risk_reasons),
                    'prompt_format': row['prompt_format'],
                    'context_richness': row['context_richness'],
                    'task_type': row['task_type'],
                    'prompt_length': row['prompt_length'],
                    'expansion_ratio': round(row['expansion_ratio'], 2)
                })
        
        return pd.DataFrame(risks).sort_values('risk_score', ascending=False) if risks else pd.DataFrame()
    
    def generate_upgrade_candidates(self, top_n: int = 10) -> pd.DataFrame:
        """Generate top N prompt upgrade candidates."""
        candidates = []
        
        high_value = self.config['task_categories']['high_value']
        
        for idx, row in self.df.iterrows():
            upgrade_score = 0
            reasons = []
            
            # Criteria for upgrade
            if row['prompt_format'] == 'short_direct':
                upgrade_score += 2
                reasons.append("short_direct_format")
            
            if row['context_richness'] == 'low':
                upgrade_score += 1
                reasons.append("low_context")
            
            if row['expansion_ratio'] > 15:
                upgrade_score += 1
                reasons.append(f"high_expansion({row['expansion_ratio']:.1f})")
            
            if row['task_type'] in high_value:
                upgrade_score += 2
                reasons.append(f"high_value_task({row['task_type']})")
            
            if upgrade_score >= 3:
                prompt_preview = row['user_prompt'][:100] + '...' if len(row['user_prompt']) > 100 else row['user_prompt']
                
                candidates.append({
                    'interaction_id': row['interaction_id'],
                    'account_id': row['account_id'],
                    'task_type': row['task_type'],
                    'upgrade_score': upgrade_score,
                    'prompt_preview': prompt_preview,
                    'prompt_length': row['prompt_length'],
                    'response_length': row['response_length'],
                    'expansion_ratio': round(row['expansion_ratio'], 2),
                    'risk_reason': ', '.join(reasons),
                    'suggested_upgrade': self._suggest_upgrade(row)
                })
        
        df_candidates = pd.DataFrame(candidates)
        if not df_candidates.empty:
            df_candidates = df_candidates.sort_values('upgrade_score', ascending=False).head(top_n)
        
        return df_candidates
    
    def _suggest_upgrade(self, row: pd.Series) -> str:
        """Suggest upgrade strategy for a prompt."""
        suggestions = []
        
        if row['prompt_format'] == 'short_direct':
            suggestions.append("Use structured format with CONTEXT/TASK/OUTPUT sections")
        
        if row['context_richness'] == 'low':
            suggestions.append("Add relevant context and constraints")
        
        if row['task_type'] in self.config['task_categories']['high_value']:
            suggestions.append("Break down into subtasks with clear success criteria")
        
        return '; '.join(suggestions) if suggestions else "Add more structure and context"
    
    def compare_accounts(self) -> pd.DataFrame:
        """Compare maturity scores across accounts."""
        if len(self.accounts) < 2:
            print("⚠ Only 1 account found. Skipping comparison.")
            return pd.DataFrame()
        
        comparison = []
        
        for account_id in self.accounts:
            metrics = self.compute_maturity_score(account_id)
            df_account = self.df[self.df['account_id'] == account_id]
            
            # Format distribution
            format_dist = df_account['prompt_format'].value_counts(normalize=True).to_dict()
            
            # Risk rate
            risks = self.detect_risk_clusters()
            risk_count = len(risks[risks['account_id'] == account_id]) if not risks.empty else 0
            risk_rate = risk_count / len(df_account) if len(df_account) > 0 else 0
            
            comparison.append({
                'account_id': account_id,
                'maturity_score': metrics['maturity_score'],
                'level': metrics['level'],
                'confidence': metrics['confidence'],
                'n_interactions': metrics['n_interactions'],
                'short_direct_rate': format_dist.get('short_direct', 0),
                'structured_rate': format_dist.get('structured', 0) + format_dist.get('multi_instruct', 0),
                'risk_rate': round(risk_rate, 3)
            })
        
        df_comparison = pd.DataFrame(comparison).sort_values('maturity_score', ascending=False)
        
        # Flag imbalance
        max_n = df_comparison['n_interactions'].max()
        min_n = df_comparison['n_interactions'].min()
        if max_n / min_n > 3:
            print(f"⚠ Account comparison is imbalanced ({min_n} vs {max_n} interactions). Interpret ratios cautiously.")
        
        return df_comparison
    
    def compute_quality_metrics(self) -> Optional[Dict[str, Any]]:
        """Compute quality metrics from human labels."""
        if self.labels_df is None or 'usefulness_score' not in self.df.columns:
            print("⚠ No quality labels available. Skipping quality metrics.")
            return None
        
        labeled = self.df[self.df['usefulness_score'].notna()]
        
        if len(labeled) == 0:
            print("⚠ No labeled interactions found.")
            return None
        
        metrics = {
            'n_labeled': len(labeled),
            'coverage': round(len(labeled) / len(self.df), 3),
            'usefulness_avg': round(labeled['usefulness_score'].mean(), 2),
            'precision_avg': round(labeled['precision_score'].mean(), 2) if 'precision_score' in labeled.columns else None,
            'clarity_avg': round(labeled['clarity_score'].mean(), 2) if 'clarity_score' in labeled.columns else None,
        }
        
        # Success/rework rates
        if 'success_1st_turn' in labeled.columns:
            metrics['success_1st_turn_rate'] = round(labeled['success_1st_turn'].mean(), 3)
        
        if 'rework_required' in labeled.columns:
            rework_major = (labeled['rework_required'] == 'major').mean()
            metrics['major_rework_rate'] = round(rework_major, 3)
        
        if 'hallucination_detected' in labeled.columns:
            metrics['hallucination_rate'] = round(labeled['hallucination_detected'].mean(), 3)
        
        return metrics
    
    def generate_report(self, output_dir: Path) -> Path:
        """Generate main Markdown report."""
        output_dir.mkdir(parents=True, exist_ok=True)
        report_path = output_dir / "empower_v4_report.md"
        
        # Overall maturity
        overall_maturity = self.compute_maturity_score()
        
        # Account comparison
        comparison = self.compare_accounts()
        
        # Risk clusters
        risks = self.detect_risk_clusters()
        
        # Upgrade candidates
        upgrades = self.generate_upgrade_candidates(top_n=10)
        
        # Quality metrics
        quality = self.compute_quality_metrics()
        
        # Generate report
        with open(report_path, 'w') as f:
            f.write("# Empower V4 — AI Usage Evaluation Report\n\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**Total interactions:** {len(self.df)}\n")
            f.write(f"**Accounts analyzed:** {len(self.accounts)}\n\n")
            
            if self.mode == "quick_proxy":
                f.write("⚠ **PROXY MODE ACTIVE** — These are structural metrics, not validated quality metrics.\n\n")
            
            f.write("---\n\n")
            f.write("## Overall Maturity\n\n")
            f.write(f"**Maturity Score:** {overall_maturity['maturity_score']} / 5.00\n\n")
            f.write(f"**Level:** {overall_maturity['level']}\n\n")
            f.write(f"**Confidence:** {overall_maturity['confidence']} ({overall_maturity['n_interactions']} interactions)\n\n")
            
            f.write("### Component Scores\n\n")
            for comp, score in overall_maturity['components'].items():
                f.write(f"- {comp}: {score}\n")
            f.write("\n")
            
            if not comparison.empty:
                f.write("---\n\n")
                f.write("## Account Comparison\n\n")
                f.write(comparison.to_markdown(index=False))
                f.write("\n\n")
                
                best = comparison.iloc[0]
                worst = comparison.iloc[-1]
                f.write(f"**Most mature account:** {best['account_id']} (score: {best['maturity_score']})\n\n")
                f.write(f"**Most risky account:** {worst['account_id']} (risk rate: {worst['risk_rate']:.1%})\n\n")
                f.write(f"**Biggest gap:** {best['maturity_score'] - worst['maturity_score']:.2f} points\n\n")
            
            if not risks.empty:
                f.write("---\n\n")
                f.write("## Top Risk Clusters\n\n")
                f.write(risks.head(10).to_markdown(index=False))
                f.write("\n\n")
            
            if not upgrades.empty:
                f.write("---\n\n")
                f.write("## Top 10 Prompt Upgrade Candidates\n\n")
                f.write(upgrades.to_markdown(index=False))
                f.write("\n\n")
            
            if quality:
                f.write("---\n\n")
                f.write("## Quality Metrics (from labels)\n\n")
                f.write(f"**Labeled interactions:** {quality['n_labeled']} / {len(self.df)} ({quality['coverage']:.1%} coverage)\n\n")
                f.write(f"**Average usefulness:** {quality['usefulness_avg']} / 5.0\n\n")
                if quality.get('precision_avg'):
                    f.write(f"**Average precision:** {quality['precision_avg']} / 5.0\n\n")
                if quality.get('success_1st_turn_rate') is not None:
                    f.write(f"**Success on first turn:** {quality['success_1st_turn_rate']:.1%}\n\n")
                if quality.get('major_rework_rate') is not None:
                    f.write(f"**Major rework required:** {quality['major_rework_rate']:.1%}\n\n")
                if quality.get('hallucination_rate') is not None:
                    f.write(f"**Hallucination detected:** {quality['hallucination_rate']:.1%}\n\n")
            
            f.write("---\n\n")
            f.write("## Recommended Next Actions\n\n")
            f.write("1. **Rewrite top upgrade candidates** using structured format (CONTEXT/TASK/OUTPUT)\n")
            f.write("2. **Address risk clusters** by adding context and breaking down complex tasks\n")
            if len(self.accounts) > 1:
                f.write(f"3. **Share best practices** from {comparison.iloc[0]['account_id']} with other accounts\n")
            f.write("4. **Label more interactions** to enable quality-lift analysis\n")
            f.write("5. **Monitor maturity over time** by running Empower V4 monthly\n\n")
        
        print(f"\n✓ Report generated: {report_path}")
        return report_path
    
    def export_csvs(self, output_dir: Path):
        """Export all CSV datasets."""
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Normalized interactions
        self.df.to_csv(output_dir / "normalized_interactions.csv", index=False)
        print(f"✓ Exported: normalized_interactions.csv")
        
        # Maturity scorecard
        scorecard = []
        for account_id in self.accounts:
            metrics = self.compute_maturity_score(account_id)
            scorecard.append({
                'account_id': account_id,
                **metrics['components'],
                'maturity_score': metrics['maturity_score'],
                'level': metrics['level']
            })
        pd.DataFrame(scorecard).to_csv(output_dir / "maturity_scorecard.csv", index=False)
        print(f"✓ Exported: maturity_scorecard.csv")
        
        # Account comparison
        comparison = self.compare_accounts()
        if not comparison.empty:
            comparison.to_csv(output_dir / "account_comparison.csv", index=False)
            print(f"✓ Exported: account_comparison.csv")
        
        # Risk clusters
        risks = self.detect_risk_clusters()
        if not risks.empty:
            risks.to_csv(output_dir / "risk_clusters.csv", index=False)
            print(f"✓ Exported: risk_clusters.csv")
        
        # Upgrade candidates
        upgrades = self.generate_upgrade_candidates(top_n=20)
        if not upgrades.empty:
            upgrades.to_csv(output_dir / "prompt_upgrade_candidates.csv", index=False)
            print(f"✓ Exported: prompt_upgrade_candidates.csv")
    
    def export_manifest(self, output_dir: Path, mode: str):
        """Export run manifest with metadata."""
        manifest = {
            'run_timestamp': datetime.now().isoformat(),
            'empower_version': 'v4.0.0',
            'mode': mode,
            'input_mode': self.mode,
            'n_interactions': len(self.df),
            'n_accounts': len(self.accounts),
            'accounts': self.accounts,
            'has_quality_labels': self.labels_df is not None,
            'maturity_score': self.compute_maturity_score()['maturity_score']
        }
        
        manifest_path = output_dir / "run_manifest.json"
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        print(f"✓ Exported: run_manifest.json")
    
    def generate_charts(self, output_dir: Path):
        """Generate visualization charts."""
        if not CHARTS_AVAILABLE:
            print("⚠ Matplotlib not available. Skipping charts.")
            return
        
        charts_dir = output_dir / "charts"
        charts_dir.mkdir(parents=True, exist_ok=True)
        
        # Maturity by account
        if len(self.accounts) > 1:
            comparison = self.compare_accounts()
            plt.figure(figsize=(10, 6))
            plt.barh(comparison['account_id'], comparison['maturity_score'])
            plt.xlabel('Maturity Score')
            plt.title('Maturity Score by Account')
            plt.xlim(0, 5)
            plt.tight_layout()
            plt.savefig(charts_dir / "maturity_by_account.png", dpi=150)
            plt.close()
            print(f"✓ Generated: maturity_by_account.png")
        
        # Prompt format distribution
        format_counts = self.df['prompt_format'].value_counts()
        plt.figure(figsize=(10, 6))
        plt.bar(format_counts.index, format_counts.values)
        plt.xlabel('Prompt Format')
        plt.ylabel('Count')
        plt.title('Prompt Format Distribution')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(charts_dir / "prompt_format_distribution.png", dpi=150)
        plt.close()
        print(f"✓ Generated: prompt_format_distribution.png")
        
        # Context richness distribution
        context_counts = self.df['context_richness'].value_counts()
        plt.figure(figsize=(8, 6))
        plt.pie(context_counts.values, labels=context_counts.index, autopct='%1.1f%%')
        plt.title('Context Richness Distribution')
        plt.tight_layout()
        plt.savefig(charts_dir / "context_richness_distribution.png", dpi=150)
        plt.close()
        print(f"✓ Generated: context_richness_distribution.png")


def main():
    parser = argparse.ArgumentParser(description='Empower V4 — AI Usage Evaluator')
    parser.add_argument('--input', required=True, type=Path, help='Input CSV/JSONL file')
    parser.add_argument('--labels', type=Path, help='Quality labels CSV (optional)')
    parser.add_argument('--mode', default='full', 
                       choices=['quick', 'compare', 'full', 'labels', 'upgrade', 'all'],
                       help='Execution mode')
    parser.add_argument('--output', type=Path, default=Path('./empower_v4_package'),
                       help='Output directory')
    parser.add_argument('--charts', action='store_true', help='Generate charts')
    parser.add_argument('--config', type=Path, help='Custom config JSON')
    
    args = parser.parse_args()
    
    # Load config
    config = None
    if args.config:
        with open(args.config) as f:
            config = json.load(f)
    
    # Initialize evaluator
    evaluator = EmpowerV4Evaluator(config)
    
    # Load data
    evaluator.load_data(args.input)
    
    # Load labels if provided
    if args.labels:
        evaluator.load_quality_labels(args.labels)
    
    # Execute based on mode
    print(f"\n{'='*60}")
    print(f"Running Empower V4 in '{args.mode}' mode")
    print(f"{'='*60}\n")
    
    if args.mode in ['quick', 'full', 'all']:
        report_path = evaluator.generate_report(args.output)
    
    if args.mode in ['full', 'all']:
        evaluator.export_csvs(args.output)
        evaluator.export_manifest(args.output, args.mode)
    
    if args.mode in ['compare', 'all']:
        comparison = evaluator.compare_accounts()
        if not comparison.empty:
            print("\nAccount Comparison:")
            print(comparison.to_string(index=False))
    
    if args.mode in ['upgrade', 'all']:
        upgrades = evaluator.generate_upgrade_candidates(top_n=10)
        if not upgrades.empty:
            print("\nTop Upgrade Candidates:")
            print(upgrades[['interaction_id', 'task_type', 'upgrade_score', 'risk_reason']].to_string(index=False))
    
    if (args.charts or args.mode == 'all') and CHARTS_AVAILABLE:
        evaluator.generate_charts(args.output)
    
    print(f"\n{'='*60}")
    print(f"✓ Empower V4 evaluation complete!")
    print(f"✓ Results saved to: {args.output}")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()