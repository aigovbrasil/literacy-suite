"""
NARRATIVE DISCOVERY EXTRACTION — X-RAY BUSINESS
Extracts ALL content relevant to Discovery & Research business phases
from project files: readme, brifing_, tags
"""

import re
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

# ─────────────────────────────────────────────────────────
# 1. READ SOURCE FILES
# ─────────────────────────────────────────────────────────
SOURCES = {
    "README": "/mnt/project/readme",
    "BRIFING": "/mnt/project/brifing_",
    "TAGS": "/mnt/project/tags",
}

texts = {}
for key, path in SOURCES.items():
    try:
        with open(path, "r", encoding="utf-8") as f:
            texts[key] = f.read()
    except Exception as e:
        texts[key] = ""
        print(f"WARN: could not read {path}: {e}")

# ─────────────────────────────────────────────────────────
# 2. TAXONOMY FOR DISCOVERY / RESEARCH PHASES
# ─────────────────────────────────────────────────────────
# Each entry: (CATEGORY, SUBCATEGORY, PHASE, CONTENT, SOURCE, STATUS, PRIORITY)

ROWS = []

def add(cat, subcat, phase, content, src, status="ATIVO", priority="MÉDIA"):
    ROWS.append({
        "CATEGORY": cat,
        "SUBCATEGORY": subcat,
        "PHASE": phase,
        "CONTENT": content.strip(),
        "SOURCE": src,
        "STATUS": status,
        "PRIORITY": priority,
    })

# ─────────────────────────────────────────────────────────
# 3. EXTRACT — PROBLEMS & PAINS
# ─────────────────────────────────────────────────────────
problems = [
    ("Conversas estratégicas, áudios, pesquisas e decisões ficam dispersos em chats, documentos e anotações, dificultando continuidade e execução.", "BRIFING+TAGS"),
    ("Projetos avançam sem seguir fases claras, gerando confusão entre scope, discovery, diagnosis, strategy, design, validation, build, launch, measure e iterate.", "TAGS"),
    ("Agentes de IA podem perder contexto, gerar respostas desalinhadas ou alucinar quando não possuem uma fonte única de verdade atualizada.", "TAGS"),
    ("Consultores precisam transformar informação bruta em entregáveis claros, mas esse processo exige organização, síntese, estrutura e memória acumulada.", "TAGS"),
    ("Sem mecanismos explícitos de captura, decisões importantes tomadas durante conversas podem não ser registradas.", "TAGS"),
    ("Consultores podem querer produtividade com IA, mas ter medo de alucinação, baixa confiabilidade ou perda de controle sobre o entregável.", "TAGS"),
    ("A adoção de skills pode ser travada por fricção técnica, falta de clareza sobre instalação, ausência de onboarding e dificuldade de personalização.", "TAGS"),
    ("O público pode não entender imediatamente o problema ou o valor da solução, exigindo educação de mercado e demonstrações concretas.", "TAGS"),
    ("Construir plataforma, curso ou SaaS antes da validação pode gerar desperdício de esforço se oferta, público e canal ainda não estiverem comprovados.", "TAGS"),
]
for p, src in problems:
    add("PROBLEMA/DOR", "Dor identificada", "DISCOVERY", p, src, "IDENTIFICADO", "ALTA")

# ─────────────────────────────────────────────────────────
# 4. EXTRACT — HYPOTHESES
# ─────────────────────────────────────────────────────────
hypotheses = [
    ("H01", "O X-Ray Business pode gerar valor funcionando como co-pilot para consultores, apoiando diagnóstico, análise, estruturação de entregáveis e tomada de decisão.", "MED", "ALTA"),
    ("H02", "O produto deve ser posicionado como apoio metodológico e analítico, não como ferramenta que substitui o julgamento humano.", "MED", "ALTA"),
    ("H03", "A criação de uma skill em Markdown com conhecimento persistente pode resolver o problema de perda de contexto ao longo do ciclo de desenvolvimento.", "MED", "ALTA"),
    ("H04", "Uma estrutura inspirada em product self-knowledge, internal knowledge e brand guidelines permite que o agente opere com consistência.", "LOW", "MÉDIA"),
    ("H05", "Triggers explícitos como o comando 'captura' podem funcionar como mecanismo de entrada para salvar decisões, insights e atualizações.", "LOW", "ALTA"),
    ("H06", "Consultores pagariam por uma SaaS Web de skills se a solução reduzir fricção técnica e aumentar produtividade.", "LOW", "ALTA"),
    ("H07", "O primeiro MVP pode não ser necessariamente uma plataforma SaaS; pode ser curso, consultoria, portfólio demonstrativo, biblioteca de skills ou Project to Linear.", "LOW", "ALTA"),
    ("H08", "Consultores solo e pequenas boutiques de consultoria têm dores, maturidade técnica, orçamento e velocidade de adoção diferentes; o público inicial precisa ser validado.", "LOW", "ALTA"),
    ("H09", "Existe interesse em IA entre consultores, mas baixa clareza sobre instalação, uso e adaptação de skills pode travar adoção.", "LOW", "ALTA"),
    ("H10", "A plataforma pode ser desejável no longo prazo, mas uma oferta educacional ou consultiva pode ser mais adequada como MVP inicial.", "LOW", "ALTA"),
]
for hid, content, conf, pri in hypotheses:
    add("HIPÓTESE", hid, "SCOPE → DISCOVERY", content, "TAGS+BRIFING", f"NÃO VALIDADA | CONF:{conf}", pri)

# ─────────────────────────────────────────────────────────
# 5. EXTRACT — TARGET AUDIENCE / PERSONAS
# ─────────────────────────────────────────────────────────
personas = [
    ("Usuário Primário", "Consultor, estrategista, founder, operador de negócio ou profissional responsável por diagnosticar, estruturar e acompanhar projetos empresariais.", "ALTA"),
    ("Cliente Final", "Empresas, negócios, founders, times internos ou clientes de consultoria que precisam de diagnóstico, clareza estratégica e estruturação operacional.", "ALTA"),
    ("Decisor", "Dono do negócio, sócio, diretor, gestor de área, head de estratégia, head de produto, head de marketing ou líder de consultoria.", "ALTA"),
    ("Influenciador", "Analistas, consultores, operadores internos, especialistas de IA, times de produto, marketing, dados ou operações.", "MÉDIA"),
    ("Segmento A validar — Consultor Solo", "Consultores independentes. Possível público inicial. Validar: dor, maturidade técnica, orçamento e velocidade de adoção.", "ALTA"),
    ("Segmento A validar — Boutique de Consultoria", "Pequenas consultorias. Possível público inicial alternativo. Validar: processo decisório, volume de projetos, willingness to pay.", "ALTA"),
    ("Segmentos amplos", "PMEs, startups, negócios em reposicionamento, empresas em crescimento, times internos que precisam organizar conhecimento e projetos estratégicos.", "MÉDIA"),
]
for ptype, desc, pri in personas:
    add("PÚBLICO / PERSONA", ptype, "DISCOVERY", desc, "TAGS", "A VALIDAR", pri)

# ─────────────────────────────────────────────────────────
# 6. EXTRACT — BUSINESS MODEL OPTIONS
# ─────────────────────────────────────────────────────────
biz_models = [
    ("SaaS Web de skills para consultores", "Modelo recorrente. Alta escalabilidade. Requer validação de willingness to pay e redução de fricção técnica.", "H06", "A VALIDAR"),
    ("Curso para ensinar consultores a usar IA e skills", "Modelo de receita única ou assinatura. Menor fricção de entrada. Pode ser MVP educacional.", "H07", "A VALIDAR"),
    ("Plataforma com biblioteca inicial de skills", "Combinação de produto + conteúdo. Requer curadoria. Pode ser visão de longo prazo.", "H07", "A VALIDAR"),
    ("Consultoria ou serviço guiado de implementação", "Menor escala, maior margem. Validação direta de mercado. Possível MVP consultivo.", "H07", "A VALIDAR"),
    ("Project to Linear como case demonstrável ou produto", "Workflow específico. Alto valor demonstrativo. Pode ser componente de MVP ou ativo de vendas.", "H07", "A VALIDAR"),
    ("Portfólio demonstrativo com arquitetura e demos", "Ativo de marketing e prova de conceito. Pode gerar leads e validar proposta antes de build.", "H07", "PRIORIDADE"),
    ("Framework X-Ray Business aplicado a empresas/projetos", "Metodologia própria licenciável. Diferenciação por processo. Requer validação de posicionamento.", "H01", "A VALIDAR"),
    ("Skill/agente configurável com conhecimento persistente", "Produto técnico. Alta diferenciação. Requer público com maturidade para adotar.", "H03", "A VALIDAR"),
]
for name, desc, hyp, status in biz_models:
    add("MODELO DE NEGÓCIO", name, "STRATEGY", f"{desc} | Hipótese relacionada: {hyp}", "TAGS+BRIFING", status, "ALTA")

# ─────────────────────────────────────────────────────────
# 7. EXTRACT — VALUE PROPOSITION
# ─────────────────────────────────────────────────────────
add("PROPOSTA DE VALOR", "Declaração atual", "STRATEGY",
    "O X-Ray Business oferece uma camada de inteligência estruturada para transformar conversas, descobertas, decisões, pesquisas e materiais dispersos em conhecimento operacional consolidado.",
    "TAGS", "PROVISÓRIA — NÃO VALIDADA", "ALTA")

add("PROPOSTA DE VALOR", "Posicionamento central", "STRATEGY",
    "Co-pilot para consultores ou operadores de negócio capaz de acompanhar o ciclo completo de um projeto, mantendo contexto persistente, fontes únicas de verdade, hipóteses rastreáveis, diagnósticos baseados em dados e entregáveis consistentes.",
    "TAGS", "PROVISÓRIA — NÃO VALIDADA", "ALTA")

add("PROPOSTA DE VALOR", "O que NÃO é", "STRATEGY",
    "A solução não promete eliminar o trabalho humano nem gerar tudo automaticamente. Não é automação total. Não substitui o consultor. Não é ferramenta infalível. Não gera entregáveis sem validação humana.",
    "README+TAGS", "DECISÃO TOMADA", "ALTA")

value_mechanisms = [
    "Captura estruturada de contexto",
    "Normalização de narrativa",
    "Organização de hipóteses",
    "Diagnóstico a partir de dados",
    "Consolidação de decisões",
    "Análise de riscos",
    "Criação de matriz de validação",
    "Construção de entregáveis",
    "Preservação de memória do projeto",
    "Redução de retrabalho",
    "Aumento de consistência entre fases do projeto",
    "Redução da fricção técnica para consultores",
    "Apoio à transformação de IA em produto, serviço ou rotina operacional",
]
for vm in value_mechanisms:
    add("PROPOSTA DE VALOR", "Mecanismo de valor", "DISCOVERY → STRATEGY", vm, "TAGS", "LEVANTADO", "MÉDIA")

# ─────────────────────────────────────────────────────────
# 8. EXTRACT — STRATEGIC INSIGHTS
# ─────────────────────────────────────────────────────────
insights = [
    ("I01", "A persistência do conhecimento é central. O valor do sistema não está apenas em responder bem, mas em manter o contexto vivo e atualizado ao longo do projeto.", "ALTA"),
    ("I02", "O ciclo data-driven ajuda a impedir que o projeto pule diretamente para construção de plataforma, curso ou SaaS sem validação suficiente.", "ALTA"),
    ("I03", "A fase mais importante agora não é Build, mas Scope → Discovery → Diagnosis → Strategy.", "ALTA"),
    ("I04", "O próximo movimento estratégico deve ser transformar hipóteses em matriz de validação para decidir, com evidências, qual frente deve virar MVP inicial.", "ALTA"),
    ("I05", "A plataforma pode ser uma visão de longo prazo, mas não precisa ser assumida como MVP inicial antes de validação.", "ALTA"),
    ("I06", "A adoção por consultores depende tanto da proposta de valor quanto da redução de fricção técnica e da clareza sobre o papel da IA.", "ALTA"),
    ("I07", "A solução precisa avaliar não apenas demanda, mas também entendimento do problema pelo público. Se o público não reconhece a dor, pode ser necessário educar antes de vender.", "ALTA"),
    ("I08", "A lógica de product self-knowledge e internal knowledge pode ser aplicada ao próprio desenvolvimento do X-Ray Business, antes de ser oferecida como solução para terceiros.", "MÉDIA"),
    ("I09", "O portfólio pode funcionar como demonstrativo da arquitetura da solução, não apenas como material visual ou comercial.", "MÉDIA"),
    ("I10", "As fases de medição e iteração devem estar previstas desde o início para evitar decisões baseadas apenas em percepção ou intuição.", "MÉDIA"),
    ("I11", "O produto deve deixar claro que é um co-pilot, não um gerador autônomo infalível. Essa distinção é importante para mitigar risco de alucinação e preservar confiança.", "ALTA"),
    ("I12", "O comando 'captura' pode se tornar um mecanismo operacional simples e poderoso para transformar conversas em documentação estruturada.", "MÉDIA"),
    ("I13", "Muitos projetos com IA sofrem com perda de contexto e baixa governança — isso representa oportunidade de diferenciação metodológica.", "ALTA"),
    ("I14", "Casos concretos facilitam entendimento e reduzem abstração da proposta. O Project to Linear pode ser um case demonstrável valioso.", "MÉDIA"),
]
for iid, content, pri in insights:
    add("INSIGHT ESTRATÉGICO", iid, "DIAGNOSIS", content, "TAGS", "REGISTRADO", pri)

# ─────────────────────────────────────────────────────────
# 9. EXTRACT — RISKS
# ─────────────────────────────────────────────────────────
risks = [
    ("R01", "A solução parecer autônoma demais", "Usuários podem interpretar que o sistema gera tudo sozinho.", "Deixar explícito na proposta de valor que o agente apoia e exige validação humana."),
    ("R02", "Alucinações de IA comprometerem entregáveis", "Agentes podem produzir inferências incorretas se não ancorados em fontes claras.", "Usar fontes únicas de verdade, separar fatos de hipóteses e exigir validação."),
    ("R03", "Perda de contexto entre conversas", "Sem persistência documental, insights ficam presos em chats isolados.", "Implementar skill MD com arquivos internos atualizáveis e triggers de captura."),
    ("R04", "Acúmulo desorganizado de informações", "Capturar tudo sem taxonomia gera excesso de conteúdo e baixa usabilidade.", "Estruturar categorias claras: decisão, hipótese, dúvida, risco, oportunidade, guideline, backlog."),
    ("R05", "Confusão entre fases do ciclo", "Sem fases explícitas, o projeto pode misturar exploração com execução.", "Usar o ciclo data-driven como estrutura principal com critérios de entrada e saída."),
    ("R06", "Construir plataforma antes de validar demanda", "Desperdício de esforço se público, oferta, canal e proposta de valor não estiverem comprovados.", "Criar matriz de validação, landing page, entrevistas, lista de espera e testes antes de build."),
    ("R07", "Curva de aprendizado travar adoção", "Consultores podem se interessar por IA, mas desistir se instalação e uso forem difíceis.", "Desenhar onboarding simples, fluxo de instalação guiada, templates e demonstrações claras."),
    ("R08", "Público não entender o problema", "Se consultores não reconhecerem a dor, conversão pode ser baixa.", "Testar mensagens educacionais, demonstrações e exemplos concretos de ganho."),
    ("R09", "Skill depender de capacidades técnicas não disponíveis", "Nem todo ambiente permite atualização automática real de arquivos persistentes.", "Definir arquitetura técnica antes de depender operacionalmente do mecanismo de salvamento."),
]
for rid, title, desc, mitigation in risks:
    add("RISCO", rid, "DIAGNOSIS", f"{title} | Descrição: {desc} | Mitigação: {mitigation}", "TAGS", "MAPEADO", "ALTA")

# ─────────────────────────────────────────────────────────
# 10. EXTRACT — OPPORTUNITIES
# ─────────────────────────────────────────────────────────
opportunities = [
    ("O01", "Criar uma metodologia própria de gestão de conhecimento para projetos com IA", "Muitos projetos com IA sofrem com perda de contexto e baixa governança. Transformar a skill MD em parte central da oferta.", "ALTA"),
    ("O02", "Usar o próprio X-Ray Business como caso demonstrativo", "O desenvolvimento do projeto pode servir como prova de conceito. Documentar o ciclo completo como portfólio vivo.", "ALTA"),
    ("O03", "Criar um sistema de captura inline para consultores", "Consultores tomam decisões durante conversas e reuniões. Oferecer comandos como 'captura', 'decisão', 'risco', 'pendência'.", "ALTA"),
    ("O04", "Construir fontes únicas de verdade para negócios em desenvolvimento", "Empresas frequentemente operam com conhecimento fragmentado. Vender como diagnóstico ou camada de governança de IA.", "MÉDIA"),
    ("O05", "Validar o mercado com baixo custo antes de construir produto pesado", "Landing page, entrevistas, formulários e lista de espera podem gerar evidência antes de build.", "ALTA"),
    ("O06", "Transformar Project to Linear em case demonstrável", "Casos concretos facilitam entendimento. Usar como demo navegável ou exemplo de aplicação da metodologia.", "MÉDIA"),
    ("O07", "Criar uma biblioteca inicial de skills para consultores", "Templates reduzem fricção e aceleram percepção de valor. Skills para diagnóstico, proposta comercial, plano de ação.", "MÉDIA"),
    ("O08", "Educar consultores sobre uso prático de IA", "Se adoção for travada por baixa clareza técnica, educação pode ser parte da oferta. Curso mínimo, e-book, workshops.", "MÉDIA"),
    ("O09", "Combinar brand guidelines, conhecimento interno e product self-knowledge como módulos reutilizáveis", "Agentes ficam mais consistentes com regras, contexto e limites claros.", "MÉDIA"),
]
for oid, title, desc, pri in opportunities:
    add("OPORTUNIDADE", oid, "DISCOVERY → STRATEGY", f"{title} | {desc}", "TAGS", "MAPEADA", pri)

# ─────────────────────────────────────────────────────────
# 11. EXTRACT — OPEN QUESTIONS (critical for discovery)
# ─────────────────────────────────────────────────────────
questions = [
    ("Q01", "Qual hipótese deve ser validada primeiro?", "Há hipóteses sobre SaaS Web, curso, plataforma, consultoria, Project to Linear e biblioteca de skills.", "Define a primeira matriz de validação e o foco da próxima rodada de discovery.", "ALTA"),
    ("Q02", "Qual público inicial deve ser priorizado?", "Consultor solo vs. pequena boutique de consultoria.", "Afeta proposta de valor, preço, canal, linguagem, onboarding e formato de MVP.", "ALTA"),
    ("Q03", "Qual deve ser o MVP inicial?", "Curso, plataforma, consultoria, Project to Linear, portfólio demonstrativo ou SaaS Web.", "Define esforço de build, estratégia de validação e canal de lançamento.", "ALTA"),
    ("Q04", "O público entende a dor ou precisa ser educado?", "Pode haver interesse em IA, mas baixa clareza sobre skills, instalação e aplicações práticas.", "Influencia se a primeira oferta deve ser educacional, consultiva ou de produto.", "ALTA"),
    ("Q05", "Qual canal deve ser testado primeiro?", "LinkedIn, Instagram, YouTube, blogs, landing page, formulário, entrevistas, comunidades.", "Define coleta de dados, aquisição de leads e validação de mensagem.", "ALTA"),
    ("Q06", "Como diferenciar informação bruta, hipótese, decisão e fonte única de verdade?", "O projeto precisa evitar misturar ideias exploratórias com decisões consolidadas.", "Afeta confiabilidade do sistema e qualidade das análises futuras.", "ALTA"),
    ("Q07", "Qual deve ser a estrutura exata do diretório da skill MD?", "A intenção é espelhar product self-knowledge e knowledge base.", "Afeta manutenção, versionamento e facilidade de uso por agentes.", "MÉDIA"),
    ("Q08", "Onde a persistência será implementada?", "Claude Project, Markdown local, Drive, Git, Notion, Obsidian ou outro.", "Define arquitetura técnica da solução de memória operacional.", "ALTA"),
    ("Q09", "O trigger 'captura' deve salvar qualquer informação ou apenas decisões formalizadas?", "Durante conversas inline surgem insights, dúvidas, hipóteses e decisões.", "Define regras de governança e evita poluição da fonte única de verdade.", "ALTA"),
    ("Q10", "Como o agente deve lidar com contradições entre versões anteriores e novas decisões?", "O projeto está em formação e ideias podem mudar.", "Exige regras de versionamento, substituição ou marcação de tensão estratégica.", "MÉDIA"),
]
for qid, q, ctx, impact, pri in questions:
    add("DÚVIDA EM ABERTO", qid, "DISCOVERY", f"{q} | Contexto: {ctx} | Impacto: {impact}", "TAGS", "NÃO RESOLVIDA", pri)

# ─────────────────────────────────────────────────────────
# 12. EXTRACT — DECISIONS ALREADY TAKEN
# ─────────────────────────────────────────────────────────
decisions = [
    ("D01", "Posicionar a solução como co-pilot para consultores", "Reduzir risco de expectativa excessiva sobre automação e deixar claro que o sistema apoia, mas não substitui, julgamento humano.", "Influencia comunicação, produto, entregáveis e limites de uso."),
    ("D02", "Criar portfólio demonstrativo da arquitetura do X-Ray Business", "Mostrar o funcionamento da solução e permitir demonstração prática.", "Pode servir como material comercial, técnico e operacional."),
    ("D03", "Estruturar uma skill em Markdown para o projeto", "Criar um formato persistente, editável e reutilizável de conhecimento.", "Transforma a operação do projeto em um sistema documentado."),
    ("D04", "Usar triggers explícitos como 'captura' para registrar informações", "Permitir que decisões e insights sejam salvos no momento em que surgem.", "Melhora a governança do conhecimento e reduz perda de informação."),
    ("D05", "Tratar o momento atual como fase Discovery com reforço de Scope", "Leonardo está colhendo informações antes de avançar para construção.", "Evita execução prematura."),
    ("D06", "Adotar o ciclo data-driven como estrutura principal do projeto", "Organizar o desenvolvimento em fases claras com perguntas, métodos, tags e critérios.", "Cria espinha dorsal para a skill e para o projeto Claude."),
    ("D07", "Priorizar operacionalmente Scope → Discovery → Diagnosis → Strategy", "Ainda há dúvidas sobre público, oferta, canal, modelo de negócio e MVP inicial.", "Posterga construção pesada até hipóteses organizadas e validadas."),
]
for did, title, justif, impact in decisions:
    add("DECISÃO TOMADA", did, "SCOPE → STRATEGY", f"{title} | Justificativa: {justif} | Impacto: {impact}", "TAGS", "CONFIRMADA", "ALTA")

# ─────────────────────────────────────────────────────────
# 13. EXTRACT — ANALYSIS BACKLOG
# ─────────────────────────────────────────────────────────
backlog = [
    ("B01", "Criar matriz de validação das hipóteses atuais", "Necessário para decidir com dados qual frente deve virar MVP inicial.", "ALTA"),
    ("B02", "Preencher a fase Scope", "É necessário definir problema, hipótese, público, decisão a desbloquear e fora de escopo.", "ALTA"),
    ("B03", "Definir público prioritário para discovery", "Consultor solo e boutique podem exigir ofertas, preços e canais diferentes.", "ALTA"),
    ("B04", "Definir quais hipóteses serão testadas primeiro", "Há múltiplas possibilidades de MVP.", "ALTA"),
    ("B05", "Desenhar estrutura de diretórios da skill MD", "Necessário para implementar persistência e fonte única de verdade.", "ALTA"),
    ("B06", "Definir comandos e triggers operacionais", "O comando 'captura' precisa ter regras claras de uso, classificação e atualização.", "ALTA"),
    ("B07", "Separar documentos de conhecimento bruto, hipóteses e decisões validadas", "Evita confusão entre exploração e verdade operacional.", "ALTA"),
    ("B08", "Criar modelo de arquivo para decisões", "Decisões precisam ser versionadas e rastreáveis.", "ALTA"),
    ("B09", "Criar modelo de arquivo para product self-knowledge", "Necessário para que o agente entenda produto, escopo, limites e proposta de valor.", "ALTA"),
    ("B10", "Definir arquitetura de persistência", "Sem isso, a skill funciona apenas como instrução estática, não como memória viva.", "ALTA"),
    ("B11", "Definir métricas primárias de validação", "Sem métricas, a validação pode virar percepção subjetiva.", "ALTA"),
    ("B12", "Mapear concorrentes e alternativas", "Necessário para entender diferenciação, posicionamento e objeções.", "MÉDIA"),
    ("B13", "Definir experimentos de baixo custo", "Landing page, formulário, entrevistas e lista de espera podem validar demanda antes de construção.", "ALTA"),
    ("B14", "Criar arquivos específicos por fase do ciclo", "Cada fase precisa ter perguntas, dados, tags e entregáveis próprios.", "ALTA"),
    ("B15", "Criar modelo de arquivo para brand guidelines", "Necessário para consistência de linguagem, posicionamento e apresentação.", "MÉDIA"),
    ("B16", "Transformar portfólio demonstrativo em caso de uso", "Pode validar a arquitetura e apoiar venda futura.", "MÉDIA"),
    ("B17", "Definir critérios para escolha entre MVP options", "SaaS Web, curso, plataforma, consultoria ou Project to Linear.", "ALTA"),
    ("B18", "Definir como resultados de validação serão registrados na skill MD", "Necessário para fechar o ciclo measure → iterate.", "ALTA"),
]
for bid, title, motivo, pri in backlog:
    add("BACKLOG DE ANÁLISE", bid, "DISCOVERY → VALIDATION", f"{title} | Motivo: {motivo}", "TAGS", "PENDENTE", pri)

# ─────────────────────────────────────────────────────────
# 14. EXTRACT — CYCLE PHASES & TAGS (structural facts)
# ─────────────────────────────────────────────────────────
cycle_phases = [
    ("SCOPE", "Define o que será analisado, construído ou validado. Perguntas: Qual problema? Qual hipótese? Qual público? Qual decisão a desbloquear? O que está fora do escopo?", "fase_scope: objetivo, hipotese_relacionada, publico_analisado, decisao_a_desbloquear, fora_de_escopo"),
    ("DISCOVERY", "Coleta informações qualitativas e quantitativas sobre mercado, público, dores, concorrência, comportamento e contexto.", "fase_discovery: dados_coletados, fontes, padroes_observados, dores_identificadas, objeções_identificadas, lacunas_de_dados"),
    ("DIAGNOSIS", "Transforma dados coletados em leitura estratégica.", "fase_diagnosis: hipoteses_suportadas, hipoteses_nao_suportadas, hipoteses_inconclusivas, principais_insights, principais_riscos, tensoes_estrategicas"),
    ("STRATEGY", "Define o caminho recomendado com base no diagnóstico.", "fase_strategy: publico_prioritario, posicionamento, proposta_de_valor, modelo_de_negocio_prioritario, canal_prioritario, criterios_de_decisao"),
    ("DESIGN", "Converte a estratégia em arquitetura de produto, oferta, experiência e entregáveis.", "fase_design: arquitetura_da_solucao, componentes_do_mvp, fluxo_do_usuario, entregaveis, pontos_de_personalizacao, requisitos_de_ux"),
    ("VALIDATION", "Testa se a estratégia e a solução fazem sentido antes de construir demais.", "fase_validation: experimento, hipotese_testada, metrica_primaria, resultado_esperado, resultado_obtido, interpretacao, decisao_recomendada"),
    ("BUILD", "Constrói somente o necessário para entregar ou testar a proposta validada.", "fase_build: ativos_a_construir, prioridade, dependencias, versao_minima, criterio_de_pronto, riscos_tecnicos"),
    ("LAUNCH", "Coloca a oferta no mercado com canal, mensagem e conversão.", "fase_launch: oferta, publico, canal, mensagem, preco, cta, metrica_de_sucesso"),
    ("MEASURE", "Mede o desempenho real da oferta, canal, mensagem e produto.", "fase_measure: metricas_coletadas, resultado_por_metrica, benchmark, desvios, aprendizados, qualidade_dos_dados"),
    ("ITERATE", "Usa os dados para ajustar hipótese, oferta, produto, canal ou público.", "fase_iterate: o_que_manter, o_que_alterar, o_que_remover, nova_hipotese, proximo_experimento, proxima_decisao"),
]
for phase, desc, tag_fields in cycle_phases:
    add("CICLO DATA-DRIVEN", phase, phase, f"{desc} | Tags XML: {tag_fields}", "README+BRIFING+TAGS", "ESTRUTURAL", "ALTA")

# ─────────────────────────────────────────────────────────
# 15. EXTRACT — VALIDATION METHODS & METRICS
# ─────────────────────────────────────────────────────────
val_methods = [
    ("Entrevistas com consultores", "Qualitativo", "Dores, objeções, nível de maturidade técnica, interesse em pagar"),
    ("Formulário de pesquisa", "Qualitativo + Quantitativo", "Segmentação, ranking de interesse, intenção de pagamento, objeções frequentes"),
    ("Análise de concorrentes", "Desk research", "Diferenciação, posicionamento, lacunas de mercado"),
    ("Análise de conteúdo (LinkedIn, YouTube, Instagram, blogs)", "Desk research", "Padrões de dor expressos publicamente, linguagem do público, temas recorrentes"),
    ("Benchmark de cursos, comunidades, SaaS e consultorias de IA", "Desk research", "Preços praticados, formatos, público, proposta de valor"),
    ("Landing page + lista de espera", "Quantitativo", "Taxa de conversão, leads capturados, interesse por oferta"),
    ("Pré-venda", "Quantitativo", "Intenção de pagamento real, validação de preço"),
    ("Demo navegável", "Qualitativo", "Nível de engajamento, objeções, clareza da proposta"),
    ("Teste com consultores", "Qualitativo + Usabilidade", "Fricção de uso, tempo de configuração, satisfação"),
    ("Formulário com ranking de interesse", "Quantitativo", "Comparação entre ofertas, priorização de público"),
]
for method, mtype, what_measures in val_methods:
    add("MÉTODO DE VALIDAÇÃO", mtype, "VALIDATION", f"{method} | Mede: {what_measures}", "BRIFING+TAGS", "DISPONÍVEL", "ALTA")

metrics = [
    "Visitas na landing page",
    "Taxa de conversão",
    "Leads capturados",
    "Respostas à pesquisa",
    "Custo por lead",
    "Taxa de abertura de e-mail",
    "Cliques",
    "Interesse por oferta",
    "Intenção de pagamento",
    "Objeções mais frequentes",
    "Tempo para configurar skill",
    "Satisfação do usuário",
    "Uso recorrente",
    "Taxa de conclusão do curso",
]
for m in metrics:
    add("MÉTRICA DE VALIDAÇÃO", "KPI", "MEASURE", m, "BRIFING", "DEFINIDA", "ALTA")

# ─────────────────────────────────────────────────────────
# 16. EXTRACT — PRODUCT COMPONENTS
# ─────────────────────────────────────────────────────────
components = [
    ("Skill MD / Markdown do X-Ray Business", "Organizar o conhecimento central do projeto em documentos persistentes e reutilizáveis.", "Reduz perda de contexto e cria fonte única de verdade.", "EM FORMULAÇÃO"),
    ("Ciclo data-driven X-Ray Business", "Estruturar o desenvolvimento do negócio em fases claras, com perguntas, tags e critérios de decisão.", "Evita execução prematura e força validação progressiva.", "INCORPORADO"),
    ("Trigger 'captura'", "Acionar internalização de decisões, insights e atualizações durante conversas ou pesquisas.", "Transforma informação emergente em conhecimento salvo e estruturado.", "CONCEITO DEFINIDO"),
    ("Diretório interno da skill", "Organizar arquivos por temas: briefing, scope, discovery, diagnosis, strategy, design, validation, decisões, brand guidelines, produto, operação e backlog.", "Permite navegação, manutenção e evolução do conhecimento.", "PENDENTE DE DESENHO"),
    ("Fonte única de verdade", "Consolidar informações finais e atualizadas do projeto.", "Evita contradições, duplicidade e desalinhamento.", "NECESSIDADE VALIDADA"),
    ("Matriz de validação", "Transformar hipóteses em perguntas, métodos, métricas, evidências e critérios de decisão.", "Ajuda a decidir com dados qual público, oferta, canal e MVP priorizar.", "PENDENTE DE CRIAÇÃO"),
    ("Portfólio demonstrativo", "Demonstrar arquitetura, funcionamento e potencial de uso da solução.", "Demo, material comercial e referência operacional.", "IDEIA REGISTRADA"),
    ("Biblioteca inicial de skills", "Oferecer exemplos, templates ou módulos reutilizáveis para consultores.", "Reduz fricção de adoção e tangibiliza a proposta.", "HIPÓTESE DE MVP"),
    ("Fluxo de instalação guiada", "Reduzir barreiras técnicas para uso das skills.", "Aumenta probabilidade de adoção por consultores menos técnicos.", "PENDENTE DE DESENHO"),
    ("E-book interativo", "Demonstrar capacidade de entrega e educação do usuário.", "Ativo de marketing, onboarding ou prova de conceito.", "HIPÓTESE DE ENTREGÁVEL"),
    ("Project to Linear", "Funcionar como case demonstrável ou fluxo específico da arquitetura.", "Mostra aplicação prática da metodologia em workflow concreto.", "HIPÓTESE DE CASE/MVP"),
]
for name, func, value, stage in components:
    add("COMPONENTE DO PRODUTO", name, "DESIGN → BUILD", f"Função: {func} | Valor: {value}", "TAGS", stage, "ALTA")

# ─────────────────────────────────────────────────────────
# 17. BUILD XLSX
# ─────────────────────────────────────────────────────────
wb = openpyxl.Workbook()

# ── COLOR PALETTE ──
DARK_BG    = "1A1A2E"
MID_BG     = "16213E"
ACCENT     = "0F3460"
HIGHLIGHT  = "533483"
GREEN_DARK = "1B5E20"
RED_DARK   = "B71C1C"
AMBER      = "F57F17"
TEAL       = "006064"
PURPLE     = "4A148C"
NAVY       = "0D47A1"
WHITE      = "FFFFFF"
LIGHT_GRAY = "F5F5F5"
MID_GRAY   = "E0E0E0"

CAT_COLORS = {
    "PROBLEMA/DOR":           ("B71C1C", WHITE),
    "HIPÓTESE":               ("0D47A1", WHITE),
    "PÚBLICO / PERSONA":      ("006064", WHITE),
    "MODELO DE NEGÓCIO":      ("4A148C", WHITE),
    "PROPOSTA DE VALOR":      ("1B5E20", WHITE),
    "INSIGHT ESTRATÉGICO":    ("E65100", WHITE),
    "RISCO":                  ("880E4F", WHITE),
    "OPORTUNIDADE":           ("33691E", WHITE),
    "DÚVIDA EM ABERTO":       ("37474F", WHITE),
    "DECISÃO TOMADA":         ("1A237E", WHITE),
    "BACKLOG DE ANÁLISE":     ("4E342E", WHITE),
    "CICLO DATA-DRIVEN":      ("006064", WHITE),
    "MÉTODO DE VALIDAÇÃO":    ("558B2F", WHITE),
    "MÉTRICA DE VALIDAÇÃO":   ("00695C", WHITE),
    "COMPONENTE DO PRODUTO":  ("283593", WHITE),
}

PRIORITY_COLORS = {"ALTA": "B71C1C", "MÉDIA": "E65100", "BAIXA": "2E7D32"}
STATUS_COLORS = {
    "IDENTIFICADO": "1565C0", "NÃO VALIDADA": "6A1B9A",
    "A VALIDAR": "AD1457", "PRIORIDADE": "1B5E20",
    "MAPEADO": "37474F", "MAPEADA": "37474F",
    "REGISTRADO": "0277BD", "CONFIRMADA": "1565C0",
    "PENDENTE": "BF360C", "DISPONÍVEL": "2E7D32",
    "DEFINIDA": "00695C", "EM FORMULAÇÃO": "4527A0",
    "INCORPORADO": "1B5E20", "CONCEITO DEFINIDO": "006064",
    "PENDENTE DE DESENHO": "BF360C", "NECESSIDADE VALIDADA": "1565C0",
    "PENDENTE DE CRIAÇÃO": "BF360C", "IDEIA REGISTRADA": "546E7A",
    "HIPÓTESE DE MVP": "6A1B9A", "HIPÓTESE DE ENTREGÁVEL": "6A1B9A",
    "HIPÓTESE DE CASE/MVP": "6A1B9A", "ESTRUTURAL": "004D40",
    "NÃO RESOLVIDA": "BF360C", "LEVANTADO": "546E7A",
    "DECISÃO TOMADA": "1565C0", "PROVISÓRIA — NÃO VALIDADA": "AD1457",
}

def thin_border():
    s = Side(style='thin', color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)

def header_style(ws, cell_addr, text, bg, fg=WHITE, size=11, bold=True, wrap=True):
    c = ws[cell_addr]
    c.value = text
    c.font = Font(name="Arial", bold=bold, color=fg, size=size)
    c.fill = PatternFill("solid", fgColor=bg)
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=wrap)
    c.border = thin_border()

def data_style(ws, cell_addr, text, bg=None, fg="1A1A2E", wrap=True, bold=False, h_align="left"):
    c = ws[cell_addr]
    c.value = str(text) if text is not None else ""
    c.font = Font(name="Arial", color=fg, size=9, bold=bold)
    if bg:
        c.fill = PatternFill("solid", fgColor=bg)
    c.alignment = Alignment(horizontal=h_align, vertical="top", wrap_text=wrap)
    c.border = thin_border()

# ── SHEET 1: DISCOVERY & RESEARCH MASTER ──
ws1 = wb.active
ws1.title = "DISCOVERY_RESEARCH"
ws1.sheet_view.showGridLines = False
ws1.freeze_panes = "A3"

# Title row
ws1.merge_cells("A1:J1")
c = ws1["A1"]
c.value = "X-RAY BUSINESS — DISCOVERY & RESEARCH MASTER EXTRACT"
c.font = Font(name="Arial", bold=True, color=WHITE, size=14)
c.fill = PatternFill("solid", fgColor=DARK_BG)
c.alignment = Alignment(horizontal="center", vertical="center")
ws1.row_dimensions[1].height = 32

headers = ["#", "CATEGORY", "SUBCATEGORY", "PHASE", "CONTENT", "SOURCE", "STATUS", "PRIORITY", "ACTION NEEDED", "NOTES"]
cols =    [4,   22,          20,            18,      60,        12,       24,       10,         28,              20]

for i, (h, w) in enumerate(zip(headers, cols), 1):
    col_l = get_column_letter(i)
    ws1.column_dimensions[col_l].width = w
    header_style(ws1, f"{col_l}2", h, ACCENT, WHITE, 10, True)

ws1.row_dimensions[2].height = 20

prev_cat = None
row_num = 3
for i, r in enumerate(ROWS, 1):
    cat = r["CATEGORY"]
    bg_hex, fg_hex = CAT_COLORS.get(cat, ("ECEFF1", "1A1A2E"))

    # category separator row
    if cat != prev_cat:
        ws1.merge_cells(f"A{row_num}:J{row_num}")
        c = ws1[f"A{row_num}"]
        c.value = f"▌ {cat}"
        c.font = Font(name="Arial", bold=True, color=WHITE, size=10)
        c.fill = PatternFill("solid", fgColor=bg_hex)
        c.alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws1.row_dimensions[row_num].height = 18
        row_num += 1
        prev_cat = cat

    row_bg = "FAFAFA" if i % 2 == 0 else WHITE
    pri_color = PRIORITY_COLORS.get(r["PRIORITY"], "546E7A")
    st_color  = STATUS_COLORS.get(r["STATUS"], "546E7A")

    data_style(ws1, f"A{row_num}", i, row_bg, "546E7A", False, False, "center")
    data_style(ws1, f"B{row_num}", cat, bg_hex, fg_hex, True, True)
    data_style(ws1, f"C{row_num}", r["SUBCATEGORY"], row_bg, "1A1A2E")
    data_style(ws1, f"D{row_num}", r["PHASE"], row_bg, "37474F")
    data_style(ws1, f"E{row_num}", r["CONTENT"], row_bg, "1A1A2E")
    data_style(ws1, f"F{row_num}", r["SOURCE"], row_bg, "546E7A", False, False, "center")
    data_style(ws1, f"G{row_num}", r["STATUS"], st_color, WHITE, False, True, "center")
    ws1[f"G{row_num}"].fill = PatternFill("solid", fgColor=st_color)
    data_style(ws1, f"H{row_num}", r["PRIORITY"], pri_color, WHITE, False, True, "center")
    ws1[f"H{row_num}"].fill = PatternFill("solid", fgColor=pri_color)
    data_style(ws1, f"I{row_num}", "", row_bg)
    data_style(ws1, f"J{row_num}", "", row_bg)
    ws1.row_dimensions[row_num].height = 48
    row_num += 1

# ── SHEET 2: VALIDATION MATRIX ──
ws2 = wb.create_sheet("VALIDATION_MATRIX")
ws2.sheet_view.showGridLines = False
ws2.freeze_panes = "A3"

ws2.merge_cells("A1:K1")
c = ws2["A1"]
c.value = "X-RAY BUSINESS — VALIDATION MATRIX"
c.font = Font(name="Arial", bold=True, color=WHITE, size=14)
c.fill = PatternFill("solid", fgColor=MID_BG)
c.alignment = Alignment(horizontal="center", vertical="center")
ws2.row_dimensions[1].height = 32

vh = ["ID", "HIPÓTESE", "PÚBLICO", "EVIDÊNCIA NECESSÁRIA", "MÉTODO DE VALIDAÇÃO", "MÉTRICA PRIMÁRIA", "CRITÉRIO DE SUCESSO", "CUSTO", "PRAZO", "STATUS", "PRIORIDADE"]
vw = [6, 40, 16, 30, 25, 22, 25, 10, 10, 18, 12]
for i, (h, w) in enumerate(zip(vh, vw), 1):
    col_l = get_column_letter(i)
    ws2.column_dimensions[col_l].width = w
    header_style(ws2, f"{col_l}2", h, HIGHLIGHT, WHITE, 10)
ws2.row_dimensions[2].height = 20

val_matrix = [
    ("H01", "X-Ray Business como co-pilot para consultores gera valor real", "Consultor solo / Boutique", "3+ consultores confirmam dor e interesse", "Entrevistas qualitativas (5-10)", "Taxa de confirmação de dor", "≥70% confirmam problema e veem valor", "Baixo", "2 sem", "NÃO INICIADA", "ALTA"),
    ("H02", "Posicionamento como co-pilot (não automação) é diferenciador", "Consultor solo / Boutique", "Público prefere co-pilot a automação total", "Entrevista + teste de mensagem A/B", "Preferência declarada", "≥60% preferem co-pilot vs. automação", "Baixo", "2 sem", "NÃO INICIADA", "ALTA"),
    ("H03", "Skill MD persistente resolve perda de contexto", "Consultor que usa IA", "Uso recorrente + feedback positivo", "Teste com consultores beta", "Uso recorrente em 7 dias", "≥3 usos em 7 dias sem prompt manual", "Médio", "4 sem", "NÃO INICIADA", "ALTA"),
    ("H06", "Consultores pagariam por SaaS Web de skills", "Consultor solo / Boutique", "Intenção de pagamento declarada + pré-venda", "Landing page + pré-venda ou waitlist", "% de conversão para pré-venda", "≥5% visitantes entram na waitlist", "Baixo", "3 sem", "NÃO INICIADA", "ALTA"),
    ("H07-A", "Curso como MVP inicial é viável", "Consultor solo", "Interesse confirmado + intenção de pagamento", "Formulário + landing page", "Leads qualificados", "≥20 leads qualificados em 2 semanas", "Baixo", "2 sem", "NÃO INICIADA", "ALTA"),
    ("H07-B", "Portfólio demonstrativo gera leads qualificados", "Consultor / Founder", "Cliques, leads, pedidos de demo", "Landing page + portfólio + formulário", "Leads capturados", "≥10 leads em 2 semanas", "Baixo", "2 sem", "NÃO INICIADA", "ALTA"),
    ("H07-C", "Project to Linear como case demonstrável atrai interesse", "Consultor técnico", "Engajamento com demo + pedido de acesso", "Demo navegável + formulário", "Taxa de engajamento com demo", "≥40% que veem o demo pedem mais info", "Baixo", "3 sem", "NÃO INICIADA", "MÉDIA"),
    ("H07-D", "Consultoria guiada como MVP inicial é viável", "Boutique de consultoria", "Interesse em sessão paga ou piloto", "Outreach direto + proposta", "Sessões agendadas / aceitas", "≥2 sessões pagas em 4 semanas", "Baixo", "4 sem", "NÃO INICIADA", "ALTA"),
    ("H08-A", "Consultor solo é o público inicial ideal", "Consultor solo", "Dados de entrevista + conversão > boutique", "Entrevistas + landing page segmentada", "Conversão vs. boutique", "Conversão ou NPS superior a boutique", "Baixo", "4 sem", "NÃO INICIADA", "ALTA"),
    ("H08-B", "Boutique de consultoria é o público inicial ideal", "Boutique de consultoria", "Dados de entrevista + conversão > consultor solo", "Entrevistas + outreach direto", "Conversão vs. consultor solo", "Conversão ou NPS superior a consultor solo", "Baixo", "4 sem", "NÃO INICIADA", "ALTA"),
    ("H09", "Fricção técnica é barreira real de adoção", "Consultor com interesse em IA", "Desistência no onboarding ou pedido de suporte", "Teste de usabilidade com 5 consultores", "Taxa de conclusão do onboarding", "Se <60% concluem: fricção é barreira confirmada", "Baixo", "3 sem", "NÃO INICIADA", "ALTA"),
    ("H10", "Oferta educacional é mais adequada que SaaS como MVP", "Consultor solo / Boutique", "Maior conversão em curso vs. SaaS", "Teste A/B de mensagens (curso vs. plataforma)", "Taxa de interesse por oferta", "Curso converte ≥2x mais que SaaS", "Baixo", "3 sem", "NÃO INICIADA", "ALTA"),
]
for vr_i, vr in enumerate(val_matrix, 3):
    row_bg = "F5F5F5" if vr_i % 2 == 0 else WHITE
    for col_i, val in enumerate(vr, 1):
        col_l = get_column_letter(col_i)
        data_style(ws2, f"{col_l}{vr_i}", val, row_bg)
        if col_i == 11:  # PRIORIDADE
            p_col = PRIORITY_COLORS.get(val, "546E7A")
            ws2[f"{col_l}{vr_i}"].fill = PatternFill("solid", fgColor=p_col)
            ws2[f"{col_l}{vr_i}"].font = Font(name="Arial", color=WHITE, size=9, bold=True)
    ws2.row_dimensions[vr_i].height = 44

# ── SHEET 3: PHASE TEMPLATES ──
ws3 = wb.create_sheet("PHASE_TEMPLATES")
ws3.sheet_view.showGridLines = False

ws3.merge_cells("A1:F1")
c = ws3["A1"]
c.value = "X-RAY BUSINESS — PHASE TEMPLATES (SCOPE → STRATEGY)"
c.font = Font(name="Arial", bold=True, color=WHITE, size=14)
c.fill = PatternFill("solid", fgColor=DARK_BG)
c.alignment = Alignment(horizontal="center", vertical="center")
ws3.row_dimensions[1].height = 32
for col_l, w in zip(["A","B","C","D","E","F"], [20, 30, 50, 20, 20, 30]):
    ws3.column_dimensions[col_l].width = w

phase_tmpl = [
    ("SCOPE", "objetivo", "[O que será analisado, construído ou validado]", "PENDENTE", "ALTA", ""),
    ("SCOPE", "hipotese_relacionada", "[Hipótese que esta análise precisa confirmar ou refutar]", "PENDENTE", "ALTA", ""),
    ("SCOPE", "publico_analisado", "[Quem está sendo analisado: consultor solo, boutique, etc.]", "PENDENTE", "ALTA", ""),
    ("SCOPE", "decisao_a_desbloquear", "[Qual decisão este ciclo precisa viabilizar]", "PENDENTE", "ALTA", ""),
    ("SCOPE", "fora_de_escopo", "[O que não será analisado nesta rodada]", "PENDENTE", "MÉDIA", ""),
    ("DISCOVERY", "dados_coletados", "[Inserir dados coletados de mercado, público, dores, concorrentes]", "PENDENTE", "ALTA", ""),
    ("DISCOVERY", "fontes", "[Entrevistas, formulários, benchmarks, conteúdo, desk research]", "PENDENTE", "ALTA", ""),
    ("DISCOVERY", "padroes_observados", "[Padrões recorrentes encontrados nos dados]", "PENDENTE", "ALTA", ""),
    ("DISCOVERY", "dores_identificadas", "[Dores específicas verbalizadas ou observadas no público]", "PENDENTE", "ALTA", ""),
    ("DISCOVERY", "objeções_identificadas", "[Objeções ao produto, preço, complexidade ou mudança de hábito]", "PENDENTE", "ALTA", ""),
    ("DISCOVERY", "lacunas_de_dados", "[O que ainda não foi coletado e precisa ser]", "PENDENTE", "ALTA", ""),
    ("DIAGNOSIS", "hipoteses_suportadas", "[Hipóteses fortalecidas pelos dados coletados]", "PENDENTE", "ALTA", ""),
    ("DIAGNOSIS", "hipoteses_nao_suportadas", "[Hipóteses enfraquecidas ou refutadas]", "PENDENTE", "ALTA", ""),
    ("DIAGNOSIS", "hipoteses_inconclusivas", "[Hipóteses sem evidência suficiente para decidir]", "PENDENTE", "ALTA", ""),
    ("DIAGNOSIS", "principais_insights", "[Leitura estratégica extraída dos dados]", "PENDENTE", "ALTA", ""),
    ("DIAGNOSIS", "principais_riscos", "[Riscos tornados mais visíveis após análise]", "PENDENTE", "ALTA", ""),
    ("DIAGNOSIS", "tensoes_estrategicas", "[Contradições ou dilemas que precisam ser resolvidos]", "PENDENTE", "ALTA", ""),
    ("STRATEGY", "publico_prioritario", "[Segmento escolhido com base no diagnóstico]", "PENDENTE", "ALTA", ""),
    ("STRATEGY", "posicionamento", "[Como o X-Ray Business se posiciona vs. alternativas]", "PENDENTE", "ALTA", ""),
    ("STRATEGY", "proposta_de_valor", "[Declaração de valor validada para o público prioritário]", "PENDENTE", "ALTA", ""),
    ("STRATEGY", "modelo_de_negocio_prioritario", "[SaaS, curso, consultoria, portfólio, Project to Linear]", "PENDENTE", "ALTA", ""),
    ("STRATEGY", "canal_prioritario", "[Canal de aquisição prioritário: LinkedIn, Instagram, direct, etc.]", "PENDENTE", "ALTA", ""),
    ("STRATEGY", "criterios_de_decisao", "[O que precisa ser verdade para avançar para Design e Build]", "PENDENTE", "ALTA", ""),
]

header_style(ws3, "A2", "FASE", ACCENT, WHITE, 10)
header_style(ws3, "B2", "CAMPO", ACCENT, WHITE, 10)
header_style(ws3, "C2", "CONTEÚDO ATUAL", ACCENT, WHITE, 10)
header_style(ws3, "D2", "STATUS", ACCENT, WHITE, 10)
header_style(ws3, "E2", "PRIORIDADE", ACCENT, WHITE, 10)
header_style(ws3, "F2", "RESPONSÁVEL / MÉTODO", ACCENT, WHITE, 10)
ws3.row_dimensions[2].height = 20

phase_colors = {"SCOPE": "0D47A1", "DISCOVERY": "1B5E20", "DIAGNOSIS": "4A148C", "STRATEGY": "880E4F"}
for pt_i, pt in enumerate(phase_tmpl, 3):
    phase, field, content, status, pri, resp = pt
    ph_col = phase_colors.get(phase, "37474F")
    row_bg = "FAFAFA" if pt_i % 2 == 0 else WHITE
    data_style(ws3, f"A{pt_i}", phase, ph_col, WHITE, False, True, "center")
    ws3[f"A{pt_i}"].fill = PatternFill("solid", fgColor=ph_col)
    data_style(ws3, f"B{pt_i}", field, row_bg, "1A1A2E")
    data_style(ws3, f"C{pt_i}", content, row_bg, "546E7A")
    data_style(ws3, f"D{pt_i}", status, "BF360C", WHITE, False, True, "center")
    ws3[f"D{pt_i}"].fill = PatternFill("solid", fgColor="BF360C")
    data_style(ws3, f"E{pt_i}", pri, PRIORITY_COLORS.get(pri, "546E7A"), WHITE, False, True, "center")
    ws3[f"E{pt_i}"].fill = PatternFill("solid", fgColor=PRIORITY_COLORS.get(pri, "546E7A"))
    data_style(ws3, f"F{pt_i}", resp, row_bg)
    ws3.row_dimensions[pt_i].height = 36

# ── SHEET 4: LEGEND ──
ws4 = wb.create_sheet("LEGEND")
ws4.sheet_view.showGridLines = False
ws4.column_dimensions["A"].width = 25
ws4.column_dimensions["B"].width = 55

ws4.merge_cells("A1:B1")
c = ws4["A1"]
c.value = "X-RAY BUSINESS — LEGEND & TAXONOMY"
c.font = Font(name="Arial", bold=True, color=WHITE, size=14)
c.fill = PatternFill("solid", fgColor=DARK_BG)
c.alignment = Alignment(horizontal="center", vertical="center")
ws4.row_dimensions[1].height = 32

legend_data = [
    ("CATEGORY", "TYPE"),
    ("PROBLEMA/DOR", "Dores identificadas no público-alvo que o produto precisa resolver"),
    ("HIPÓTESE", "Afirmação não validada sobre mercado, produto, público ou modelo de negócio"),
    ("PÚBLICO / PERSONA", "Perfis de usuários e clientes identificados para validação"),
    ("MODELO DE NEGÓCIO", "Opções de formato comercial em análise"),
    ("PROPOSTA DE VALOR", "Declaração de benefício para o público-alvo"),
    ("INSIGHT ESTRATÉGICO", "Interpretação de dados ou padrões com implicação estratégica"),
    ("RISCO", "Ameaça identificada ao projeto, adoção ou entregável"),
    ("OPORTUNIDADE", "Possibilidade de captura de valor ou diferenciação"),
    ("DÚVIDA EM ABERTO", "Questão sem resposta que bloqueia ou influencia decisão"),
    ("DECISÃO TOMADA", "Escolha consolidada que orienta execução"),
    ("BACKLOG DE ANÁLISE", "Item pendente de pesquisa, análise ou definição"),
    ("CICLO DATA-DRIVEN", "Fases estruturais do ciclo de desenvolvimento do X-Ray Business"),
    ("MÉTODO DE VALIDAÇÃO", "Técnica de coleta de evidências para testar hipóteses"),
    ("MÉTRICA DE VALIDAÇÃO", "KPI para medir resultado de experimentos"),
    ("COMPONENTE DO PRODUTO", "Elemento técnico ou funcional do produto em desenvolvimento"),
    ("", ""),
    ("STATUS", "MEANING"),
    ("NÃO VALIDADA", "Hipótese sem evidência coletada ainda"),
    ("A VALIDAR", "Item aguardando experimento ou pesquisa"),
    ("IDENTIFICADO", "Dor ou risco reconhecido, não resolvido"),
    ("CONFIRMADA", "Decisão tomada e registrada"),
    ("PENDENTE", "Item no backlog aguardando execução"),
    ("MAPEADO/MAPEADA", "Risco ou oportunidade documentado"),
    ("PRIORIDADE", "Item prioritário para próxima ação"),
    ("ESTRUTURAL", "Elemento central da arquitetura do projeto"),
    ("", ""),
    ("PRIORITY", "MEANING"),
    ("ALTA", "Ação imediata necessária. Bloqueia avanço ou decisão."),
    ("MÉDIA", "Importante mas não urgente. Pode aguardar próximo ciclo."),
    ("BAIXA", "Nice-to-have. Não bloqueia avanço."),
    ("", ""),
    ("PHASE", "DESCRIPTION"),
    ("SCOPE", "Define problema, hipótese, público e decisão a desbloquear"),
    ("DISCOVERY", "Coleta dados qualitativos e quantitativos sobre mercado e público"),
    ("DIAGNOSIS", "Interpreta dados, valida/refuta hipóteses, identifica riscos"),
    ("STRATEGY", "Define direção, público, oferta, canal e posicionamento"),
    ("DESIGN", "Desenha solução, UX, MVP e entregáveis"),
    ("VALIDATION", "Testa hipóteses com mercado antes de construir demais"),
    ("BUILD", "Constrói a versão mínima necessária para entregar ou testar"),
    ("LAUNCH", "Coloca a oferta no mercado com canal, mensagem e CTA"),
    ("MEASURE", "Mede desempenho real da oferta, canal, mensagem e produto"),
    ("ITERATE", "Usa dados para ajustar hipótese, oferta, produto, canal ou público"),
]
for li, (k, v) in enumerate(legend_data, 2):
    if v == "TYPE" or v == "MEANING" or v == "DESCRIPTION":
        header_style(ws4, f"A{li}", k, ACCENT, WHITE, 9)
        header_style(ws4, f"B{li}", v, ACCENT, WHITE, 9)
    elif k == "":
        ws4[f"A{li}"].value = ""
        ws4[f"B{li}"].value = ""
    else:
        bg = "FAFAFA" if li % 2 == 0 else WHITE
        data_style(ws4, f"A{li}", k, bg, "1A1A2E", False, True)
        data_style(ws4, f"B{li}", v, bg, "37474F")
    ws4.row_dimensions[li].height = 18

# ── SUMMARY TAB ──
ws5 = wb.create_sheet("SUMMARY", 0)
ws5.sheet_view.showGridLines = False
for col_l, w in zip(["A","B","C"], [28, 15, 40]):
    ws5.column_dimensions[col_l].width = w

ws5.merge_cells("A1:C1")
c = ws5["A1"]
c.value = "X-RAY BUSINESS — DISCOVERY EXTRACTION SUMMARY"
c.font = Font(name="Arial", bold=True, color=WHITE, size=15)
c.fill = PatternFill("solid", fgColor=DARK_BG)
c.alignment = Alignment(horizontal="center", vertical="center")
ws5.row_dimensions[1].height = 40

from collections import Counter
cat_counts = Counter(r["CATEGORY"] for r in ROWS)
pri_counts = Counter(r["PRIORITY"] for r in ROWS)

summary_rows = [
    ("EXTRACTION DATE", datetime.now().strftime("%Y-%m-%d"), ""),
    ("TOTAL ROWS EXTRACTED", len(ROWS), "Across all categories"),
    ("", "", ""),
    ("CATEGORY", "COUNT", ""),
]
for cat, cnt in sorted(cat_counts.items(), key=lambda x: -x[1]):
    summary_rows.append((cat, cnt, ""))
summary_rows.append(("", "", ""))
summary_rows.append(("PRIORITY", "COUNT", ""))
for pri, cnt in pri_counts.items():
    summary_rows.append((pri, cnt, ""))
summary_rows.append(("", "", ""))
summary_rows.append(("CURRENT PHASE", "SCOPE → DISCOVERY", "Priority: validate hypotheses before building"))
summary_rows.append(("NEXT ACTION", "Create validation matrix", "Transform H01-H10 into experiments"))
summary_rows.append(("KEY DECISION", "Define MVP initial focus", "SaaS / Course / Consulting / Portfolio"))
summary_rows.append(("PHASE PRIORITY", "Scope → Discovery → Diagnosis → Strategy", "Do NOT advance to Build without validation"))

for si, (a, b, note) in enumerate(summary_rows, 2):
    row_bg = "F5F5F5" if si % 2 == 0 else WHITE
    if a in ("CATEGORY", "PRIORITY", "EXTRACTION DATE", "TOTAL ROWS EXTRACTED",
             "CURRENT PHASE", "NEXT ACTION", "KEY DECISION", "PHASE PRIORITY"):
        data_style(ws5, f"A{si}", a, ACCENT, WHITE, False, True)
        ws5[f"A{si}"].fill = PatternFill("solid", fgColor=ACCENT)
        data_style(ws5, f"B{si}", str(b), ACCENT, WHITE, False, True, "center")
        ws5[f"B{si}"].fill = PatternFill("solid", fgColor=ACCENT)
        data_style(ws5, f"C{si}", note, ACCENT, WHITE)
        ws5[f"C{si}"].fill = PatternFill("solid", fgColor=ACCENT)
    else:
        data_style(ws5, f"A{si}", a, row_bg, "1A1A2E")
        data_style(ws5, f"B{si}", str(b) if b else "", row_bg, "37474F", False, False, "center")
        data_style(ws5, f"C{si}", note, row_bg, "546E7A")
    ws5.row_dimensions[si].height = 20

# ── SAVE ──
out_path = "/mnt/user-data/outputs/xray_discovery_research.xlsx"
wb.save(out_path)
total = len(ROWS)
print(f"Saved → {out_path}")
print(f"DISCOVERY_RESEARCH rows: {total}")
print(f"VALIDATION_MATRIX rows: {len(val_matrix)}")
print(f"PHASE_TEMPLATES rows: {len(phase_tmpl)}")
print(f"Categories: {len(cat_counts)}")
