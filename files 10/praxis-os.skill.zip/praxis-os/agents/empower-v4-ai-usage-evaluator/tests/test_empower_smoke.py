import subprocess
import sys
from pathlib import Path


def test_cli_help_runs():
    root = Path(__file__).resolve().parents[1]
    script = root / "scripts" / "empower_v4_evaluator.py"
    result = subprocess.run([sys.executable, str(script), "--help"], capture_output=True, text=True)
    assert result.returncode == 0
    assert "Empower V4" in result.stdout
