# Publishing Protocol

Use this when converting Empower results into GitHub, Medium, LinkedIn, or blog content.

## Public-Ready Rules

1. Remove or anonymize raw prompts and responses.
2. Convert accounts into archetypes.
3. Publish aggregate metrics and methodology, not private logs.
4. Distinguish proxy metrics from labeled quality results.
5. Include limitations: dataset size, imbalance, label coverage, and selection bias.
6. Provide reproducible scripts and synthetic examples when possible.
