# Metric Formulas

## Maturity Score

```text
maturity = 1 + 4 * (
  0.30 * prompt_structure +
  0.25 * context_richness +
  0.20 * output_control +
  0.10 * task_diversity +
  0.10 * high_value_task_share +
  0.05 * evidence_attachment
)
```

## Expansion Ratio

```text
expansion_ratio = response_length / max(prompt_length, 1)
```

## Lift

```text
lift = improved_rate / baseline_rate
absolute_delta = improved_rate - baseline_rate
normalized_delta = (improved_rate - baseline_rate) / baseline_rate
```

## Risk Heuristic

High risk when a row combines:

- short_direct prompt format
- low context richness
- high-value task type
- high expansion ratio
- missing evidence or quality labels
