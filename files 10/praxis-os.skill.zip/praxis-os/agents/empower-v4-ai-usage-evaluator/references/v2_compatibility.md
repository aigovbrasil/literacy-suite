# V2 Compatibility

V2 inputs may include RDF-lite facts, pattern registries, normalized account metrics, or early canonical interaction tables.

## Handling Rules

- Preserve source IDs.
- Map known columns into canonical schema.
- Create gap rows for unmapped fields.
- Mark inferred classifications as proxy metrics.
