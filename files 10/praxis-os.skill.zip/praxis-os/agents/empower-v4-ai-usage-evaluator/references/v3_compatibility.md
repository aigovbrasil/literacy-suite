# V3 Compatibility

V3 inputs may include maturity scorecards, quality label queues, account comparison tables, and prompt upgrade candidates.

## Handling Rules

- Reuse existing labels when available.
- Do not recompute labels manually.
- Keep structural metrics and quality metrics separate.
- Preserve prior account anonymization.
