# Output Contract

## Required Files

- `README.md`
- `empower_v4_report.md`
- `account_comparison.csv`
- `maturity_scorecard.csv`
- `risk_clusters.csv`
- `prompt_upgrade_candidates.csv`
- `normalized_interactions.csv`
- `run_manifest.json`

## Report Sections

1. Executive Summary
2. Dataset Profile
3. Maturity Scorecard
4. Account Comparison
5. Risk Clusters
6. Upgrade Candidates
7. Quality Labels / Lift, if available
8. Assumptions and Gaps
9. Next Actions
