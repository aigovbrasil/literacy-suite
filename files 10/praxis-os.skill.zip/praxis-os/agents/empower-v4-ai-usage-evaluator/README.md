# Empower V4 — AI Usage Evaluator Skill

This directory is a normalized `SKILL.md` package for evaluating AI/Claude usage patterns across accounts, conversations, prompts, and research datasets.

## Fast Start

```bash
python scripts/empower_v4_evaluator.py --input input.csv --mode full --output empower_v4_package --charts
```

For labeled quality analysis:

```bash
python scripts/empower_v4_evaluator.py --input interactions.csv --labels quality_labels_completed.csv --mode all --output empower_v4_package --charts
```

## Included Assets

- `SKILL.md` — activation rules, workflow, scoring rules, output contract.
- `scripts/empower_v4_evaluator.py` — main CLI evaluator.
- `scripts/build_epistemic.py` — epistemic extraction builder.
- `scripts/build_narrative_discovery.py` — narrative discovery builder.
- `examples/data/` — uploaded workbook examples preserved for reference.
- `references/` — compatibility, formulas, and publishing guidance.
- `schemas/` — canonical interaction schema.
- `tests/` — smoke test for CLI availability.

## Core Outputs

A normal run should produce:

- `empower_v4_report.md`
- `account_comparison.csv`
- `maturity_scorecard.csv`
- `risk_clusters.csv`
- `prompt_upgrade_candidates.csv`
- `normalized_interactions.csv`
- `run_manifest.json`

## Notes

Structural maturity is a proxy metric unless paired with human labels. Reports should explicitly mark confidence level, dataset imbalance, and label coverage.
