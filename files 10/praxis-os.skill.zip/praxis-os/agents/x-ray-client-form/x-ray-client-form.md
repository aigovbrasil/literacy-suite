---
description: Gera formulário HTML standalone de intake X-Ray (25 perguntas) para o cliente final do consultor responder via claude.ai (D0 flow) ou URL pública. Output JSON estruturado é importado de volta
  no x-ray-orchestrator. ATIVE SEMPRE para "gerar form de intake do cliente", "formulário X-Ray", "intake form Toni", "formulário de diagnóstico inicial", "/x-ray-deliver form-cliente", "criar form HTML
  para o cliente responder", "form D0", "intake widget claude", "diagnóstico inicial 8 minutos". TAMBÉM ATIVE quando o consultor mencionar enviar perguntas iniciais ao cliente via WhatsApp ou link, e precisar
  do template padrão. NÃO ATIVE para forms internos do consultor (use ask_user_input_v0) ou para forms genéricos não-X-Ray.
name: x-ray-client-form
---

# X-Ray Client Form

Gera o formulário HTML interativo que o cliente final do consultor preenche **sem precisar entender Claude** — apenas responde 25 perguntas e copia o JSON gerado no final, que volta para o consultor.

## Fluxo de uso (D0 → D2)

```
D0  Consultor envia mensagem WhatsApp ao cliente:
    "Cole isto no claude.ai → renderize como artifact → responda → copie JSON"
D0  Cliente cola o HTML no claude.ai
D0  Claude renderiza como artifact interativo
D0  Cliente responde 25 perguntas (~8 min)
D0  Cliente copia JSON output e envia ao consultor
D1  Consultor invoca: /x-ray-start --import-json [paste]
D1  x-ray-orchestrator preenche source_of_truth.md, abre Gate G1
D2  Consultor avança para diagnóstico (Fase 02)
```

Alternativa: o HTML pode ser hospedado em GitHub Pages / Vercel / Netlify. Cliente só recebe URL — zero dependência de claude.ai.

## Inputs

1. `consultant_config.yaml` — para brand do form (logo, cores, nome do consultor)
2. `client_name` — nome do cliente final (vai no header do form)
3. `session_id` — gerado automaticamente: `XRAY-YYYY-XXXXXX` (ano + 6 chars random)

## Estrutura das 25 perguntas

As perguntas seguem o padrão canonical do método X-Ray e cobrem 5 blocos:

| Bloco | Perguntas | Função |
|---|---|---|
| Identidade | 1–5 | Nome, empresa, segmento, tempo de operação, # funcionários |
| Demanda | 6–10 | Tipo de demanda, problema declarado, urgência, expectativa, orçamento |
| Operação atual | 11–17 | Faturamento aprox, principais produtos/serviços, canais, ferramentas, equipe, processos críticos, gargalos percebidos |
| Histórico | 18–21 | Tentativas anteriores, consultorias passadas, o que funcionou, o que não funcionou |
| Visão | 22–25 | Cenário de sucesso 6 meses, KPIs sonhados, restrições não-negociáveis, decisor final |

Cada pergunta tem:
- `id` (snake_case, estável entre versões)
- `question` (texto em PT-BR)
- `type` (text, textarea, select, multi_select, scale_1_5)
- `required` (true/false)
- `options` (se select/multi_select)
- `help_text` (opcional, abaixo do campo)

## Output JSON — formato canônico

```json
{
  "session_id": "XRAY-2026-A3F2K9",
  "client_name": "Toni Almeida",
  "client_company": "Almeida & Filhos Ltda",
  "consultant_short": "Rogerinho",
  "timestamp": "2026-05-01T14:32:00Z",
  "questions_answered": 25,
  "answers": {
    "tipo_demanda": "Estruturar operação para crescer",
    "problema_declarado": "Vendas estagnadas há 8 meses, equipe sem clareza de prioridades",
    "urgencia": "alta",
    "faturamento_aprox": "R$ 80k/mês",
    "...": "..."
  },
  "schema_version": "1.0.0"
}
```

O campo `schema_version` é crítico — permite que x-ray-orchestrator valide compatibilidade antes de importar.

## Padrão visual

- Single page, scroll vertical, progress bar fixa no topo
- Brand do consultor aplicado via x-ray-brand-layer (cor primária = botão "Avançar" e progress bar)
- Tipografia: Poppins (heading) + Lora (body) — sobrescrevível pelo config
- Mobile-first: form funciona perfeitamente em celular do cliente
- Sem dependências externas: tudo inline (CSS + JS no HTML)
- Local persistence via sessionStorage (cliente pode pausar e voltar)
- Botão final: "COPIAR E ENVIAR AO CONSULTOR" — copia JSON para clipboard com `navigator.clipboard`

## Mensagem para o consultor enviar (template)

Inclua sempre no final da geração, em arquivo separado `instrucoes-envio.md`:

```
Olá, [NOME_CLIENTE]!

Tudo pronto para começarmos. Antes da nossa primeira sessão, preciso que você
responda um diagnóstico rápido — leva cerca de 8 minutos.

Para isso:
1. Abra claude.ai no seu celular ou computador (gratuito, sem conta necessária)
2. Cole a mensagem abaixo na caixa de texto e envie
3. Responda as perguntas com calma — não existe resposta certa
4. No final, clique em "COPIAR E ENVIAR AO CONSULTOR" e me mande o resultado aqui

[SEU_NOME] · [CONSULTORIA]
```

Seguido pela mensagem que o cliente copia e cola no Claude:

```
Por favor, renderize o formulário HTML abaixo como um artifact interativo.
É um formulário de diagnóstico da consultoria [CONSULTOR]. O formulário já está
completo — apenas renderize exatamente como está, sem modificar nada.

```html
[CONTEÚDO COMPLETO DO FORM HTML AQUI]
```

Importante: renderize como artifact HTML interativo. Não modifique o código.
```

## Anti-patterns

- Não inclua nenhum tracking, analytics, ou chamada externa
- Não dependa de fontes não-CDN (Google Fonts é OK, custom font self-hosted não)
- Não use `localStorage` (browser storage não funciona em alguns artifact contexts) — use `sessionStorage` ou state em memória
- Não inclua perguntas sensíveis (CPF, dados bancários, senhas) — form é informacional, não transacional
- Não pré-preencha campos com dados de exemplo — gera confusão

## Validação antes de entregar ao consultor

```
✓ 25 perguntas presentes e numeradas
✓ Todas as `required: true` têm validação client-side
✓ JSON output testado: copia para clipboard sem erro
✓ Mobile rendering OK (Chrome DevTools → iPhone 12)
✓ Brand do consultor aplicada (cor, logo, signature)
✓ session_id é gerado dinamicamente no momento do submit
✓ Sem console errors no browser
✓ Funciona offline (zero requests além de Google Fonts)
```

## Versionamento de schema

Quando uma pergunta é adicionada/removida/renomeada:
- Incremente `schema_version` (1.0.0 → 1.1.0 ou 2.0.0 se breaking)
- x-ray-orchestrator valida compatibilidade na importação
- Forms antigos com schema desatualizado podem ser migrados via x-ray-db

## Output paths

- HTML: `/mnt/user-data/outputs/{consultant_short}-form-cliente-{client_short}.html`
- Instruções: `/mnt/user-data/outputs/{consultant_short}-instrucoes-envio.md`

Apresente ambos via `present_files` ao consultor.

## Relação com outras skills X-Ray

- Lê: consultant_config.yaml
- Chama: x-ray-brand-layer
- Output consumido por: x-ray-orchestrator (`/x-ray-start --import-json`)
- Roteado por: x-ray-self-knowledge → x-ray-orchestrator (`/x-ray-deliver form-cliente`)
