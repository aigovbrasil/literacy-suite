# Canonical Mapping — consultoria_canonical.json ↔ x-ray-db schema

Fonte: `consultoria_canonical.json` (X-RAY-FORM-CANONICAL-v1)

Mapeamento bidirecional: 19 fases × 13 gates × 100+ deliverables do
schema canônico de consultoria → 12 blocos YAML do x-ray-db.

---

## Quando consultar este arquivo

- Input é output de x-ray-abs em modo Canonical Engine (PASSO 8)
- Input cita "S00", "S05", "GATE-S07", "DEL-S15-XX", "D45", "D90"
- Usuário pede normalização YAML preservando taxonomia da consultoria
- Output do x-ray-db precisa preencher `roadmap[].phase` + `roadmap[].gate` corretamente

---

## Mapping Table — 19 Fases Canônicas × Schema Blocks

| Fase Canônica | Nome                              | D-Day      | Schema Block Principal                    |
|---------------|-----------------------------------|------------|-------------------------------------------|
| S00           | Entrada/Qualificação              | D0         | `project.decision_question` + GATE-S00    |
| S01           | Qualificação Empreendedor         | D1-D3      | `project.stakeholders` + `executive_context.delta` |
| S02           | Pergunta de Decisão               | D2         | `project.decision_question` + `success_criteria` |
| S03           | Construção do Escopo              | D3-D4      | `project.scope` (custom) + `frameworks[]` |
| S04           | Kickoff Oficial                   | D4         | GATE-S04 em `roadmap[].gate`              |
| S05           | Diagnóstico Interno               | D5-D10     | `areas[]` + `artifacts[]`                 |
| S06           | Pesquisa Externa                  | D10-D20    | `executive_context.current_state` + `frameworks[]` (TAM/SAM/SOM) |
| S07           | Validação Qualitativa             | D15-D25    | `pilot_cases[]` (entrevistas) + GATE-S07  |
| S08           | Validação Quantitativa            | D20-D35    | `pilot_cases[].metric_*` + GATE-S08       |
| S09           | Diagnóstico Integrado             | D25-D35    | `executive_context.delta` + `risks[]`     |
| S10           | Opções Estratégicas               | D35-D45    | `frameworks[]` (scoring matrix) + `next_steps[].score` |
| S11           | Testes Mínimos                    | D40-D50    | `pilot_cases[]` + GATE-S11                |
| S12           | Recomendação Estratégica          | D45        | `executive_context.target_state` + GATE-S12 |
| S13           | Modelo de Negócio                 | D45-D55    | `modules[]` (pricing, ops, gtm)           |
| S14           | Roadmap 30/60/90                  | D55-D65    | `roadmap[]` completo                      |
| S15           | Ativos de Execução                | D65-D75    | `artifacts[]` (4 categorias × 30+ items)  |
| S16           | Piloto Assistido                  | D75-D90    | `pilot_cases[]` (status: running/completed) + GATE-S16 |
| S17           | Padronização                      | D90-D105   | `workflows[]` padronizados                |
| S18           | Transferência Conhecimento        | D105-D115  | `workflows[].owner` + GATE-S18            |
| S19           | Handover Final                    | D115-D120  | GATE-S19 (5 condições)                    |

---

## Mapping Table — 13 Gates Canônicos

| Gate Canônico | x-ray-abs label | Critério Go                                          |
|---------------|-----------------|-------------------------------------------------------|
| GATE-S00      | (entrada)       | DQ formulada                                          |
| GATE-S01      | (fit)           | Fit empreendedor-oportunidade ≥ 6/10                  |
| GATE-S02      | (DQ aprovada)   | DQ aprovada pelo empreendedor                         |
| GATE-S03      | (escopo)        | Escopo aprovado                                       |
| GATE-S04      | G0              | 5/5 condições kickoff confirmadas                     |
| GATE-S05      | (dados internos)| Dados internos suficientes                            |
| GATE-S06      | (dor mercado)   | Evidência externa de dor + TAM/SAM/SOM                |
| GATE-S07      | G1              | Dor real + frequente + monetizável (≥60% entrevistas) |
| GATE-S08      | (unit econ)     | LTV>CAC + margem positiva                             |
| GATE-S09      | G2              | Diagnóstico causal robusto                            |
| GATE-S10      | G3              | Opção superior identificada                           |
| GATE-S11      | G4              | Hipótese mínima validada                              |
| GATE-S12      | G5              | Empreendedor aceita recomendação                      |
| GATE-S13      | G6              | Modelo viável fin+ops                                 |
| GATE-S14      | G7              | Plano executável                                      |
| GATE-S16      | G8              | Piloto: cliente pagou + valor + repetível             |
| GATE-S17      | G9              | Empreendedor opera sozinho em sim                     |
| GATE-S18      | G10             | Método mínimo dominado                                |
| GATE-S19      | G11             | 5 condições de handover atendidas                     |
| GATE-S20      | G12             | Autonomia consolidada                                 |

`roadmap[].gate` deve usar a label x-ray-abs (G0-G12) ou a label
canônica (GATE-Sxx) consistentemente. Recomendado: G0-G12 para output
consumido por agentes downstream, GATE-Sxx em comentários.

---

## Mapping Table — Deliverables Canônicos × artifacts[]

Os 100+ deliverables do schema canônico mapeiam para `artifacts[]` no
YAML. Padrão de ID:

```
DEL-Sxx-NN  → artifacts[].id = "art-Sxx-NN"
```

### Categorias de deliverables S15 (Ativos de Execução)

| Categoria       | Deliverables exemplos                                    | artifacts[].type |
|-----------------|----------------------------------------------------------|------------------|
| Comerciais      | Script prospecção · pitch deck · landing page · CRM      | document/asset/tool |
| Operacionais    | Checklist onboarding · playbook entrega · template briefing | document/template |
| Financeiros     | Modelo financeiro · projeção 90d · controle caixa        | spreadsheet      |
| Gestão          | Dashboard KPIs · matriz risco · backlog experimentos     | dashboard/document |

### Mapping específico — deliverables críticos

```yaml
# DEL-S00-01 — Pergunta de decisão formulada
project.decision_question: "<string>"

# DEL-S03-01 — Documento de escopo aprovado
artifacts:
  - id: art-S03-01
    type: document
    name: "Documento de Escopo"
    epistemic: FACT  # se aprovado
    relevance: critical

# DEL-S07-02 — Mapa de dores consolidado
artifacts:
  - id: art-S07-02
    type: document
    name: "Mapa de Dores"
    epistemic: FACT
    relevance: high

# DEL-S08-01 — Modelo econômico preliminar
artifacts:
  - id: art-S08-01
    type: spreadsheet
    name: "Modelo Econômico Preliminar"
    relevance: critical

# DEL-S14-01 — Roadmap 30/60/90 dias
roadmap:
  - phase: D55-D65
    deliverable: "Roadmap 30 dias"
    gate: G7
  - phase: D55-D65
    deliverable: "Roadmap 60 dias"
    gate: G7
  - phase: D55-D65
    deliverable: "Roadmap 90 dias"
    gate: G7

# DEL-S19 — Pacote completo handover (22 itens)
# Cada item vira um artifact com ID art-S19-NN
```

---

## Mapping — 10 Decision Questions canônicas → project.decision_question

| DQ-N  | Pergunta                                  | Trigger no input                               |
|-------|-------------------------------------------|-------------------------------------------------|
| DQ-1  | Existe uma decisão clara?                 | Briefing vago, sem decisão articulada           |
| DQ-2  | Existe fit empreendedor-oportunidade?     | Founder novo no setor / sem recursos confirmados|
| DQ-3  | Existe dor real no mercado?               | Hipótese de produto sem validação qualitativa   |
| DQ-4  | Existe disposição a pagar?                | Hipótese de pricing sem teste                   |
| DQ-5  | Existe canal de aquisição viável?         | GTM teórico, sem outbound/inbound testado       |
| DQ-6  | Existe modelo econômico aceitável?        | Unit economics não calculadas                    |
| DQ-7  | Existe oferta simples para começar?       | Produto over-engineered, escopo amplo demais     |
| DQ-8  | Existe piloto com sinal positivo?         | Pré-piloto / piloto em curso                     |
| DQ-9  | Existe processo repetível?                | Pós-piloto · padronização incompleta             |
| DQ-10 | Empreendedor consegue operar sozinho?     | Pré-handover                                     |

A skill x-ray-db deve preencher `project.decision_question` com a DQ
canônica detectada quando input é output de x-ray-abs em Canonical Engine
Mode (PASSO 8 da skill x-ray-abs).

---

## Mapping — 5 Fórmulas de Scoring → next_steps[].score

```yaml
# SCORE-01 (Prioridade Simples — S06, S07, S08)
score:
  impacto: <1-10>
  confianca: <1-10>
  esforco: <1-10>
  composite: <calculated · I*C/E>
  formula: SCORE-01

# SCORE-02 (Prioridade Completa — S08, S09, S10) ⭐ default
score:
  impacto: <1-10>
  urgencia: <1-10>
  confianca: <0.0-1.0>
  fit: <1-10>
  esforco: <1-10>
  risco: <1-10>
  composite: <calculated · (I*U*C*F)/(E*R)>
  formula: SCORE-02

# SCORE-03 (Potencial de Mercado — S05, S06)
score:
  volume_problema: <1-10>
  intensidade_dor: <1-10>
  capacidade_pagar: <1-10>
  composite: <calculated · V*I*C>
  formula: SCORE-03

# SCORE-04 (Cálculo de Gap — S07, S08)
score:
  meta: <numeric>
  resultado_atual: <numeric>
  composite: <calculated · meta - atual>
  formula: SCORE-04

# SCORE-05 (Funil de Conversão — S07, S12)
score:
  ctr_botao: <0.0-1.0>
  taxa_checkout: <0.0-1.0>
  taxa_compra: <0.0-1.0>
  conversao_total: <calculated>
  formula: SCORE-05
```

x-ray-db deve preservar `formula:` quando input declara fórmula
canônica usada. Default: SCORE-02.

---

## 5 Condições de Handover (S19) → executive_context.handover_status

```yaml
executive_context:
  one_liner: "<síntese>"
  current_state: "<atual>"
  target_state: "<futuro>"
  delta: "<gap>"
  primary_lens: "<lente>"
  handover_status:                          # v2 · novo
    hov1_clareza_estrategica: <true|false|partial>
    hov2_sistema_metricas: <true|false|partial>
    hov3_rotina_decisao: <true|false|partial>
    hov4_documentacao_ops: <true|false|partial>
    hov5_autonomia_critica: <true|false|partial>
    overall: <ready|extend|risks_documented>
```

Campo `handover_status` deve ser populado quando input declara fase ≥ S18.

---

## Anti-pattern — não inventar fase

Se input não declara fase explicitamente E não há sinais qualitativos
fortes, NÃO inventar `project.stage`. Usar:

```yaml
project:
  stage: null
  stage_epistemic: GAP
  stage_inference_notes: "Input não declarou fase · ausência de D-day · ausência de gate references"
```

Resultado válido com null é melhor que stage inferido errado.

---

## Trigger — Canonical Pipeline Mode em x-ray-db

Ativar este mode quando input contém qualquer dos seguintes sinais:

```
- Output de x-ray-abs em modo Canonical Engine (PASSO 8 explícito)
- Strings: "S00"-"S20" · "GATE-S00"-"GATE-S20" · "DQ-1"-"DQ-10"
- Strings: "DEL-Sxx-NN" · "D-day" · "D5"-"D120"
- Header em texto: "[FASE: Sxx · GATE: GATE-Sxx · CRITÉRIO: ...]"
```

Comportamento:
1. Ler este arquivo + verificar mapeamentos canônicos
2. Preservar IDs canônicos no YAML (DEL-Sxx-NN → art-Sxx-NN)
3. Preencher `roadmap[].gate` com label G0-G12 (não GATE-Sxx)
4. Preencher `executive_context.handover_status` se fase ≥ S18
5. Declarar `metadata.canonical_mode: true` no header
