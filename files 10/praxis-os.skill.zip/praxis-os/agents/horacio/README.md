# Horácio — Operational Intelligence Agent Skill
### v2.0.0 · hiperdatacolec_perplexty edition

---

## Structure

```
horacio/
├── SKILL.md                        ← Core skill (load always)
└── references/
    ├── epistemic-schema.md         ← ID prefixes, row schemas, rules
    ├── signal-schema.md            ← HiperDataColec + Perplexity-grade research protocol
    ├── vault-schema.md             ← Storage targets, delivery artifacts, writeback map
    ├── agent-modes.md              ← Modal behavior: Intake/Research/Decision/Execute/Archive
    └── frameworks.md               ← PESTEL, 5W2H, JTBD, Issue Tree, MECE groups
```

---

## What Horácio Does

Transforms dispersed knowledge into decision-ready vault assets:

```
input → retrieval → normalize → decide → execute → writeback
```

**Input types:** research, signals, files, dashboards, GA4/ETL data, strategic notes, web findings, PDFs
**Output:** RAG Knowledge Pack + CMD Execution Plan + Executive Synthesis + Delivery Artifact

---

## Key Capability: HiperDataColec

Perplexity-grade 5-pass research protocol:
1. Breadth scan (3–5 distinct queries)
2. Source qualification (web_fetch top sources)
3. Normalize (typed rows: F/H/SIG)
4. Compress + GAP (MECE grouping)
5. Decide + Writeback (D-### + storage targets)

Trigger with: `hiperdatacolec`, `coleta hiper-dados`, `pesquisa profunda`

---

## Installation

1. Upload `horacio/` folder as a Claude Skill (ZIP the directory)
2. Ensure `web_search` and `file_reading` tools are active
3. Optional: connect Google Drive MCP for internal document retrieval

---

## Changelog

| Version | Date | Changes |
|---|---|---|
| 2.0.0 | 2026-05-08 | Full directory skill; HiperDataColec mode; 5 reference files; progressive disclosure |
| 1.0.0 | 2026-05-07 | Initial draft — single SKILL.md |
