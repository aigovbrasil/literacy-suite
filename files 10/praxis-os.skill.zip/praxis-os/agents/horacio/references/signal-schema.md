# HiperDataColec + Signal Schema — Horácio v2

## HiperDataColec Mode

**Aliases:** `hiperdatacolec` | `coleta hiper-dados` | `pesquisa profunda` | `deep research`

Activate when the user needs Perplexity-grade multi-pass web research that
produces decision-ready vault output rather than raw search summaries.

---

## 5-Pass Collection Protocol

### PASS 1 — Breadth Scan
```
Goal: identify signal clusters, contradictions, key sources
Tool: web_search × 3–5 distinct queries
Rules:
  - Query diversity required (no near-duplicate searches)
  - Cover: market, competition, customer, regulation, technology angles
  - Note source types found (primary? official? journalism?)
```

### PASS 2 — Source Qualification
```
Goal: extract high-confidence facts from top sources
Tool: web_fetch × top 3–5 URLs from Pass 1
Rules:
  - Rank by source reliability (primary > official > enterprise > journalism)
  - Flag paywalled or inaccessible sources as G-### (GAP)
  - Extract: metric, timeframe, geography, author/org
```

### PASS 3 — Normalize
```
Goal: convert raw findings into typed SIG-### and F-### rows
Output: signal_schema table (see below)
Rules:
  - Every claim gets a Tipo prefix (F/H/I/SIG)
  - No invented data — G-### for missing evidence
  - Separate observed fact from interpretation
```

### PASS 4 — Compress + GAP
```
Goal: MECE grouping, noise reduction, gap identification
Grouping default:
  market_demand | buyer_pain | workflow_gap | decision_gap |
  pricing | competition | execution_constraint | moat | risk | next_action
Output:
  - Compressed signal clusters (max 3 rows per group)
  - GAPS table for missing evidence
```

### PASS 5 — Decide + Writeback
```
Goal: convert compressed signals into decisions and storage targets
Output:
  - D-### decision table (at least 1 binary recommendation)
  - Storage target for every output row
  - Delivery artifact (prompt / spec / plan)
```

---

## Signal Schema (Full)

For market research, GA4, ETL, sector reports, behavioral data:

```
| signal_id | source_id | category | signal_type | fact | metric | value | unit |
| timeframe | geography | reliability_score | relevance_score | implication | next_action |
```

**Categories:**
`market | customer | product | technology | regulatory | competitive | behavioral | financial`

**Signal types:**
`trend | anomaly | confirmation | contradiction | weak_signal | leading_indicator | lagging_indicator`

**Reliability score:** 1–5 (1=speculation, 5=primary source with data)
**Relevance score:** 1–5 (1=tangential, 5=directly actionable for current decision)

### Example

```
| SIG-001 | SRC-001 | market | trend | Adoção de IA em PMEs cresceu 34% YoY no Brasil |
| 34% | pct_yoy | 2025 Q4 | Brasil | 4 | 5 | Mercado em maturação; janela de entrada se fecha |
| Validar via entrevista se crescimento é nas PMEs alvo (50-200 func) |
```

---

## Data / Dashboard / GA4 Policy

When handling dashboards, GA4, ETL exports, or structured data files:

1. Extract the metric (exact value, not rounded unless source rounds it)
2. Identify the source (SRC-###)
3. Record timeframe AND geography
4. Separate: observed fact vs interpretation
5. Add strategic implication
6. Add next action
7. Define validation metric (M-###)
8. Assign storage target

**Anti-patterns:**
- ❌ "Conversions increased" → ✅ "F-001: Conversions increased 18% MoM | April 2026 | Brasil | SRC-003"
- ❌ "Engagement is good" → ✅ "M-001: Session duration > 3min = H-001 validated"
- ❌ Mixing timeframes in same row → always separate rows per period

---

## Perplexity-Grade Quality Bar

A HiperDataColec output passes if:
- [ ] ≥ 3 distinct sources consulted
- [ ] Source reliability scored for every F/SIG row
- [ ] Timeframe + geography explicit on every metric
- [ ] At least 1 contradiction or gap identified
- [ ] At least 1 binary D-### produced
- [ ] Storage target assigned to every output

Fails if:
- [ ] Generic summaries without typed rows
- [ ] Data without source or timeframe
- [ ] No decision produced from research
- [ ] Invented data filling gaps (use G-### instead)
