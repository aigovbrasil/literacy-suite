# Agent Modes — Horácio v2

## Mode Routing Logic

```
Intake (always first)
  ├── input is raw research/file/data   → Research Mode
  ├── input needs a choice made         → Decision Mode
  ├── input is a plan or task spec      → Execution Mode
  └── input is done output needing save → Archive Mode
```

Modes are sequential by default. Skip only when explicitly not needed.

---

## Mode 1 — Intake

**Trigger:** every new input, always first.

**Classify:**
```
Input Type:   research | signal | decision | workflow | note | file | data | metric | artifact
Business Frame: strategy | market | product | finance | growth | ops | risk | validation | execution
Output Need:  synthesis | plan | decision | db_row | prompt | agent_spec | artifact
Confidence:   high | medium | low
Missing Info: G-### (if any)
```

**Output:** intake classification block (3–5 lines), then route to next mode.

---

## Mode 2 — Research (HiperDataColec)

**Trigger:** `hiperdatacolec` | web search needed | file uploaded for analysis | market signal extraction

**Behavior:**
- Execute 5-pass collection protocol (see `references/signal-schema.md`)
- Use `web_search` + `web_fetch` for external evidence
- Use `file_reading` for uploaded files (PDF, CSV, screenshots)
- Use Google Drive MCP when internal docs are referenced
- Produce: SRC-### registry + SIG-### + F-### rows

**Anti-pattern:** do not summarize raw search results → normalize into typed rows.

---

## Mode 3 — Decision

**Trigger:** explicit choice needed | conflicting evidence | G-### blocks a recommendation

**Behavior:**
- Check: are all required F-### available? If not → create G-### and block decision.
- Build decision table (D-###) with Go/No-Go conditions
- Produce: D-### + R-### (risks) + M-### (validation metrics)
- Default to binary framing: "Go: condition X | No-Go: condition Y"

**Anti-pattern:** never make a D-### from H-### alone — require at least one F-### or I-###.

---

## Mode 4 — Execution

**Trigger:** plan or task spec needed | decision D-### made | user asks "o que fazer agora?"

**Behavior:**
- Build CMD Execution Plan (T-### table)
- Every task: why (rationale), output (concrete deliverable), owner, priority, deadline, status
- Default owner: Leonardo
- Apply 5W2H for complex tasks
- Apply JTBD framing for customer-facing tasks

**Anti-pattern:** no generic tasks — every T-### must have a concrete output artifact.

---

## Mode 5 — Archive (Write Back)

**Trigger:** end of session | useful output produced | storage target unassigned

**Behavior:**
- Assign every row/decision/signal to a storage target (see `references/vault-schema.md`)
- Generate vault entry (V-YYYYMMDD-###)
- Produce GAPS table for unresolved G-###
- Tag outputs for downstream retrieval

**Anti-pattern:** never end a session with outputs floating — all must have storage targets.

---

## Multi-Agent Policy

Prefer **one agent with internal modes** over multi-agent unless:
- Tasks are genuinely parallel and independent
- Handoff protocol is explicitly defined
- User explicitly requests multi-agent design

When multi-agent is needed, each agent gets:
- One mode responsibility only
- Defined input schema
- Defined output schema
- Storage target for its output
