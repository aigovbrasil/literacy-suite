---
compatibility: 'tools: ask_user_input_v0, create_file, view, bash_tool, present_files'
description: 'Transforma workflows casuais do Claude em skills profissionais reutilizáveis com widget visual interativo. SEMPRE ative quando usuário disser "transforma isso em skill", "quero automatizar
  isso", "cria skill desse workflow", "skill-ify this", "vira skill", ou quando mencionar que está repetindo o mesmo pedido toda semana/dia. TAMBÉM ative quando usuário descrever workflow repetitivo (ex:
  "toda segunda crio cronograma semanal"). Skill otimizada para iniciantes não-dev — 3 perguntas apenas, widget preview instantâneo via forge-visual-canvas, documentação em PT-BR, zero jargão técnico. Integra
  automaticamente com live-prompt-pro-converter (normalização), skill-creator (geração), e todas skills X-Ray/user disponíveis.

  '
name: workflow-to-skill-magic
---

# Workflow to Skill Magic

**Do workflow casual → Skill profissional em 3 perguntas.**

Sistema automático que:
- Captura workflow que você acabou de fazer
- Normaliza via `/live-prompt-pro-converter`
- Gera skill via `/skill-creator`
- Cria widget visual via `/forge-visual-canvas`
- Integra com skills disponíveis
- Entrega `.skill` + widget + exemplos

**Zero programação. Zero jargão. Tudo em português.**

---

## QUANDO USAR

### Gatilhos Explícitos
```
"transforma isso em skill"
"quero automatizar isso"
"cria skill desse workflow"
"skill-ify this"
"vira skill"
"como transformo em skill?"
```

### Gatilhos Contextuais (Automáticos)
- Usuário repete mesmo pedido 2+ vezes na conversa
- Menciona "toda semana faço isso"
- Menciona "sempre preciso pedir isso"
- Descreve workflow com >3 etapas repetitivas

### Exemplos Reais
```
User: "Toda segunda crio cronograma semanal, mas sempre esqueço o formato. Tem como automatizar?"
Skill: ✅ ATIVA

User: "Preciso gerar relatório mensal sempre, mas nunca lembro os campos"
Skill: ✅ ATIVA

User: "Como transformo esse workflow que acabei de fazer em skill?"
Skill: ✅ ATIVA
```

---

## WORKFLOW CANÔNICO (Invisível ao Usuário)

```
1. CAPTURA (automática)
   ├── Escaneia conversa atual
   ├── Identifica ferramentas usadas
   ├── Extrai input/output
   └── Detecta padrão repetitivo

2. NORMALIZAÇÃO (via live-prompt-pro-converter)
   ├── Descrição casual → spec técnica
   ├── Identifica triggers claros
   └── Otimiza para Claude

3. INTAKE SIMPLIFICADO (ask_user_input_v0)
   ├── Q1: Qual nome curto? [auto-sugerido]
   ├── Q2: Quando deve ativar? [auto-detectado]
   └── Q3: Só você ou compartilhar? [uso/público]

4. GERAÇÃO (via skill-creator)
   ├── Cria SKILL.md estruturado
   ├── Gera scripts se necessário
   ├── Define triggers
   └── Integra com skills disponíveis

5. WIDGET VISUAL (via forge-visual-canvas)
   ├── Dashboard interativo
   ├── Preview de uso
   ├── Exemplos clicáveis
   └── Dark/light mode

6. INTEGRAÇÃO INTELIGENTE
   ├── Detecta skills relacionadas
   ├── Sugere combinações
   └── Otimiza token economy

7. ENTREGA
   ├── nome-da-skill.skill (ZIP)
   ├── widget-preview.html (standalone)
   ├── README-pt-br.md (guia claro)
   └── install.txt (comandos copy-paste)
```

**Usuário vê:** 3 perguntas → Aguarda 30seg → Recebe tudo pronto.

---

## INTERFACE SIMPLIFICADA (UX Iniciante)

### Entrada do Usuário
```
"Transforma isso em skill"
```

### Claude Responde
```
✨ Detectei que você:
  • Criou cronograma semanal
  • Formatou em tabela
  • Adicionou tarefas recorrentes

Vou transformar em skill automática!

Só 3 perguntas rápidas:
```

### Pergunta 1 (Nome)
```
📝 Qual nome curto para a skill?

Sugestão: "cronograma-semanal"

[Input texto livre ou aceita sugestão]
```

### Pergunta 2 (Gatilho)
```
🎯 Quando deve ativar?

Detectei que ativa quando você diz:
☑ "cria cronograma semanal"
☑ "gera agenda da semana"

Adicionar outro gatilho? [Opcional]
```

### Pergunta 3 (Uso)
```
👥 Essa skill é:

○ Só para mim (uso pessoal)
○ Para compartilhar (outros vão usar)
```

### Processamento (Visível)
```
⚙️ Criando sua skill...

✓ Normalizando workflow
✓ Gerando estrutura
✓ Criando widget visual
✓ Integrando com suas skills

Pronto em ~30 segundos...
```

### Entrega
```
🎉 Skill criada!

📦 cronograma-semanal.skill
📊 Widget interativo (preview abaixo)
📄 Guia de instalação

[Widget renderiza inline via forge-visual-canvas]

Próximo passo:
Settings > Skills > Upload cronograma-semanal.skill

Quer testar agora? Diga: "cria cronograma semanal"
```

---

## REGRAS DE CONDUTA

### R01: APENAS 3 PERGUNTAS
```python
questions = [
    {"q": "Nome?", "auto_suggest": True},
    {"q": "Quando ativar?", "auto_detect": True},
    {"q": "Uso pessoal ou público?", "default": "pessoal"}
]
# MAX 3. Nunca mais.
```

### R02: PORTUGUÊS SEMPRE
```python
language = "pt-BR"
jargon_level = "zero"
examples = "concretos"
tone = "amigável"
```

### R03: PREVIEW ANTES DE ENTREGAR
Widget visual SEMPRE renderiza via `forge-visual-canvas`:
```python
widget = generate_visual_preview({
    "skill_name": nome,
    "triggers": gatilhos,
    "workflow_steps": etapas,
    "example_output": preview_resultado
})
```

### R04: INTEGRAÇÃO AUTOMÁTICA
```python
# Detecta skills relacionadas sem perguntar
available_skills = get_user_skills()
related = detect_related_skills(workflow, available_skills)

# Integra automaticamente se ROI claro
if related and roi_obvious:
    integrate_silently()
else:
    suggest_integration()
```

### R05: FALLBACK GRACIOSO
```python
# Se workflow muito vago
if workflow_unclear:
    ask_user_input({
        "question": "Pode descrever o que você fez em 2-3 frases?",
        "examples": [
            "Criei tabela com 5 colunas",
            "Gerei lista de tarefas semanais",
            "Formatei documento em markdown"
        ]
    })
```

### R06: WOW MOMENT GARANTIDO
```python
# Widget deve causar "Uau, isso ficou profissional!"
widget_quality = "production-grade"
design_tokens = "FORGE"
interactions = "smooth"
preview_accuracy = "pixel-perfect"
```

---

## WIDGET VISUAL (via forge-visual-canvas)

### Estrutura do Widget
```html
<!-- Dashboard Interativo -->
<div class="skill-preview">
  <header>
    <h1>cronograma-semanal</h1>
    <span class="badge">v1.0.0</span>
  </header>
  
  <section class="triggers">
    <h2>Ativa quando você diz:</h2>
    <ul>
      <li>"cria cronograma semanal"</li>
      <li>"gera agenda da semana"</li>
    </ul>
  </section>
  
  <section class="workflow-preview">
    <h2>O que faz:</h2>
    <ol class="steps">
      <li>Cria tabela 7 dias</li>
      <li>Adiciona tarefas recorrentes</li>
      <li>Formata em markdown</li>
    </ol>
  </section>
  
  <section class="example-output">
    <h2>Resultado:</h2>
    <div class="output-preview">
      <!-- Preview real do cronograma -->
    </div>
  </section>
  
  <section class="integrations">
    <h2>Integra com:</h2>
    <span class="badge">docx</span>
    <span class="badge">pdf</span>
  </section>
  
  <footer>
    <button onclick="copyInstallCommand()">
      Copiar comando de instalação
    </button>
  </footer>
</div>
```

### Design Tokens (FORGE)
```css
:root {
  --color-primary: #FF6B35;
  --color-bg: #1A1A2E;
  --font-display: 'Poppins', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
  --radius: 12px;
  --shadow: 0 8px 24px rgba(0,0,0,0.2);
}
```

---

## INTEGRAÇÃO COM SKILLS DISPONÍVEIS

### Com live-prompt-pro-converter
```python
# SEMPRE normaliza descrição casual
raw_description = user_input
normalized = call_skill("live-prompt-pro-converter", {
    "input": raw_description,
    "target_model": "claude",
    "optimize_for": "skill-creation"
})
```

### Com skill-creator
```python
# Gera skill core
skill_md = call_skill("skill-creator", {
    "intent": normalized.intent,
    "triggers": normalized.triggers,
    "workflow": normalized.steps,
    "user_level": "iniciante"
})
```

### Com forge-visual-canvas
```python
# Gera widget visual
widget = call_skill("forge-visual-canvas", {
    "type": "skill-dashboard",
    "data": {
        "name": skill_name,
        "triggers": triggers,
        "workflow": steps,
        "output_preview": example
    },
    "language_visual": "executiva",
    "mode": "dark"
})
```

### Com x-ray-self-knowledge
```python
# Se workflow relacionado a X-Ray
if detect_xray_context(workflow):
    xray_routing = call_skill("x-ray-self-knowledge", {
        "query": "qual skill X-Ray este workflow usa?"
    })
    integrate_xray(xray_routing)
```

### Com hyperautomation-diagnostico
```python
# Sugere automações adicionais
automation_suggestions = call_skill("hyperautomation-diagnostico", {
    "workflow": skill_workflow,
    "context": "pós-skill-creation"
})
# Ex: "Quer criar GitHub Action para rodar isso toda segunda?"
```

---

## CASO TÍPICO — Cronograma Semanal

### Input do Usuário
```
User: "Toda segunda crio cronograma semanal. 
       Sempre esqueço o formato. 
       Tem como automatizar?"
```

### Skill Detecta
```yaml
workflow_detected:
  task: "Criar cronograma semanal"
  frequency: "toda segunda"
  pain_point: "esquecer formato"
  tools_likely: [create_file, ask_user_input_v0]
```

### Skill Responde
```
✨ Detectei workflow repetitivo!

Vou criar skill que automatiza isso.

📝 Nome sugerido: "cronograma-semanal"
   [Manter] ou [Trocar]

🎯 Ativa quando você disser:
   ☑ "cria cronograma semanal"
   ☑ "gera agenda da semana"
   [OK] ou [Adicionar gatilho]

👥 Uso: 
   ○ Só para mim ✓
   ○ Compartilhar

⚙️ Criando... (30s)
```

### Skill Gera
```
cronograma-semanal/
├── SKILL.md
│   ├── Triggers: "cria cronograma", "agenda semana"
│   ├── Workflow: tabela 7 dias + recorrentes
│   └── Output: markdown table
├── templates/
│   └── cronograma-base.md
└── widget/
    └── preview.html (visual interativo)
```

### Widget Preview (Inline)
```html
<!-- Renderiza via forge-visual-canvas -->
<div class="skill-dashboard">
  <h1>cronograma-semanal</h1>
  
  <section class="demo">
    <button onclick="runDemo()">
      ▶️ Ver demonstração
    </button>
    <!-- Mostra animação do workflow -->
  </section>
  
  <section class="output-sample">
    <!-- Preview do cronograma real -->
    | Dia | Tarefas |
    |-----|---------|
    | Seg | • Reunião 9h<br>• Code review 14h |
    | ... | ... |
  </section>
</div>
```

### Entrega Final
```
🎉 Skill pronta!

📦 Arquivos:
  • cronograma-semanal.skill (12KB)
  • widget-preview.html (standalone)
  • README-pt-br.md

📊 Widget interativo ↓
[Widget renderiza aqui]

📥 Instalar:
Settings > Skills > Upload cronograma-semanal.skill

🧪 Testar agora:
"cria cronograma semanal"

💡 Dica:
Integrei com skill 'docx' — pode exportar pra Word!
Quer? Diga: "exporta cronograma pra Word"
```

---

## CASOS DE USO (ICP)

### 1. Freelancer — Relatório Mensal Cliente
```
Input: "Todo mês mando relatório pro cliente, sempre esqueço o template"

Skill gera:
  • relatorio-mensal-cliente.skill
  • Widget com preview do relatório
  • Integra com docx + pdf
  • Gatilho: "gera relatório mensal"
```

### 2. Consultor — Proposta Comercial
```
Input: "Sempre crio proposta comercial, mas mudo só valores"

Skill gera:
  • proposta-comercial.skill
  • Widget com calculadora de valores
  • Templates variáveis
  • Gatilho: "cria proposta comercial"
```

### 3. PM — Sprint Planning Doc
```
Input: "Toda sprint crio doc de planning, formato sempre igual"

Skill gera:
  • sprint-planning-doc.skill
  • Widget com checklist
  • Integra com Linear (cria issues)
  • Gatilho: "planning da sprint"
```

---

## ESTIMATIVAS

| Complexidade | Workflow | Perguntas | Tempo | Custo (Haiku) |
|--------------|----------|-----------|-------|---------------|
| Simples | 1-3 etapas | 3 | 30s | $0.02 |
| Médio | 4-7 etapas | 3 | 60s | $0.05 |
| Complexo | 8+ etapas | 3 + clarificações | 90s | $0.08 |

**Modelo recomendado:** Haiku 4 (rápido + barato para showcase)

---

## TROUBLESHOOTING

### "Workflow muito vago"
```python
if vague:
    ask: "Pode dar exemplo concreto do que você fez?"
    wait_for_example()
    retry_detection()
```

### "Usuário não sabe nomear skill"
```python
if nome == "não sei":
    auto_suggest = extract_noun_from_workflow(descrição)
    # Ex: "cronograma" de "criar cronograma"
```

### "Widget não renderiza"
```python
if widget_fails:
    fallback_to_text_preview()
    log_error_for_improvement()
```

---

## PRÓXIMOS PASSOS (Pós-Entrega)

1. ✅ Usuário baixa `.skill`
2. ✅ Upload em Settings > Skills
3. ✅ Testa com gatilho
4. 🎯 Compartilha widget (marketing viral)
5. 🎯 Solicita feedback via ask_user_input

---

**Versão:** 1.0.0  
**Status:** Production-ready  
**Target:** Iniciantes não-dev, topo de funil  
**Idioma:** PT-BR
