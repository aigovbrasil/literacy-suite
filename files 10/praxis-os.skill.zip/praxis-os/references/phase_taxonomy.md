# PRAXIS.OS — Phase Taxonomy

The 5-phase model. Every PRAXIS request maps to one phase. Agents read this
file when they need to know which phase a request belongs to.

## SIGNAL — gathering raw data

User is collecting information. No analysis yet. No deliverable.

Agents in this phase:

- bussola-personalization (consultant config + client intake)
- x-ray-client-form (HTML intake artifact for client)
- cmd-03-maro (multi-agent research design)
- horacio (signal normalization to vault)
- empower-v4-ai-usage-evaluator (audit of past AI usage)

Trigger words: new client, intake, research, signals, vault, hyperdata,
import, normalize, audit usage, sinal de mercado, hipotese inicial

Exit criteria: enough labeled facts to begin diagnosis. Move to INTELLIGENCE
when consultant says "ok, what does this mean?"

## INTELLIGENCE — analysis and diagnosis

User is reasoning over signals. Producing structured analysis. No client
deliverable yet.

Agents in this phase:

- x-ray-abs (strategic diagnosis with scoring)
- x-ray-db (YAML normalization for downstream agents)
- live-prompt-pro-converter (analytical prompt optimization)
- product-self-knowledge (verify Anthropic product facts before citing)

Trigger words: diagnose, analyze, gap, risk, score, prioritize, why, hypothesis,
SWOT, problem tree, decision question

Exit criteria: prioritized list of problems with scoring, ready to act on.
Move to ARTIFACT when consultant says "draft this for the client."

## ARTIFACT — written output production

User is producing documents, content, comms. Output may be for internal or
external audience.

Agents in this phase:

- business-docx-pipeline (full doc corpus from brief)
- doc-coauthoring (collaborative document workflow)
- internal-comms (status reports, 3P, newsletter)
- frankwatching-editor (Dutch B2B editorial)

Trigger words: write, draft, document, proposal, article, MRD, BRD, PRD,
RFC, decision doc, newsletter, status report, post, comms

Exit criteria: written artifact in canonical format with sources cited.
Move to DELIVERY when consultant says "package this up."

## DELIVERY — packaging and client output

User is finalizing artifacts for client consumption. Visual polish, branding,
distribution.

Agents in this phase:

- x-ray-onboarding-ebook (interactive HTML ebook, dual route)
- x-ray-executive-office (Kanban dashboard, dual mode)
- x-ray-skill-packager (suite ZIP for distribution)
- bussola-consultative-faq (self-service method FAQ)

Trigger words: ebook, dashboard, package, ship, deliver, send, kanban,
deliverable, ZIP, final, client-ready

Exit criteria: artifact in final format with brand applied, ready to send.
Move to FEEDBACK after delivery.

## FEEDBACK — self-improvement and system maintenance

User is improving their own system after a case completes. Engineering layer.

Agents in this phase:

- cmd-01-pps (project packaging system)
- cmd-02-mirp (skill improve-register-publish)
- workflow-to-skill-magic (convert workflow → skill)
- x-ray-self-knowledge (suite navigation router)

Trigger words: improve, audit, register, publish, skill-ify, automate this,
package my project, normalize my files, what does X agent do

Exit criteria: an improved skill or normalized project artifact. Loop back
to SIGNAL on next case.

## Detection heuristic

When intent is ambiguous, ask:

1. Is the user gathering or analyzing? → SIGNAL vs INTELLIGENCE
2. Is the output for them or for someone else? → ARTIFACT (themselves or
   internal) vs DELIVERY (external client)
3. Is the user working on a case or on their own toolkit? → first 4 phases
   vs FEEDBACK
