# PRAXIS.OS — Gates Reference

Gates are human-required approval checkpoints. No automatic promotion past a
gate, ever. Agents must surface gate status to the consultant and wait for
explicit confirmation before continuing.

## Bússola PME (G0–G6)

| Gate | What it gates | Where | Hardcoded |
|---|---|---|---|
| G0 | Intake completeness — 10 fields filled | end of personalization | no |
| G1 | Normalization complete — facts vs hypotheses split | end of diagnostic phase 2 | no |
| G2 | Priority lock — top 3 problems chosen | end of phase 4 | **yes** |
| G3 | Plan of action approved by consultant | end of phase 5 | no |
| G4 | QA checklist green — qa_checklist.md all checked | pre-delivery | no |
| G5 | Final artifact set approved before client send | end of phase 7 | **yes** |
| G6 | Execution handoff to Linear/Slack — irreversible | end of phase 8 | **yes** |

Hardcoded = never bypass in any mode. The orchestrator refuses.

## X-Ray (G1–G4) + canonical engine (G0–G12)

X-Ray operational gates:

| Gate | What it gates |
|---|---|
| G1 | Intake confirmed, case opened, session_state initialized |
| G2 | Diagnosis promoted from hypothesis to working diagnosis |
| G3 | Plan of action drafted with owner + deadline per task |
| G4 | Deliverable approved by consultant for client release |

X-Ray canonical engine extends to G0–G12 across S00–S20 phases. Used by
`x-ray-db` and `x-ray-executive-office` for sprint tracking. Reference:
`agents/x-ray-abs/references/canonical_engine.md` (if present).

## Phase gate per agent

| Agent | Owns gate | Gate behavior |
|---|---|---|
| bussola-personalization | G0 | blocks downstream until 10 fields complete |
| bussola-diagnostic-engine | G2 | hardcoded — refuses to auto-prioritize |
| bussola-deliverable-forge | G4, G5 | G5 hardcoded — no client output without sign |
| bussola-execution-bridge | G6 | hardcoded — no Linear write without confirm |
| x-ray-orchestrator | G1–G4 | session-level gates, all guided |
| x-ray-executive-office | reflects G0–G12 | display only, never promotes |

## Failure modes

If the consultant tries to skip a hardcoded gate:

1. Agent refuses
2. Explains which gate is blocking
3. Surfaces what's missing
4. Does NOT offer to skip "this once"

Speed is not a valid reason to bypass a gate. Gates exist because past
failures showed that bypassing them produces low-quality client deliverables
that hurt the consultant's brand.
