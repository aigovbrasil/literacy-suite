# PRAXIS.OS — Install Guide

## What this is

A 23-agent professional services operating system that runs inside Claude.ai
as a single skill. One router, 23 specialists, 5 phases. Built on Anthropic's
skill-creator monorepo pattern.

## Installation (3 minutes)

1. Go to your Claude.ai project at https://claude.ai
2. Click your project name → Settings → Skills
3. Upload `praxis-os.skill`
4. Wait for "Installed" confirmation
5. Start a new conversation in the project
6. Type `/praxis-help` to verify the router answers

## First-run setup

After install, in your first conversation:

1. Type `/praxis-start`
2. The router will invoke `bussola-personalization` to build your
   `consultant_config.yaml`
3. Answer the 10 fields (name, brand colors, primary method, mode, MCPs)
4. The file is saved to project context — every future conversation reads it

## Daily workflow patterns

| What you want to do | Type |
|---|---|
| Check where I left off | `/praxis status` |
| Open a new client case | `/praxis-start --method xray` or `--method bussola` |
| Run strategic diagnosis | "diagnostique este briefing" + paste content |
| Generate a deliverable | "gere o ebook para o cliente" |
| Improve a prompt | "melhore este prompt" + paste prompt |
| Convert a workflow to a skill | "transforma este workflow em skill" |
| Wrap up the week | `/praxis close-week` |

## Folder structure (what's inside)

```
praxis-os/
├── SKILL.md              ← the router (you talk to this)
├── agents/               ← 23 specialist agents
│   ├── x-ray-abs/
│   ├── x-ray-orchestrator/
│   ├── bussola-personalization/
│   ├── horacio/
│   └── ... (19 more)
├── scripts/              ← validation, packaging, eval tools
│   ├── package_skill.py
│   ├── quick_validate.py
│   └── improve_description.py
└── references/           ← shared across agents
    ├── consultant_config.schema.yaml
    ├── gates.md
    └── phase_taxonomy.md
```

## Updating

When agents change or new ones are added:

1. Edit files locally (or in Claude Code with `git`)
2. Run `python scripts/quick_validate.py /path/to/praxis-os/`
3. Run `python scripts/package_skill.py /path/to/praxis-os/ ./dist`
4. Re-upload the new `praxis-os.skill` to your project Settings → Skills

## Troubleshooting

- Router doesn't fire → check that `praxis-os.skill` is in the project
  Settings, not your user-level skills. Project skills override user skills.
- Two agents seem to compete → the router asks you to pick. Pick once;
  it learns the pattern for this conversation.
- An agent fails → check `agents/<name>/SKILL.md` is intact. If it's missing
  scripts or references, re-package from source.

## Support

The router itself has built-in help. Type:

- `/praxis-help` — list all commands
- `/praxis-agents` — list all 23 agents
- `/praxis-phase <phase>` — list agents in a specific phase

## Version

PRAXIS.OS v1.0 — 23 agents, built 2026-05-13.
